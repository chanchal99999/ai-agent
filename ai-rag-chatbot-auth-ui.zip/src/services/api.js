import axios from 'axios'

const TOKEN_KEY = 'ecom_ops_token'

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' }
})

// Attach JWT token to every request
api.interceptors.request.use(config => {
  const token = localStorage.getItem(TOKEN_KEY)
  if (token) {
    config.headers['Authorization'] = `Bearer ${token}`
  }
  return config
})

// Handle 401 � clear token and redirect to login
api.interceptors.response.use(
  response => response,
  error => {
    if (error.response?.status === 401) {
      localStorage.removeItem(TOKEN_KEY)
      localStorage.removeItem('ecom_ops_user')
      // Only redirect if not already on auth pages
      if (!window.location.pathname.startsWith('/login') &&
          !window.location.pathname.startsWith('/register')) {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

// ---- Auth ----
export const authApi = {
  login: (username, password) =>
    api.post('/auth/login', { username, password }).then(r => r.data),

  register: (data) =>
    api.post('/auth/register', data).then(r => r.data),

  logout: () =>
    api.post('/auth/logout').then(r => r.data),

  me: () =>
    api.get('/auth/me').then(r => r.data),
}

// ---- Chat ----
export const chatApi = {
  sendMessage: (message, sessionId) =>
    api.post('/chat', { message, sessionId }).then(r => r.data),

  createSession: () =>
    api.post('/chat/sessions').then(r => r.data),

  getSessions: () =>
    api.get('/chat/sessions').then(r => r.data),

  getMessages: (sessionId) =>
    api.get(`/chat/sessions/${sessionId}/messages`).then(r => r.data),

  deleteSession: (sessionId) =>
    api.delete(`/chat/sessions/${sessionId}`),
}

// ---- Orders ----
// from / to are ISO-8601 strings; pass null/undefined to use the
// backend default (last 1 hour).
export const ordersApi = {
  getDashboard: (from, to) => {
    const params = {}
    if (from) params.from = from
    if (to)   params.to   = to
    return api.get('/orders/dashboard', { params }).then(r => r.data)
  },

  getOrder: (orderId) =>
    api.get(`/orders/${orderId}`).then(r => r.data),

  getAllManage: (from, to) => {
    const params = {}
    if (from) params.from = from
    if (to)   params.to   = to
    return api.get('/orders/manage/all', { params }).then(r => r.data)
  },

  getAllFulfilment: (from, to) => {
    const params = {}
    if (from) params.from = from
    if (to)   params.to   = to
    return api.get('/orders/fulfilment/all', { params }).then(r => r.data)
  },

  getFailedManage: () =>
    api.get('/orders/failed/manage').then(r => r.data),

  getFailedFulfilment: () =>
    api.get('/orders/failed/fulfilment').then(r => r.data),

  getPriorityIssues: (from, to) => {
    const params = {}
    if (from) params.from = from
    if (to)   params.to   = to
    return api.get('/orders/priority', { params }).then(r => r.data)
  },
}

// ---- Remediation ----
export const remediationApi = {
  getAll: () =>
    api.get('/remediation').then(r => r.data),

  getById: (documentId) =>
    api.get(`/remediation/${documentId}`).then(r => r.data),

  create: (data) =>
    api.post('/remediation', data).then(r => r.data),

  update: (documentId, data) =>
    api.put(`/remediation/${documentId}`, data).then(r => r.data),

  uploadFile: (formData) =>
    api.post('/remediation/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    }).then(r => r.data),

  delete: (documentId) =>
    api.delete(`/remediation/${documentId}`),

  reindex: () =>
    api.post('/remediation/reindex').then(r => r.data),

  getDownloadUrl: (documentId) => `/api/remediation/${documentId}/download`,
}
