import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { BotMessageSquare, Eye, EyeOff, Loader2, LogIn } from 'lucide-react'
import { authApi } from '../services/api.js'
import { useAuth } from '../context/AuthContext.jsx'
import toast from 'react-hot-toast'
import styles from './AuthPage.module.css'

export default function LoginPage() {
  const navigate    = useNavigate()
  const { login }   = useAuth()

  const [form, setForm]       = useState({ username: '', password: '' })
  const [showPw, setShowPw]   = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState('')

  const set = (k, v) => { setForm(f => ({ ...f, [k]: v })); setError('') }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.username || !form.password) {
      setError('Please enter your username and password')
      return
    }
    setLoading(true)
    setError('')
    try {
      const data = await authApi.login(form.username, form.password)
      login(data.token, {
        username: data.username,
        email:    data.email,
        fullName: data.fullName,
        role:     data.role,
        userId:   data.userId,
      })
      toast.success(`Welcome back, ${data.fullName || data.username}!`)
      navigate('/chat', { replace: true })
    } catch (err) {
      const msg = err.response?.data?.error || 'Login failed. Please try again.'
      setError(msg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={styles.root}>
      <div className={styles.card}>

        {/* Brand */}
        <div className={styles.brand}>
          <div className={styles.brandIcon}><BotMessageSquare size={28} /></div>
          <div>
            <div className={styles.brandName}>CFC Agent</div>
          </div>
        </div>

        <h1 className={styles.title}>Sign in to your account</h1>
        <p className={styles.desc}>Enter your credentials to access CFC Agent</p>

        {error && (
          <div className={styles.errorBanner}>{error}</div>
        )}

        <form className={styles.form} onSubmit={handleSubmit}>
          <div className={styles.field}>
            <label className={styles.label}>Username</label>
            <input
              className={styles.input}
              type="text"
              placeholder="Enter your username"
              value={form.username}
              onChange={e => set('username', e.target.value)}
              autoFocus
              autoComplete="username"
              disabled={loading}
            />
          </div>

          <div className={styles.field}>
            <label className={styles.label}>Password</label>
            <div className={styles.passwordWrap}>
              <input
                className={styles.input}
                type={showPw ? 'text' : 'password'}
                placeholder="Enter your password"
                value={form.password}
                onChange={e => set('password', e.target.value)}
                autoComplete="current-password"
                disabled={loading}
              />
              <button
                type="button"
                className={styles.eyeBtn}
                onClick={() => setShowPw(v => !v)}
                tabIndex={-1}
              >
                {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className={`btn btn-primary ${styles.submitBtn}`}
            disabled={loading}
          >
            {loading
              ? <><Loader2 size={16} className={styles.spin} /> Signing in…</>
              : <><LogIn size={16} /> Sign In</>
            }
          </button>
        </form>

        <p className={styles.switchLink}>
          Don't have an account?{' '}
          <Link to="/register" className={styles.link}>Create one</Link>
        </p>

        {/* Default credentials hint */}
        <div className={styles.hint}>
          <strong>Demo credentials</strong>
          <div className={styles.hintRow}><span>Admin</span><code>admin1 / admin123</code></div>
          <div className={styles.hintRow}><span>User</span><code>user1 / user123</code></div>
        </div>
      </div>
    </div>
  )
}
