import { useState, useEffect, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  AlertTriangle, RefreshCw, Loader2, MessageSquare,
  ShieldAlert, Calendar, Clock, RotateCcw
} from 'lucide-react'
import { ordersApi } from '../services/api.js'
import { formatDate, priorityBadgeClass, statusBadgeClass } from '../utils/helpers.js'
import toast from 'react-hot-toast'
import styles from './PriorityPage.module.css'

// ─── UTC datetime helpers (same pattern as Dashboard) ─────────────────
function oneHourAgo() {
  return new Date(Date.now() - 60 * 60 * 1000).toISOString().slice(0, 16)
}
function nowUTC() {
  return new Date().toISOString().slice(0, 16)
}
/** Treat datetime-local string as UTC by appending Z directly */
function toISO(localStr) {
  if (!localStr) return null
  return localStr + ':00.000Z'
}

// ─── Date window filter bar ────────────────────────────────────────────
function DateWindowFilter({ from, to, onChange, onApply, loading, isDefault }) {
  return (
    <div className={styles.dateWindow}>
      <div className={styles.dateWindowLeft}>
        <Calendar size={14} className={styles.dateWindowIcon} />
        <span className={styles.dateWindowLabel}>Showing issues for</span>
        {isDefault && (
          <span className={styles.timeWindowBadge}>
            <Clock size={11} /> Last 1 hour
          </span>
        )}
      </div>

      <div className={styles.dateWindowControls}>
        <div className={styles.dateWindowField}>
          <label className={styles.dateWindowFieldLabel}>From (UTC)</label>
          <input
            type="datetime-local"
            className={styles.dateWindowInput}
            value={from}
            onChange={e => onChange('from', e.target.value)}
          />
        </div>
        <span className={styles.dateWindowSep}>→</span>
        <div className={styles.dateWindowField}>
          <label className={styles.dateWindowFieldLabel}>To (UTC)</label>
          <input
            type="datetime-local"
            className={styles.dateWindowInput}
            value={to}
            onChange={e => onChange('to', e.target.value)}
          />
        </div>

        <button
          className={`btn btn-primary btn-sm ${styles.applyBtn}`}
          onClick={onApply}
          disabled={loading}
        >
          {loading ? <Loader2 size={13} className={styles.spin} /> : <RefreshCw size={13} />}
          Apply
        </button>

        {!isDefault && (
          <button
            className="btn btn-ghost btn-sm"
            onClick={() => onChange('reset')}
            title="Reset to last 1 hour"
          >
            <RotateCcw size={13} /> Reset
          </button>
        )}
      </div>
    </div>
  )
}

// ─── Main page ─────────────────────────────────────────────────────────
export default function PriorityPage() {
  const navigate = useNavigate()

  // Date window — default last 1 hour, always UTC
  const [winFrom, setWinFrom] = useState(oneHourAgo)
  const [winTo,   setWinTo]   = useState(nowUTC)

  const isDefaultWindow = useMemo(() => {
    const fromDiff = Math.abs(new Date(winFrom + 'Z') - (Date.now() - 3600000))
    const toDiff   = Math.abs(new Date(winTo   + 'Z') - Date.now())
    return fromDiff < 120000 && toDiff < 120000
  }, [winFrom, winTo])

  const [issues,  setIssues]  = useState([])
  const [loading, setLoading] = useState(true)

  const load = async (fromStr, toStr) => {
    setLoading(true)
    try {
      const data = await ordersApi.getPriorityIssues(
        toISO(fromStr ?? winFrom),
        toISO(toStr   ?? winTo)
      )
      setIssues(data)
    } catch {
      toast.error('Failed to load priority issues')
    } finally {
      setLoading(false)
    }
  }

  // Initial load — default 1-hour window
  useEffect(() => { load(winFrom, winTo) }, [])

  const handleWindowChange = (field, value) => {
    if (field === 'reset') {
      const f = oneHourAgo()
      const t = nowUTC()
      setWinFrom(f)
      setWinTo(t)
      load(f, t)
    } else if (field === 'from') {
      setWinFrom(value)
    } else {
      setWinTo(value)
    }
  }

  const handleApply = () => load(winFrom, winTo)

  const askChatbot = (issue) => {
    // Pass structured state — ChatPage creates a new session and
    // pre-fills the input box without auto-sending
    navigate('/chat', {
      state: {
        orderId:   issue.orderId,
        exception: issue.exception,
      }
    })
  }

  const criticalCount = issues.filter(i => i.priority === 'CRITICAL').length
  const highCount     = issues.filter(i => i.priority === 'HIGH').length

  return (
    <div className={styles.root}>

      {/* ── Header ── */}
      <div className={styles.header}>
        <div className={styles.headerLeft}>
          <div className={styles.headerIcon}>
            <ShieldAlert size={20} />
          </div>
          <div>
            <h1 className={styles.title}>Priority Issues</h1>
            <p className={styles.subtitle}>
              Orders and jobs requiring immediate attention — API exceptions, max retries reached
            </p>
          </div>
        </div>
        <button className="btn btn-outline" onClick={handleApply} disabled={loading}>
          <RefreshCw size={14} className={loading ? styles.spin : ''} />
          Refresh
        </button>
      </div>

      {/* ── Date window filter ── */}
      <DateWindowFilter
        from={winFrom}
        to={winTo}
        onChange={handleWindowChange}
        onApply={handleApply}
        loading={loading}
        isDefault={isDefaultWindow}
      />

      {/* ── Content ── */}
      {loading ? (
        <div className={styles.loader}><Loader2 size={28} className={styles.spin} /></div>
      ) : issues.length === 0 ? (
        <div className={styles.emptyState}>
          <div className={styles.emptyIcon}><AlertTriangle size={32} /></div>
          <h3>No Priority Issues</h3>
          <p>
            {isDefaultWindow
              ? 'No issues in the last hour. All recent orders are operating normally.'
              : 'No issues found for the selected date range.'}
          </p>
        </div>
      ) : (
        <>
          {/* Summary bar */}
          <div className={styles.summary}>
            <span className="badge badge-error">
              <AlertTriangle size={10} />
              {issues.length} issue{issues.length !== 1 ? 's' : ''}
            </span>
            {criticalCount > 0 && (
              <span className="badge badge-error" style={{ background: '#7f1d1d' }}>
                {criticalCount} critical
              </span>
            )}
            {highCount > 0 && (
              <span className="badge badge-warning">
                {highCount} high
              </span>
            )}
            {!isDefaultWindow && (
              <span style={{ fontSize: 12, color: 'var(--text-muted)', marginLeft: 4 }}>
                in selected window
              </span>
            )}
          </div>

          {/* Issue cards */}
          <div className={styles.issueList}>
            {issues.map((issue, idx) => (
              <div
                key={idx}
                className={`card ${styles.issueCard} fade-in`}
                style={{ borderLeftColor: issue.priority === 'CRITICAL' ? 'var(--error)' : 'var(--warning)' }}
              >
                <div className={styles.issueHeader}>
                  <div className={styles.issueTitleRow}>
                    <span className={`badge ${priorityBadgeClass(issue.priority)}`}>
                      {issue.priority}
                    </span>
                    <span className={styles.issueOrderId}>{issue.orderId}</span>
                    {issue.fulfilmentId && (
                      <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                        · {issue.fulfilmentId}
                      </span>
                    )}
                    {issue.eventType && (
                      <span className={`badge ${issue.eventType === 'pickReport' ? 'badge-info' : 'badge-warning'}`}>
                        {issue.eventType}
                      </span>
                    )}
                  </div>
                  <div className={styles.issueActions}>
                    <span className={`badge ${statusBadgeClass(issue.status)}`}>{issue.status}</span>
                    <button className="btn btn-ghost btn-sm" onClick={() => askChatbot(issue)}>
                      <MessageSquare size={13} />
                      Resolve with CFC Agent
                    </button>
                  </div>
                </div>

                <div className={styles.issueBody}>
                  <div className={styles.issueField}>
                    <span className={styles.issueFieldLabel}>Source</span>
                    <code style={{ fontSize: 11 }}>{issue.source}</code>
                  </div>
                  <div className={styles.issueField}>
                    <span className={styles.issueFieldLabel}>Event ID</span>
                    <code style={{ fontSize: 11 }}>{issue.eventId}</code>
                  </div>
                  <div className={styles.issueField}>
                    <span className={styles.issueFieldLabel}>Retry Attempts</span>
                    <span className={`badge ${issue.retryAttempt >= 3 ? 'badge-error' : 'badge-warning'}`}>
                      {issue.retryAttempt}
                    </span>
                  </div>
                  {issue.eventDatetime && (
                    <div className={styles.issueField}>
                      <span className={styles.issueFieldLabel}>Event Time</span>
                      <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                        {formatDate(issue.eventDatetime)}
                      </span>
                    </div>
                  )}
                </div>

                {issue.exception && (
                  <div className={styles.issueException}>
                    <span className={styles.issueFieldLabel} style={{ flexShrink: 0 }}>Exception</span>
                    <code className={styles.exceptionText}>{issue.exception}</code>
                  </div>
                )}

                <div className={styles.issueFooter}>
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={() => navigate(`/orders?orderId=${issue.orderId}`)}
                  >
                    View Order Details
                  </button>
                  {/* <button
                    className="btn btn-outline btn-sm"
                    onClick={() => navigate('/remediation')}
                  >
                    View Remediation Docs
                  </button> */}
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
