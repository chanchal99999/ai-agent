import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { BotMessageSquare, Eye, EyeOff, Loader2, UserPlus } from 'lucide-react'
import { authApi } from '../services/api.js'
import toast from 'react-hot-toast'
import styles from './AuthPage.module.css'

export default function RegisterPage() {
  const navigate = useNavigate()

  const [form, setForm] = useState({
    username: '', email: '', password: '', confirmPassword: '',
    fullName: '', role: 'USER'
  })
  const [showPw, setShowPw]   = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState('')

  const set = (k, v) => { setForm(f => ({ ...f, [k]: v })); setError('') }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.username || !form.email || !form.password) {
      setError('Username, email and password are required')
      return
    }
    if (form.password.length < 6) {
      setError('Password must be at least 6 characters')
      return
    }
    if (form.password !== form.confirmPassword) {
      setError('Passwords do not match')
      return
    }
    const emailRx = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRx.test(form.email)) {
      setError('Please enter a valid email address')
      return
    }

    setLoading(true)
    setError('')
    try {
      await authApi.register({
        username: form.username,
        email:    form.email,
        password: form.password,
        fullName: form.fullName,
        role:     form.role,
      })
      toast.success('Account created! Please sign in.')
      navigate('/login')
    } catch (err) {
      const msg = err.response?.data?.error || 'Registration failed. Please try again.'
      setError(msg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={styles.root}>
      <div className={styles.card}>

        {/* Brand */}
        <div className={styles.brand}>
          <div className={styles.brandIcon}><BotMessageSquare size={28} /></div>
          <div>
            <div className={styles.brandName}>OpsBot</div>
            <div className={styles.brandSub}>E-Commerce Operations Support</div>
          </div>
        </div>

        <h1 className={styles.title}>Create your account</h1>
        <p className={styles.desc}>Join the operations platform</p>

        {error && <div className={styles.errorBanner}>{error}</div>}

        <form className={styles.form} onSubmit={handleSubmit}>

          <div className={styles.row}>
            <div className={styles.field}>
              <label className={styles.label}>Full Name</label>
              <input className={styles.input} type="text" placeholder="Jane Smith"
                value={form.fullName} onChange={e => set('fullName', e.target.value)}
                autoFocus disabled={loading} />
            </div>
            <div className={styles.field}>
              <label className={styles.label}>Username <span className={styles.req}>*</span></label>
              <input className={styles.input} type="text" placeholder="jsmith"
                value={form.username} onChange={e => set('username', e.target.value)}
                autoComplete="username" disabled={loading} />
            </div>
          </div>

          <div className={styles.field}>
            <label className={styles.label}>Email <span className={styles.req}>*</span></label>
            <input className={styles.input} type="email" placeholder="jane@company.com"
              value={form.email} onChange={e => set('email', e.target.value)}
              autoComplete="email" disabled={loading} />
          </div>

          <div className={styles.row}>
            <div className={styles.field}>
              <label className={styles.label}>Password <span className={styles.req}>*</span></label>
              <div className={styles.passwordWrap}>
                <input className={styles.input}
                  type={showPw ? 'text' : 'password'}
                  placeholder="Min. 6 characters"
                  value={form.password}
                  onChange={e => set('password', e.target.value)}
                  autoComplete="new-password" disabled={loading} />
                <button type="button" className={styles.eyeBtn}
                  onClick={() => setShowPw(v => !v)} tabIndex={-1}>
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <div className={styles.field}>
              <label className={styles.label}>Confirm Password <span className={styles.req}>*</span></label>
              <input className={styles.input}
                type={showPw ? 'text' : 'password'}
                placeholder="Repeat password"
                value={form.confirmPassword}
                onChange={e => set('confirmPassword', e.target.value)}
                autoComplete="new-password" disabled={loading} />
            </div>
          </div>

          <div className={styles.field}>
            <label className={styles.label}>Account Type</label>
            <div className={styles.roleCards}>
              {[
                { val: 'USER',  label: 'Standard User',  desc: 'View all data, use chat, view remediation docs' },
                { val: 'ADMIN', label: 'Administrator',   desc: 'All user permissions + upload, create and reindex docs' },
              ].map(r => (
                <label
                  key={r.val}
                  className={`${styles.roleCard} ${form.role === r.val ? styles.roleCardActive : ''}`}
                >
                  <input type="radio" name="role" value={r.val}
                    checked={form.role === r.val}
                    onChange={() => set('role', r.val)}
                    className={styles.roleRadio} />
                  <div>
                    <div className={styles.roleLabel}>{r.label}</div>
                    <div className={styles.roleDesc}>{r.desc}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <button type="submit"
            className={`btn btn-primary ${styles.submitBtn}`}
            disabled={loading}>
            {loading
              ? <><Loader2 size={16} className={styles.spin} /> Creating account…</>
              : <><UserPlus size={16} /> Create Account</>
            }
          </button>
        </form>

        <p className={styles.switchLink}>
          Already have an account?{' '}
          <Link to="/login" className={styles.link}>Sign in</Link>
        </p>
      </div>
    </div>
  )
}
