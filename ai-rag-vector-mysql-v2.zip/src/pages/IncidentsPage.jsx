import { useState, useEffect, useCallback } from 'react'
import {
  AlertTriangle, RefreshCw, CheckCircle, Clock, XCircle, Filter
} from 'lucide-react'
import { incidentApi } from '../services/api.js'
import { useAuth } from '../context/AuthContext.jsx'
import toast from 'react-hot-toast'

const STATUS_META = {
  OPEN:        { label: 'Open',        color: '#DC2626', icon: AlertTriangle },
  IN_PROGRESS: { label: 'In Progress', color: '#F0A500', icon: Clock },
  RESOLVED:    { label: 'Resolved',    color: '#16a34a', icon: CheckCircle },
  CLOSED:      { label: 'Closed',      color: '#64748B', icon: XCircle },
}

const SEVERITY_COLOR = {
  LOW: '#64748B', MEDIUM: '#2E75B6', HIGH: '#F0A500', CRITICAL: '#DC2626',
}

export default function IncidentsPage() {
  const { user } = useAuth()
  const role = user?.role
  const isOps = role === 'USER' || role === 'ADMIN'   // operations can update
  const [incidents, setIncidents] = useState([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('ALL')

  const load = useCallback(() => {
    setLoading(true)
    incidentApi.list()
      .then(setIncidents)
      .catch(() => toast.error('Failed to load incidents'))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => { load() }, [load])

  const updateStatus = async (incidentId, status) => {
    try {
      const updated = await incidentApi.update(incidentId, { status })
      setIncidents(prev => prev.map(i => i.incidentId === incidentId ? updated : i))
      toast.success(`Incident marked ${STATUS_META[status]?.label || status}`)
    } catch {
      toast.error('Failed to update incident')
    }
  }

  const filtered = statusFilter === 'ALL'
    ? incidents
    : incidents.filter(i => i.status === statusFilter)

  return (
    <div style={{ padding: 24, maxWidth: 1100, margin: '0 auto', width: '100%' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 700, margin: 0, display: 'flex', alignItems: 'center', gap: 8 }}>
            <AlertTriangle size={22} color="#DC2626" />
            Incidents
          </h1>
          <p style={{ color: '#64748B', margin: '4px 0 0', fontSize: 14 }}>
            {isOps
              ? 'All incidents raised by customer care for the operations team.'
              : 'Incidents you have raised for the operations team.'}
          </p>
        </div>
        <button onClick={load}
          style={{
            display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer',
            padding: '8px 14px', borderRadius: 8, border: '1px solid #E5E7EB',
            background: '#fff', fontSize: 13, fontWeight: 600, color: '#1F2937',
          }}>
          <RefreshCw size={14} /> Refresh
        </button>
      </div>

      {/* Status filter */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16, alignItems: 'center', flexWrap: 'wrap' }}>
        <Filter size={14} color="#64748B" />
        {['ALL', 'OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'].map(stt => (
          <button key={stt} onClick={() => setStatusFilter(stt)}
            style={{
              padding: '4px 12px', borderRadius: 16, fontSize: 12, fontWeight: 600,
              border: '1px solid', cursor: 'pointer',
              borderColor: statusFilter === stt ? '#2E75B6' : '#E5E7EB',
              background: statusFilter === stt ? '#2E75B6' : '#fff',
              color: statusFilter === stt ? '#fff' : '#64748B',
            }}>
            {stt === 'ALL' ? 'All' : STATUS_META[stt].label}
          </button>
        ))}
      </div>

      {loading && <div style={{ color: '#64748B', padding: 40, textAlign: 'center' }}>Loading…</div>}

      {!loading && filtered.length === 0 && (
        <div style={{ textAlign: 'center', padding: 60, color: '#64748B' }}>
          <AlertTriangle size={32} style={{ opacity: 0.4 }} />
          <p>No incidents to show.</p>
        </div>
      )}

      {!loading && filtered.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {filtered.map(inc => {
            const meta = STATUS_META[inc.status] || STATUS_META.OPEN
            const StatusIcon = meta.icon
            return (
              <div key={inc.incidentId}
                style={{
                  border: '1px solid #E5E7EB', borderRadius: 12, padding: 16,
                  background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
                }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 16 }}>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4, flexWrap: 'wrap' }}>
                      <span style={{ fontWeight: 700, fontSize: 16 }}>{inc.orderId}</span>
                      {inc.errorCode && (
                        <span style={{
                          fontSize: 11, fontWeight: 700, color: '#DC2626',
                          background: '#FEE2E2', padding: '2px 8px', borderRadius: 6,
                        }}>{inc.errorCode}</span>
                      )}
                      <span style={{
                        fontSize: 11, fontWeight: 700, color: '#fff',
                        background: SEVERITY_COLOR[inc.severity] || '#2E75B6',
                        padding: '2px 8px', borderRadius: 6,
                      }}>{inc.severity}</span>
                    </div>
                    {inc.description && (
                      <p style={{ margin: '4px 0', fontSize: 14, color: '#1F2937' }}>{inc.description}</p>
                    )}
                    <div style={{ fontSize: 12, color: '#64748B', marginTop: 6 }}>
                      Raised by <strong>{inc.raisedBy}</strong>
                      {inc.assignedTo && <> · Assigned to <strong>{inc.assignedTo}</strong></>}
                      {' · '}{inc.createdAt ? new Date(inc.createdAt).toLocaleString() : ''}
                    </div>
                    {inc.resolutionNotes && (
                      <div style={{ marginTop: 8, fontSize: 13, color: '#065F46', background: '#ECFDF5', padding: 8, borderRadius: 6 }}>
                        <strong>Resolution:</strong> {inc.resolutionNotes}
                      </div>
                    )}
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 8, flexShrink: 0 }}>
                    <span style={{
                      display: 'flex', alignItems: 'center', gap: 5,
                      fontSize: 12, fontWeight: 700, color: meta.color, whiteSpace: 'nowrap',
                    }}>
                      <StatusIcon size={14} /> {meta.label}
                    </span>

                    {/* Ops/admin can advance status */}
                    {isOps && inc.status !== 'CLOSED' && (
                      <div style={{ display: 'flex', gap: 6 }}>
                        {inc.status === 'OPEN' && (
                          <button onClick={() => updateStatus(inc.incidentId, 'IN_PROGRESS')}
                            style={{ fontSize: 11, background: '#F0A500', color: '#fff', border: 'none', padding: '4px 10px', borderRadius: 6, cursor: 'pointer', fontWeight: 600 }}>
                            Start
                          </button>
                        )}
                        {(inc.status === 'OPEN' || inc.status === 'IN_PROGRESS') && (
                          <button onClick={() => updateStatus(inc.incidentId, 'RESOLVED')}
                            style={{ fontSize: 11, background: '#16a34a', color: '#fff', border: 'none', padding: '4px 10px', borderRadius: 6, cursor: 'pointer', fontWeight: 600 }}>
                            Resolve
                          </button>
                        )}
                        {inc.status === 'RESOLVED' && (
                          <button onClick={() => updateStatus(inc.incidentId, 'CLOSED')}
                            style={{ fontSize: 11, background: '#64748B', color: '#fff', border: 'none', padding: '4px 10px', borderRadius: 6, cursor: 'pointer', fontWeight: 600 }}>
                            Close
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
