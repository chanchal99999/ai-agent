import { useState, useEffect, useRef } from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism'
import { oneDark }  from 'react-syntax-highlighter/dist/esm/styles/prism'
import {
  FileText, Plus, Upload, Trash2, Edit3, Download,
  RefreshCw, Loader2, Save, X, Tag, Search, Eye,
  FileCode, FileSpreadsheet, Image as ImageIcon,
  Copy, Check, ChevronDown, ChevronUp, FileImage,
  AlertCircle, FileJson
} from 'lucide-react'
import { remediationApi } from '../services/api.js'
import { useAuth } from '../context/AuthContext.jsx'
import { formatDate, truncate } from '../utils/helpers.js'
import toast from 'react-hot-toast'
import styles from './RemediationPage.module.css'

// ─── File-type detection ───────────────────────────────────────────────
const EXT_MAP = {
  pdf: 'pdf',
  md: 'markdown', markdown: 'markdown',
  png: 'image', jpg: 'image', jpeg: 'image', gif: 'image', webp: 'image', svg: 'image',
  txt: 'text', log: 'text', csv: 'text',
  json: 'json', yaml: 'yaml', yml: 'yaml', xml: 'xml',
  html: 'html', htm: 'html',
  sql: 'sql', sh: 'shell', bash: 'shell',
  py: 'python', js: 'javascript', ts: 'typescript',
  java: 'java', cs: 'csharp', go: 'go', rs: 'rust', php: 'php',
  docx: 'office', doc: 'office',
  xlsx: 'office', xls: 'office',
  pptx: 'office', ppt: 'office',
}
const CODE_LANGS = ['json','yaml','xml','html','sql','shell','python','javascript',
                    'typescript','java','csharp','go','rust','php']

function getFileCat(doc) {
  const mime = (doc.mimeType || '').toLowerCase()
  const ext  = doc.fileName ? doc.fileName.split('.').pop().toLowerCase() : ''
  if (EXT_MAP[ext]) return EXT_MAP[ext]
  if (mime === 'application/pdf')          return 'pdf'
  if (mime.startsWith('image/'))           return 'image'
  if (mime.startsWith('text/'))            return 'text'
  if (mime.includes('wordprocessing') || mime.includes('msword')) return 'office'
  if (mime.includes('spreadsheet') || mime.includes('excel'))     return 'office'
  if (mime.includes('presentation') || mime.includes('powerpoint')) return 'office'
  return 'other'
}

const CAT_COLORS = {
  pdf: '#e01a22', markdown: '#7c3aed', text: '#374151',
  image: '#059669', office: '#1d4ed8', json: '#d97706',
  yaml: '#0891b2', xml: '#6366f1', html: '#f97316',
  sql: '#0f766e', shell: '#374151', python: '#2563eb',
  javascript: '#ca8a04', typescript: '#1d4ed8',
  java: '#dc2626', other: '#6b7280',
}
const CAT_LABELS = {
  pdf: 'PDF', markdown: 'Markdown', text: 'Plain Text',
  image: 'Image', office: 'Office Document', json: 'JSON',
  yaml: 'YAML', xml: 'XML', html: 'HTML',
  sql: 'SQL', shell: 'Shell Script', python: 'Python',
  javascript: 'JavaScript', typescript: 'TypeScript',
  java: 'Java', other: 'Document',
}

function FileTypeIcon({ doc, size = 16 }) {
  const cat = getFileCat(doc)
  const color = CAT_COLORS[cat] || '#6b7280'
  const Icon  = cat === 'image' ? ImageIcon
              : CODE_LANGS.includes(cat) || cat === 'text' || cat === 'markdown' ? FileCode
              : cat === 'office' ? FileSpreadsheet
              : FileText
  return <Icon size={size} style={{ color }} />
}

// ─── Copy button ───────────────────────────────────────────────────────
function CopyBtn({ text, className = '' }) {
  const [copied, setCopied] = useState(false)
  const copy = () => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button className={`${styles.copyBtn} ${className}`} onClick={copy} title="Copy to clipboard">
      {copied ? <Check size={13} /> : <Copy size={13} />}
      {copied ? 'Copied' : 'Copy'}
    </button>
  )
}

// ─── Content renderers ─────────────────────────────────────────────────

// Markdown — proper rendered HTML
function MarkdownView({ content }) {
  return (
    <div className={styles.markdownBody}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          code({ inline, className, children }) {
            const match = /language-(\w+)/.exec(className || '')
            const code  = String(children).replace(/\n$/, '')
            if (!inline && match) {
              return (
                <div className={styles.codeBlock}>
                  <div className={styles.codeBlockHeader}>
                    <span className={styles.codeLang}>{match[1].toUpperCase()}</span>
                    <CopyBtn text={code} className={styles.copyBtnCode} />
                  </div>
                  <SyntaxHighlighter style={oneDark} language={match[1]} PreTag="div">
                    {code}
                  </SyntaxHighlighter>
                </div>
              )
            }
            return <code className={styles.inlineCode}>{children}</code>
          },
          table({ children }) {
            return (
              <div className={styles.tableWrap}>
                <table className="data-table">{children}</table>
              </div>
            )
          },
          blockquote({ children }) {
            return <blockquote className={styles.blockquote}>{children}</blockquote>
          },
          h1({ children }) { return <h1 className={styles.mdH1}>{children}</h1> },
          h2({ children }) { return <h2 className={styles.mdH2}>{children}</h2> },
          h3({ children }) { return <h3 className={styles.mdH3}>{children}</h3> },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  )
}

// Code / text with syntax highlighting
function CodeView({ content, language }) {
  const lang = CODE_LANGS.includes(language) ? language : 'text'
  return (
    <div className={styles.codeViewWrap}>
      <div className={styles.codeViewHeader}>
        <span className={styles.codeLangPill} style={{ background: CAT_COLORS[language] + '22', color: CAT_COLORS[language] || '#374151' }}>
          {CAT_LABELS[language] || language?.toUpperCase()}
        </span>
        <div className={styles.codeViewActions}>
          <span className={styles.lineCount}>{content.split('\n').length} lines</span>
          <CopyBtn text={content} />
        </div>
      </div>
      <SyntaxHighlighter
        style={oneDark}
        language={lang}
        showLineNumbers
        lineNumberStyle={{ color: '#4a5568', fontSize: 11, minWidth: 40 }}
        customStyle={{ margin: 0, borderRadius: 0, fontSize: 12, lineHeight: 1.6 }}
      >
        {content}
      </SyntaxHighlighter>
    </div>
  )
}

// Plain text with nice formatting
function PlainTextView({ content }) {
  return (
    <div className={styles.plainTextWrap}>
      <div className={styles.plainTextHeader}>
        <span className={styles.codeLangPill} style={{ background: '#f3f4f6', color: '#374151' }}>
          Plain Text
        </span>
        <div className={styles.codeViewActions}>
          <span className={styles.lineCount}>{content.split('\n').length} lines</span>
          <CopyBtn text={content} />
        </div>
      </div>
      <pre className={styles.plainTextBody}>{content}</pre>
    </div>
  )
}

// Extracted Office / PDF text — formatted as a document
function ExtractedTextView({ content, doc }) {
  // Split into paragraphs for better readability
  const paragraphs = content
    .split(/\n{2,}/)
    .map(p => p.trim())
    .filter(Boolean)

  return (
    <div className={styles.extractedWrap}>
      <div className={styles.extractedNotice}>
        <FileText size={13} />
        <span>Text extracted from <strong>{doc.fileName || 'document'}</strong> — formatting may differ from original</span>
        <CopyBtn text={content} className={styles.extractedCopy} />
      </div>
      <div className={styles.extractedBody}>
        {paragraphs.map((para, i) => (
          <p key={i} className={styles.extractedPara}>{para}</p>
        ))}
      </div>
    </div>
  )
}

// Image viewer
function ImageView({ doc, downloadUrl }) {
  return (
    <div className={styles.imageViewWrap}>
      <img
        src={downloadUrl}
        alt={doc.title}
        className={styles.imageViewImg}
        onError={e => { e.target.style.display = 'none' }}
      />
      <p className={styles.imageCaption}>{doc.fileName}</p>
    </div>
  )
}

// PDF viewer
function PdfView({ downloadUrl, doc }) {
  return (
    <div className={styles.pdfWrap}>
      <iframe
        src={`${downloadUrl}#toolbar=1&view=FitH`}
        className={styles.pdfFrame}
        title={doc.title}
      />
    </div>
  )
}

// Binary / unsupported placeholder
function PlaceholderView({ content, downloadUrl, doc }) {
  return (
    <div className={styles.placeholderWrap}>
      <div className={styles.placeholderIcon}>
        <FileText size={40} style={{ color: 'var(--border-strong)' }} />
      </div>
      <p className={styles.placeholderMsg}>{content}</p>
      {downloadUrl && (
        <a className="btn btn-primary" href={downloadUrl} download={doc.fileName}>
          <Download size={14} />
          Download {doc.fileName}
        </a>
      )}
    </div>
  )
}

// ─── View Modal ────────────────────────────────────────────────────────
function ViewModal({ doc, onClose }) {
  const cat         = getFileCat(doc)
  const downloadUrl = doc.fileName ? remediationApi.getDownloadUrl(doc.documentId) : null
  const isPlaceholder = doc.content?.startsWith('[') && doc.content?.endsWith(']')
  const color       = CAT_COLORS[cat] || '#6b7280'
  const label       = CAT_LABELS[cat] || 'Document'

  useEffect(() => {
    const h = (e) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [onClose])

  const renderContent = () => {
    if (isPlaceholder) {
      return <PlaceholderView content={doc.content} downloadUrl={downloadUrl} doc={doc} />
    }
    if (cat === 'image')    return <ImageView doc={doc} downloadUrl={downloadUrl} />
    if (cat === 'pdf')      return <PdfView downloadUrl={downloadUrl} doc={doc} />
    if (cat === 'markdown') return <MarkdownView content={doc.content} />
    if (cat === 'office')   return <ExtractedTextView content={doc.content} doc={doc} />
    if (cat === 'text')     return <PlainTextView content={doc.content} />
    if (CODE_LANGS.includes(cat)) return <CodeView content={doc.content} language={cat} />
    // fallback — extracted text
    return <ExtractedTextView content={doc.content || ''} doc={doc} />
  }

  return (
    <div className={styles.modalOverlay} onClick={onClose}>
      <div className={`${styles.modal} ${styles.viewModal}`} onClick={e => e.stopPropagation()}>

        {/* ── Header ── */}
        <div className={styles.viewHeader} style={{ borderBottomColor: color + '40' }}>
          <div className={styles.viewHeaderLeft}>
            <div className={styles.viewHeaderIcon} style={{ background: color + '18', color }}>
              <FileTypeIcon doc={doc} size={16} />
            </div>
            <div className={styles.viewHeaderText}>
              <h2 className={styles.viewHeaderTitle}>{doc.title}</h2>
              <div className={styles.viewHeaderMeta}>
                <span className={styles.viewTypePill} style={{ background: color + '15', color, borderColor: color + '30' }}>
                  {label}
                </span>
                {doc.fileName && (
                  <span className={styles.viewFileNamePill}>{doc.fileName}</span>
                )}
                {doc.errorCode && <span className="badge badge-error">{doc.errorCode}</span>}
                {doc.errorType && <span className="badge badge-warning">{doc.errorType}</span>}
              </div>
            </div>
          </div>
          <div className={styles.viewHeaderRight}>
            {downloadUrl && (
              <a className="btn btn-outline btn-sm" href={downloadUrl} download={doc.fileName}
                onClick={e => e.stopPropagation()}>
                <Download size={13} /> Download
              </a>
            )}
            <button className={styles.viewCloseBtn} onClick={onClose}><X size={15} /></button>
          </div>
        </div>

        {/* ── Metadata strip ── */}
        <div className={styles.viewMeta}>
          <span className={styles.viewMetaItem}>
            <strong>Uploaded by</strong> {doc.uploadedBy || '—'}
          </span>
          <span className={styles.viewMetaItem}>
            <strong>Created</strong> {formatDate(doc.createdAt)}
          </span>
          {doc.mimeType && (
            <span className={styles.viewMetaItem}>
              <strong>MIME</strong>
              <code className={styles.viewMetaCode}>{doc.mimeType}</code>
            </span>
          )}
          {doc.tags?.length > 0 && (
            <span className={styles.viewMetaTags}>
              {doc.tags.map(t => (
                <span key={t} className={styles.tag}><Tag size={9} />{t}</span>
              ))}
            </span>
          )}
        </div>

        {/* ── Content ── */}
        <div className={styles.viewContent}>
          {renderContent()}
        </div>
      </div>
    </div>
  )
}

// ─── Edit / Create Modal ───────────────────────────────────────────────
const EMPTY_FORM = {
  title: '', errorCode: '', errorType: '', content: '',
  uploadedBy: 'support-team', tags: ''
}

function DocModal({ doc, onClose, onSaved }) {
  const [form, setForm] = useState(doc ? {
    title:      doc.title      || '',
    errorCode:  doc.errorCode  || '',
    errorType:  doc.errorType  || '',
    content:    doc.content    || '',
    uploadedBy: doc.uploadedBy || 'support-team',
    tags:       (doc.tags || []).join(', ')
  } : EMPTY_FORM)
  const [saving, setSaving] = useState(false)
  const isEdit = !!doc

  const save = async () => {
    if (!form.title.trim() || !form.content.trim()) {
      toast.error('Title and content are required')
      return
    }
    setSaving(true)
    try {
      const payload = {
        ...form,
        tags: form.tags ? form.tags.split(',').map(t => t.trim()).filter(Boolean) : []
      }
      if (isEdit) {
        await remediationApi.update(doc.documentId, payload)
        toast.success('Document updated')
      } else {
        await remediationApi.create(payload)
        toast.success('Document created')
      }
      onSaved()
    } catch {
      toast.error('Failed to save document')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className={styles.modalOverlay} onClick={onClose}>
      <div className={styles.modal} onClick={e => e.stopPropagation()}>
        <div className={styles.modalHeader}>
          <h2 className={styles.modalTitle}>{isEdit ? 'Edit Document' : 'New Remediation Document'}</h2>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><X size={16} /></button>
        </div>
        <div className={styles.modalBody}>
          <div className={styles.formRow}>
            <label className={styles.label}>Title *</label>
            <input className="input" value={form.title}
              onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              placeholder="e.g. Fulfilment API Error Resolution Guide" />
          </div>
          <div className={styles.formGrid}>
            <div>
              <label className={styles.label}>Error Code</label>
              <input className="input" value={form.errorCode}
                onChange={e => setForm(f => ({ ...f, errorCode: e.target.value }))}
                placeholder="e.g. ACC-API-FUL-ERROR" />
            </div>
            <div>
              <label className={styles.label}>Error Type</label>
              <input className="input" value={form.errorType}
                onChange={e => setForm(f => ({ ...f, errorType: e.target.value }))}
                placeholder="e.g. API_EXCEPTION" />
            </div>
          </div>
          <div>
            <label className={styles.label}>Uploaded By</label>
            <input className="input" value={form.uploadedBy}
              onChange={e => setForm(f => ({ ...f, uploadedBy: e.target.value }))}
              placeholder="support-team" />
          </div>
          <div>
            <label className={styles.label}>Tags (comma-separated)</label>
            <input className="input" value={form.tags}
              onChange={e => setForm(f => ({ ...f, tags: e.target.value }))}
              placeholder="e.g. api-error, fulfilment, critical" />
          </div>
          <div>
            <label className={styles.label}>Content (Markdown) *</label>
            <textarea className="input" rows={14} value={form.content}
              onChange={e => setForm(f => ({ ...f, content: e.target.value }))}
              placeholder="## Resolution Steps&#10;&#10;1. Check API health...&#10;2. Retry..." />
          </div>
        </div>
        <div className={styles.modalFooter}>
          <button className="btn btn-outline" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>
            {saving ? <Loader2 size={14} className={styles.spin} /> : <Save size={14} />}
            {isEdit ? 'Save Changes' : 'Create Document'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Main page ─────────────────────────────────────────────────────────
export default function RemediationPage() {
  const [docs, setDocs]           = useState([])
  const [loading, setLoading]     = useState(true)
  const [search, setSearch]       = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editDoc, setEditDoc]     = useState(null)
  const [viewDoc, setViewDoc]     = useState(null)
  const { isAdmin } = useAuth()
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef()

  const load = async () => {
    setLoading(true)
    try {
      const data = await remediationApi.getAll()
      setDocs(data)
    } catch {
      toast.error('Failed to load documents')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const handleDownload = async (doc) => {
    try {
      const token = localStorage.getItem('ecom_ops_token')
      const resp = await fetch(`/api/remediation/${doc.documentId}/download`, {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      if (!resp.ok) { toast.error('Download failed'); return }
      const blob = await resp.blob()
      const url  = URL.createObjectURL(blob)
      const a    = document.createElement('a')
      a.href = url; a.download = doc.fileName || 'document'
      document.body.appendChild(a); a.click()
      document.body.removeChild(a); URL.revokeObjectURL(url)
    } catch { toast.error('Download failed') }
  }

  const handleDelete = async (docId) => {
    if (!confirm('Delete this document?')) return
    try {
      await remediationApi.delete(docId)
      toast.success('Document deleted')
      load()
    } catch {
      toast.error('Failed to delete')
    }
  }

  const handleFileUpload = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('title', file.name.replace(/\.[^.]+$/, ''))
      fd.append('uploadedBy', 'support-team')
      await remediationApi.uploadFile(fd)
      toast.success(`Uploaded: ${file.name}`)
      load()
    } catch {
      toast.error('Upload failed')
    } finally {
      setUploading(false)
      e.target.value = ''
    }
  }

  const handleReindex = async () => {
    try {
      await remediationApi.reindex()
      toast.success('Vector index refreshed')
    } catch {
      toast.error('Reindex failed')
    }
  }

  const filtered = docs.filter(d =>
    !search ||
    d.title?.toLowerCase().includes(search.toLowerCase()) ||
    d.errorCode?.toLowerCase().includes(search.toLowerCase()) ||
    d.errorType?.toLowerCase().includes(search.toLowerCase()) ||
    d.fileName?.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className={styles.root}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Supporting Documents</h1>
		  {isAdmin && (
          <p className={styles.subtitle}>
            Upload any file type — PDF, Word, Excel, Markdown, images, code and more
          </p>
		  )}
        </div>
        <div className={styles.headerActions}>
          {isAdmin && (
            <>
              <button className="btn btn-outline btn-sm" onClick={handleReindex}>
                <RefreshCw size={13} /> Reindex AI
              </button>
              <input ref={fileRef} type="file" style={{ display: 'none' }} onChange={handleFileUpload} />
              <button className="btn btn-outline" onClick={() => fileRef.current?.click()} disabled={uploading}>
                {uploading ? <Loader2 size={14} className={styles.spin} /> : <Upload size={14} />}
                Upload File
              </button>
              <button className="btn btn-primary" onClick={() => { setEditDoc(null); setShowModal(true) }}>
                <Plus size={14} /> New Document
              </button>
            </>
          )}
        </div>
      </div>

      <div className={styles.searchBar}>
        <div className={styles.searchWrap}>
          <Search size={14} className={styles.searchIcon} />
          <input className={styles.searchInput}
            placeholder="Search by title, error code, type or filename…"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <span className={styles.count}>{filtered.length} Document{filtered.length !== 1 ? 's' : ''}</span>
      </div>

      {loading ? (
        <div className={styles.loader}><Loader2 size={24} className={styles.spin} /></div>
      ) : filtered.length === 0 ? (
        <div className={styles.emptyState}>
          <FileText size={36} style={{ color: 'var(--border-strong)' }} />
          <p>No documents found</p>
        </div>
      ) : (
        <div className={styles.docGrid}>
          {filtered.map(doc => {
            const cat   = getFileCat(doc)
            const color = CAT_COLORS[cat] || '#6b7280'
            const label = CAT_LABELS[cat] || 'File'
            return (
              <div key={doc.documentId} className={`card ${styles.docCard} fade-in`}>
                <div className={styles.docCardHeader}>
                  <div className={styles.docCardIcon} style={{ background: color + '15', color }}>
                    <FileTypeIcon doc={doc} size={16} />
                  </div>
                  <div className={styles.docCardMeta}>
                    <h3 className={styles.docCardTitle}>{doc.title}</h3>
                    <div className={styles.docCardBadges}>
                      <span className={styles.fileTypeBadge} style={{ background: color + '12', color, borderColor: color + '30' }}>
                        {label}
                      </span>
                      {doc.errorCode && <span className="badge badge-error">{doc.errorCode}</span>}
                      {doc.errorType && <span className="badge badge-warning">{doc.errorType}</span>}
                    </div>
                  </div>
                </div>

                {doc.fileName && (
                  <div className={styles.fileNameRow}>
                    <FileTypeIcon doc={doc} size={11} />
                    <span className={styles.fileNameText}>{doc.fileName}</span>
                  </div>
                )}

                <p className={styles.docPreview}>
                  {truncate(doc.content?.replace(/^#+\s*/gm, '').replace(/\[.*?\]/g, '').trim(), 130)}
                </p>

                {doc.tags?.length > 0 && (
                  <div className={styles.tagRow}>
                    {doc.tags.map(t => <span key={t} className={styles.tag}><Tag size={9} />{t}</span>)}
                  </div>
                )}

                <div className={styles.docCardFooter}>
                  <span className={styles.docDate}>{formatDate(doc.createdAt)}</span>
                  <div className={styles.docActions}>
                    <button className="btn btn-ghost btn-sm btn-icon" onClick={() => setViewDoc(doc)} title="View content">
                      <Eye size={13} />
                    </button>
                    {isAdmin && (
                      <button className="btn btn-ghost btn-sm btn-icon"
                        onClick={() => { setEditDoc(doc); setShowModal(true) }} title="Edit">
                        <Edit3 size={13} />
                      </button>
                    )}
                    {doc.fileName && (
                      <button className="btn btn-ghost btn-sm btn-icon"
                        title="Download"
                        onClick={() => handleDownload(doc)}>
                        <Download size={13} />
                      </button>
                    )}
                    {isAdmin && (
                      <button className="btn btn-ghost btn-sm btn-icon"
                        onClick={() => handleDelete(doc.documentId)} title="Delete"
                        style={{ color: 'var(--error)' }}>
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {showModal && (
        <DocModal doc={editDoc}
          onClose={() => { setShowModal(false); setEditDoc(null) }}
          onSaved={() => { setShowModal(false); setEditDoc(null); load() }}
        />
      )}
      {viewDoc && <ViewModal doc={viewDoc} onClose={() => setViewDoc(null)} />}
    </div>
  )
}
