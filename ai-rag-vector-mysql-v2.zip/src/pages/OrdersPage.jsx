import { useState, useEffect, useCallback } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import {
  Search, Package, AlertCircle, CheckCircle2,
  Truck, ShoppingBag, Loader2, MessageSquare,
  ShoppingCart, ClipboardList, X
} from 'lucide-react'
import { ordersApi } from '../services/api.js'
import { formatDate, statusBadgeClass } from '../utils/helpers.js'
import toast from 'react-hot-toast'
import styles from './OrdersPage.module.css'

// ─── Helpers ──────────────────────────────────────────────────────────
function prettyJson(raw) {
  if (!raw) return ''
  try { return JSON.stringify(JSON.parse(raw), null, 2) }
  catch { return String(raw) }
}

// ─── JSON Payload Modal ────────────────────────────────────────────────
function PayloadModal({ title, icon: Icon, color, raw, onClose }) {
  const pretty = prettyJson(raw)

  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  return (
    <div className={styles.modalOverlay} onClick={onClose}>
      <div className={styles.modal} onClick={e => e.stopPropagation()}>
        <div className={styles.modalHeader} style={{ borderBottomColor: color + '44' }}>
          <div className={styles.modalTitleRow}>
            <span className={styles.modalIconWrap} style={{ background: color + '18', color }}>
              <Icon size={15} />
            </span>
            <span className={styles.modalTitle}>{title}</span>
          </div>
          <div className={styles.modalHeaderRight}>
            <button
              className="btn btn-outline btn-sm"
              onClick={() => { navigator.clipboard.writeText(pretty); toast.success('Copied!') }}
            >
              Copy JSON
            </button>
            <button className={styles.modalClose} onClick={onClose}><X size={15} /></button>
          </div>
        </div>
        <div className={styles.modalBody}>
          {pretty
            ? <pre className={styles.jsonPre}>{pretty}</pre>
            : <p className={styles.modalEmpty}>No payload data available</p>}
        </div>
      </div>
    </div>
  )
}

// ─── Payload button ────────────────────────────────────────────────────
function PayloadBtn({ label, icon: Icon, color, raw, onClick }) {
  const has = !!raw
  return (
    <button
      className={`${styles.payloadBtn} ${!has ? styles.payloadBtnEmpty : ''}`}
      style={has ? { '--pb': color } : {}}
      disabled={!has}
      onClick={has ? onClick : undefined}
      title={has ? `View ${label}` : `${label} not available`}
    >
      <Icon size={12} />
      <span>{label}</span>
    </button>
  )
}

// ─── Retry badge ───────────────────────────────────────────────────────
function RetryBadge({ n }) {
  const v = n ?? 0
  if (v >= 3) return <span className="badge badge-error">{v}</span>
  if (v > 0)  return <span className="badge badge-warning">{v}</span>
  return <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>0</span>
}

// ─── Order card ────────────────────────────────────────────────────────
function OrderCard({ summary }) {
  const navigate = useNavigate()
  const [modal, setModal] = useState(null)

  const openModal = useCallback((title, icon, color, raw) =>
    setModal({ title, icon, color, raw }), [])

  return (
    <div className={`card ${styles.orderCard} fade-in`}>

      {/* ── Header ── */}
      <div className={styles.orderCardHeader}>
        <div className={styles.orderCardTitle}>
          <Package size={16} />
          <span>{summary.orderId}</span>
          {summary.hasPriorityIssue && (
            <span className="badge badge-error">⚠ Priority Issue</span>
          )}
        </div>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate('/chat', { state: { orderId: summary.orderId } })}>
          <MessageSquare size={13} />
          Ask CFC Agent
        </button>
      </div>

      {/* ── Status strip ── */}
      <div className={styles.orderStatusRow}>
        <div className={styles.statusItem}>
          <ShoppingBag size={13} />
          <span>Fulfilment</span>
          <span className={`badge ${statusBadgeClass(summary.fulfilmentStatus)}`}>
            {summary.fulfilmentStatus}
          </span>
        </div>
        <div className={styles.statusItem}>
          <CheckCircle2 size={13} />
          <span>Pick Report</span>
          <span className={`badge ${statusBadgeClass(summary.pickStatus)}`}>
            {summary.pickStatus}
          </span>
        </div>
        <div className={styles.statusItem}>
          <Truck size={13} />
          <span>Delivery Report</span>
          <span className={`badge ${statusBadgeClass(summary.deliveryStatus)}`}>
            {summary.deliveryStatus}
          </span>
        </div>
        {summary.fulfilmentId && (
          <div className={styles.statusItem}>
            <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>Fulfilment ID</span>
            <code style={{ fontSize: 11 }}>{summary.fulfilmentId}</code>
          </div>
        )}
      </div>

      {/* ── Errors ── */}
      {summary.errors?.length > 0 && (
        <div className={styles.errorsBox}>
          <AlertCircle size={13} style={{ flexShrink: 0 }} />
          <div>
            {summary.errors.map((err, i) => (
              <div key={i} className={styles.errorLine}>{err}</div>
            ))}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════
           TABLE 1 — Manage Fulfilment Events
           Includes: ORDER_REQUEST payload button
      ══════════════════════════════════════════════════════════ */}
      {summary.manageEvents?.length > 0 && (
        <div className={styles.subSection}>
          <div className={styles.subTitle}>Manage Fulfilment Events</div>
          <div className={styles.tableScroll}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Event ID</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th>Retry</th>
                  <th>ORDER_REQUEST</th>
                  <th>Date &amp; Time</th>
                </tr>
              </thead>
              <tbody>
                {summary.manageEvents.map(e => (
                  <tr key={e.eventId}>
                    <td><code style={{ fontSize: 11 }}>{e.eventId}</code></td>
                    <td>
                      <span className="badge badge-info">{e.eventType}</span>
                    </td>
                    <td>
                      <span className={`badge ${statusBadgeClass(e.operationStatus)}`}>
                        {e.operationStatus}
                      </span>
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      <RetryBadge n={e.retryAttempt} />
                    </td>
                    <td>
                      <PayloadBtn
                        label="View Order Request"
                        icon={ShoppingCart}
                        color="#2563eb"
                        raw={e.orderRequest}
                        onClick={() => openModal(
                          `Order Request — ${e.orderId}`,
                          ShoppingCart, '#2563eb', e.orderRequest
                        )}
                      />
                    </td>
                    <td style={{ fontSize: 11, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                      {formatDate(e.eventDatetime)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════
           TABLE 2 — Fulfilment Job Events
           Includes: ENRICHED_PAYLOAD column for pick / delivery
      ══════════════════════════════════════════════════════════ */}
      {summary.fulfilmentEvents?.length > 0 && (
        <div className={styles.subSection}>
          <div className={styles.subTitle}>Fulfilment Job Events</div>
          <div className={styles.tableScroll}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Event ID</th>
                  <th>Type</th>
                  <th>Fulfilment ID</th>
                  <th>Status</th>
                  <th>Retry</th>
                  <th>ENRICHED_PAYLOAD</th>
                  <th>Exception</th>
                  <th>Date &amp; Time</th>
                </tr>
              </thead>
              <tbody>
                {summary.fulfilmentEvents.map(e => {
                  const isPick     = e.eventType === 'pickReport'
                  const isDelivery = e.eventType === 'deliveryReport'
                  return (
                    <tr key={e.eventId}>
                      <td><code style={{ fontSize: 11 }}>{e.eventId}</code></td>
                      <td>
                        <span className={`badge ${
                          isPick ? 'badge-info' : isDelivery ? 'badge-warning' : 'badge-muted'
                        }`}>
                          {e.eventType}
                        </span>
                      </td>
                      <td><code style={{ fontSize: 11 }}>{e.fulfilmentId}</code></td>
                      <td>
                        <span className={`badge ${statusBadgeClass(e.operationStatus)}`}>
                          {e.operationStatus}
                        </span>
                      </td>
                      <td style={{ textAlign: 'center' }}>
                        <RetryBadge n={e.retryAttempt} />
                      </td>

                      {/* ── ENRICHED_PAYLOAD cell ── */}
                      <td>
                        {isPick && (
                          <PayloadBtn
                            label="Picked Items"
                            icon={ClipboardList}
                            color="#0891b2"
                            raw={e.enrichRequest}
                            onClick={() => openModal(
                              `Picked Items — ${summary.orderId} (${e.fulfilmentId})`,
                              ClipboardList, '#0891b2', e.enrichRequest
                            )}
                          />
                        )}
                        {isDelivery && (
                          <PayloadBtn
                            label="Delivered Items"
                            icon={Truck}
                            color="#16a34a"
                            raw={e.enrichRequest}
                            onClick={() => openModal(
                              `Delivered Items — ${summary.orderId} (${e.fulfilmentId})`,
                              Truck, '#16a34a', e.enrichRequest
                            )}
                          />
                        )}
                        {!isPick && !isDelivery && (
                          <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>—</span>
                        )}
                      </td>

                      <td>
                        {e.exception
                          ? <span
                              className={styles.exceptionText}
                              title={e.exception}
                            >
                              {e.exception.length > 50
                                ? e.exception.substring(0, 47) + '…'
                                : e.exception}
                            </span>
                          : <span style={{ color: 'var(--text-muted)' }}>—</span>}
                      </td>
                      <td style={{ fontSize: 11, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                        {formatDate(e.eventDatetime)}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── JSON Payload Modal ── */}
      {modal && (
        <PayloadModal
          title={modal.title}
          icon={modal.icon}
          color={modal.color}
          raw={modal.raw}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  )
}

// ─── Sample orders ─────────────────────────────────────────────────────
const SAMPLE_ORDERS = ['ORD-123456', 'ORD-123457', 'ORD-123458', 'ORD-123459']

// ─── Main page ─────────────────────────────────────────────────────────
export default function OrdersPage() {
  const [searchParams] = useSearchParams()
  const [search, setSearch] = useState(searchParams.get('orderId') || '')
  const [summary, setSummary] = useState(null)
  const [loading, setLoading] = useState(false)

  const lookup = async (id) => {
    const orderId = (id || search).trim().toUpperCase()
    if (!orderId) return
    setLoading(true)
    setSummary(null)
    try {
      const data = await ordersApi.getOrder(orderId)
      setSummary(data)
    } catch {
      toast.error(`Order ${orderId} not found`)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const id = searchParams.get('orderId')
    if (id) { setSearch(id); lookup(id) }
  }, [])

  const handleKey = (e) => {
    if (e.key === 'Enter') lookup()
  }

  return (
    <div className={styles.root}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Orders</h1>
          <p className={styles.subtitle}>Look up order status, pick reports, and delivery reports</p>
        </div>
      </div>

      <div className={styles.searchBar}>
        <div className={styles.searchWrap}>
          <Search size={15} className={styles.searchIcon} />
          <input
            className={styles.searchInput}
            placeholder="Enter Order ID (e.g. ORD-123456)"
            value={search}
            onChange={e => setSearch(e.target.value)}
            onKeyDown={handleKey}
          />
        </div>
        <button
          className="btn btn-primary"
          onClick={() => lookup()}
          disabled={loading || !search.trim()}
        >
          {loading ? <Loader2 size={14} className={styles.spin} /> : <Search size={14} />}
          Lookup
        </button>
      </div>

      <div className={styles.quickLinks}>
        <span className={styles.quickLabel}>Quick lookup:</span>
        {SAMPLE_ORDERS.map(id => (
          <button
            key={id}
            className="btn btn-outline btn-sm"
            onClick={() => { setSearch(id); lookup(id) }}
          >
            {id}
          </button>
        ))}
      </div>

      {loading && (
        <div className={styles.loader}><Loader2 size={24} className={styles.spin} /></div>
      )}

      {!loading && summary && <OrderCard summary={summary} />}

      {!loading && !summary && (
        <div className={styles.emptyState}>
          <Package size={40} style={{ color: 'var(--border-strong)' }} />
          <p>Enter an Order ID to view fulfilment details</p>
        </div>
      )}
    </div>
  )
}
