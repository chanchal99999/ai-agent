import { useState, useEffect, useMemo, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Package, AlertTriangle, CheckCircle2, XCircle, TrendingUp,
  Loader2, RefreshCw, ChevronRight, Filter, X, ChevronDown,
  ChevronUp, Search, ShoppingCart, Truck, Clock,
  ClipboardList, Calendar, RotateCcw, FileJson
} from 'lucide-react'
import { ordersApi } from '../services/api.js'
import { formatDate, statusBadgeClass } from '../utils/helpers.js'
import toast from 'react-hot-toast'
import styles from './DashboardPage.module.css'

// ─── Helpers ──────────────────────────────────────────────────────────
function uniqueVals(rows, key) {
  return [...new Set(rows.map(r => r[key]).filter(Boolean))].sort()
}
function countActive(f) {
  return Object.values(f).filter(v => v !== '').length
}
const EMPTY_TABLE_F = {
  status: '', eventType: '', search: '', hasException: '', minRetry: ''
}

// ─── UTC datetime helpers ─────────────────────────────────────────────
// The datetime-local input has NO timezone context.
// We always treat it as UTC by appending "Z" when converting to ISO.
// The displayed value in the input is always UTC time.

/** Returns a UTC-based datetime-local string (YYYY-MM-DDTHH:mm) for 1 hour ago */
function oneHourAgo() {
  return new Date(Date.now() - 60 * 60 * 1000).toISOString().slice(0, 16)
}

/** Returns a UTC-based datetime-local string (YYYY-MM-DDTHH:mm) for now */
function nowLocal() {
  return new Date().toISOString().slice(0, 16)
}

/**
 * Convert a datetime-local string to a UTC ISO-8601 string for the API.
 * IMPORTANT: datetime-local has no timezone info. We always interpret it
 * as UTC by appending "Z" directly — never use new Date(str) alone because
 * browsers parse timezone-less strings as LOCAL time (e.g. IST = UTC+5:30),
 * which would shift the value by +5:30 when sent to the backend.
 */
function toISO(localStr) {
  if (!localStr) return null
  // Append Z to treat the datetime-local value as UTC explicitly
  return localStr + ':00.000Z'
}

function prettyJson(raw) {
  if (!raw) return ''
  try { return JSON.stringify(JSON.parse(raw), null, 2) }
  catch { return raw }
}

// ─── JSON Payload Modal ────────────────────────────────────────────────
function PayloadModal({ title, icon: Icon, color, raw, onClose }) {
  const pretty = prettyJson(raw)
  const copyAll = () => { navigator.clipboard.writeText(pretty); toast.success('Copied!') }
  return (
    <div className={styles.modalOverlay} onClick={onClose}>
      <div className={styles.modal} onClick={e => e.stopPropagation()}>
        <div className={styles.modalHeader} style={{ borderBottomColor: color + '55' }}>
          <div className={styles.modalTitleRow}>
            <span className={styles.modalIconWrap} style={{ background: color + '18', color }}>
              <Icon size={15} />
            </span>
            <span className={styles.modalTitle}>{title}</span>
          </div>
          <div className={styles.modalHeaderRight}>
            <button className="btn btn-outline btn-sm" onClick={copyAll}>Copy JSON</button>
            <button className={styles.modalClose} onClick={onClose}><X size={15} /></button>
          </div>
        </div>
        <div className={styles.modalBody}>
          {pretty
            ? <pre className={styles.jsonPre}>{pretty}</pre>
            : <p className={styles.modalEmpty}>No payload data available</p>}
        </div>
      </div>
    </div>
  )
}

// ─── Payload button ────────────────────────────────────────────────────
function PayloadBtn({ label, icon: Icon, color, raw, onClick }) {
  const has = !!raw
  return (
    <button
      className={`${styles.payloadBtn} ${!has ? styles.payloadBtnEmpty : ''}`}
      style={has ? { '--pb-color': color } : {}}
      onClick={has ? onClick : undefined}
      disabled={!has}
      title={has ? `View ${label}` : `${label} not available`}
    >
      <Icon size={12} />
      <span>{label}</span>
    </button>
  )
}

// ─── Stat card ─────────────────────────────────────────────────────────
function StatCard({ icon: Icon, label, value, color, onClick }) {
  return (
    <div
      className={`${styles.statCard} ${onClick ? styles.statCardClickable : ''}`}
      onClick={onClick}
    >
      <div className={styles.statIcon} style={{ background: color + '18', color }}>
        <Icon size={20} />
      </div>
      <div className={styles.statBody}>
        <div className={styles.statValue}>{value ?? '—'}</div>
        <div className={styles.statLabel}>{label}</div>
      </div>
      {onClick && <ChevronRight size={14} className={styles.statArrow} />}
    </div>
  )
}

// ─── Global date window filter (for stat cards + table data) ──────────
function DateWindowFilter({ from, to, onChange, onApply, loading, isDefault }) {
  return (
    <div className={styles.dateWindow}>
      <div className={styles.dateWindowLeft}>
        <Calendar size={14} className={styles.dateWindowIcon} />
        <span className={styles.dateWindowLabel}>Showing data for</span>
        {isDefault && (
          <span className={styles.timeWindowBadge}>
            <Clock size={11} /> Last 1 hour
          </span>
        )}
      </div>

      <div className={styles.dateWindowControls}>
        <div className={styles.dateWindowField}>
          <label className={styles.dateWindowFieldLabel}>From (UTC)</label>
          <input
            type="datetime-local"
            className={styles.dateWindowInput}
            value={from}
            onChange={e => onChange('from', e.target.value)}
          />
        </div>
        <span className={styles.dateWindowSep}>→</span>
        <div className={styles.dateWindowField}>
          <label className={styles.dateWindowFieldLabel}>To (UTC)</label>
          <input
            type="datetime-local"
            className={styles.dateWindowInput}
            value={to}
            onChange={e => onChange('to', e.target.value)}
          />
        </div>

        <button
          className={`btn btn-primary btn-sm ${styles.dateWindowApply}`}
          onClick={onApply}
          disabled={loading}
        >
          {loading ? <Loader2 size={13} className={styles.spin} /> : <RefreshCw size={13} />}
          Apply
        </button>

        {!isDefault && (
          <button
            className="btn btn-ghost btn-sm"
            onClick={() => { onChange('reset'); }}
            title="Reset to last 1 hour"
          >
            <RotateCcw size={13} /> Reset
          </button>
        )}
      </div>
    </div>
  )
}

// ─── Table filter panel ────────────────────────────────────────────────
function FilterPanel({ open, onToggle, filters, onChange, onReset, statusOpts, typeOpts }) {
  const active = countActive(filters)
  return (
    <div className={styles.filterWrap}>
      <button
        className={`${styles.filterToggle} ${open ? styles.filterToggleActive : ''}`}
        onClick={onToggle}
      >
        <span className={styles.ftLeft}>
          <Filter size={13} />
          <span>Column Filters</span>
          {active > 0 && <span className={styles.filterBadge}>{active}</span>}
        </span>
        {open ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
      </button>

      {open && (
        <div className={`${styles.filterPanel} fade-in`}>
          <div className={styles.filterGrid}>

            <div className={styles.fg}>
              <label className={styles.fl}>Status</label>
              <select className={styles.fs} value={filters.status} onChange={e => onChange('status', e.target.value)}>
                <option value="">All Statuses</option>
                {statusOpts.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>

            <div className={styles.fg}>
              <label className={styles.fl}>Event Type</label>
              <select className={styles.fs} value={filters.eventType} onChange={e => onChange('eventType', e.target.value)}>
                <option value="">All Types</option>
                {typeOpts.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>

            <div className={styles.fg}>
              <label className={styles.fl}>Order / Event / Fulfilment ID</label>
              <div className={styles.fsearchWrap}>
                <Search size={12} className={styles.fsearchIcon} />
                <input
                  className={styles.fsearch}
                  placeholder="e.g. ORD-123456"
                  value={filters.search}
                  onChange={e => onChange('search', e.target.value)}
                />
                {filters.search && (
                  <button className={styles.fsearchClear} onClick={() => onChange('search', '')}>
                    <X size={11} />
                  </button>
                )}
              </div>
            </div>

            <div className={styles.fg}>
              <label className={styles.fl}>Errors</label>
              <select className={styles.fs} value={filters.hasException} onChange={e => onChange('hasException', e.target.value)}>
                <option value="">All Records</option>
                <option value="yes">With Exception</option>
                <option value="no">No Exception</option>
              </select>
            </div>

            <div className={styles.fg}>
              <label className={styles.fl}>Min Retry Count</label>
              <select className={styles.fs} value={filters.minRetry} onChange={e => onChange('minRetry', e.target.value)}>
                <option value="">Any</option>
                <option value="1">≥ 1</option>
                <option value="2">≥ 2</option>
                <option value="3">≥ 3 (Critical)</option>
              </select>
            </div>

          </div>

          {active > 0 && (
            <div className={styles.filterActions}>
              <button className="btn btn-ghost btn-sm" onClick={onReset}>
                <RotateCcw size={12} /> Clear column filters
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ─── Active filter pills ───────────────────────────────────────────────
function ActivePills({ filters, onChange }) {
  const pills = [
    filters.status       && { k: 'status',       label: `Status: ${filters.status}` },
    filters.eventType    && { k: 'eventType',     label: `Type: ${filters.eventType}` },
    filters.search       && { k: 'search',        label: `ID: ${filters.search}` },
    filters.hasException && { k: 'hasException',  label: filters.hasException === 'yes' ? 'With errors' : 'No errors' },
    filters.minRetry     && { k: 'minRetry',      label: `Retry ≥ ${filters.minRetry}` },
  ].filter(Boolean)

  if (!pills.length) return null
  return (
    <div className={styles.activePills}>
      {pills.map(p => (
        <span key={p.k} className={styles.pill}>
          {p.label}
          <button className={styles.pillX} onClick={() => onChange(p.k, '')}><X size={10} /></button>
        </span>
      ))}
    </div>
  )
}

// ─── Apply column filters (no date — date handled server-side) ─────────
function applyFilters(rows, f) {
  return rows.filter(r => {
    if (f.status    && r.operationStatus !== f.status)   return false
    if (f.eventType && r.eventType       !== f.eventType) return false
    if (f.search) {
      const q = f.search.toLowerCase()
      if (!r.orderId?.toLowerCase().includes(q) &&
          !r.eventId?.toLowerCase().includes(q)  &&
          !r.fulfilmentId?.toLowerCase().includes(q)) return false
    }
    if (f.hasException === 'yes' && !r.exception)  return false
    if (f.hasException === 'no'  &&  r.exception)  return false
    if (f.minRetry && (r.retryAttempt ?? 0) < Number(f.minRetry)) return false
    return true
  })
}

// ─── Empty row ─────────────────────────────────────────────────────────
function EmptyRow({ cols }) {
  return (
    <tr>
      <td colSpan={cols} style={{ textAlign: 'center', padding: '28px 16px', color: 'var(--text-muted)', fontSize: 13 }}>
        No records match the current filters
      </td>
    </tr>
  )
}

// ─── Retry badge ───────────────────────────────────────────────────────
function RetryBadge({ n }) {
  const v = n ?? 0
  if (v >= 3) return <span className="badge badge-error">{v}</span>
  if (v > 0)  return <span className="badge badge-warning">{v}</span>
  return <span style={{ color: 'var(--text-muted)' }}>0</span>
}

// ─── Main page ─────────────────────────────────────────────────────────
export default function DashboardPage() {
  const navigate = useNavigate()

  // Global date window — drives stat cards AND table data
  const [winFrom, setWinFrom] = useState(oneHourAgo)
  const [winTo,   setWinTo]   = useState(nowLocal)
  // Track whether window matches the 1-hour default
  const isDefaultWindow = useMemo(() => {
    // winFrom/winTo are UTC-based YYYY-MM-DDTHH:mm strings (from .toISOString().slice(0,16))
    // Parse them as UTC by appending Z before comparing to Date.now()
    const fromDiff = Math.abs(new Date(winFrom + 'Z') - (Date.now() - 3600000))
    const toDiff   = Math.abs(new Date(winTo   + 'Z') - Date.now())
    return fromDiff < 120000 && toDiff < 120000
  }, [winFrom, winTo])

  const [stats, setStats]               = useState(null)
  const [manageEvents, setManageEvents] = useState([])
  const [fulfilEvents, setFulfilEvents] = useState([])
  const [loading, setLoading]           = useState(true)
  const [statsLoading, setStatsLoading] = useState(false)

  // Per-table column filters (date handled globally above)
  const [mFilters, setMFilters] = useState({ ...EMPTY_TABLE_F })
  const [fFilters, setFFilters] = useState({ ...EMPTY_TABLE_F })
  const [mOpen, setMOpen]       = useState(false)
  const [fOpen, setFOpen]       = useState(false)

  // Modal
  const [modal, setModal] = useState(null)

  const load = useCallback(async (fromStr, toStr) => {
    setLoading(true)
    try {
      const fromISO = toISO(fromStr)
      const toISO_  = toISO(toStr)
      const [s, me, fe] = await Promise.all([
        ordersApi.getDashboard(fromISO, toISO_),
        ordersApi.getAllManage(fromISO, toISO_),
        ordersApi.getAllFulfilment(fromISO, toISO_),
      ])
      setStats(s)
      setManageEvents(me)
      setFulfilEvents(fe)
    } catch {
      toast.error('Failed to load dashboard')
    } finally {
      setLoading(false)
    }
  }, [])

  // Initial load — default 1-hour window
  useEffect(() => { load(winFrom, winTo) }, [])

  const handleWindowChange = (field, value) => {
    if (field === 'reset') {
      const f = oneHourAgo()
      const t = nowLocal()
      setWinFrom(f)
      setWinTo(t)
      load(f, t)
    } else if (field === 'from') {
      setWinFrom(value)
    } else {
      setWinTo(value)
    }
  }

  const handleApply = () => load(winFrom, winTo)

  // Build lookup: orderId → fulfilment rows
  const fulfilByOrder = useMemo(() => {
    const map = {}
    fulfilEvents.forEach(r => {
      if (!map[r.orderId]) map[r.orderId] = []
      map[r.orderId].push(r)
    })
    return map
  }, [fulfilEvents])

  const mStatusOpts = useMemo(() => uniqueVals(manageEvents, 'operationStatus'), [manageEvents])
  const mTypeOpts   = useMemo(() => uniqueVals(manageEvents, 'eventType'),       [manageEvents])
  const fStatusOpts = useMemo(() => uniqueVals(fulfilEvents, 'operationStatus'), [fulfilEvents])
  const fTypeOpts   = useMemo(() => uniqueVals(fulfilEvents, 'eventType'),       [fulfilEvents])

  const filteredManage = useMemo(() => applyFilters(manageEvents, mFilters), [manageEvents, mFilters])
  const filteredFulfil = useMemo(() => applyFilters(fulfilEvents, fFilters), [fulfilEvents, fFilters])

  const updateM = (k, v) => setMFilters(f => ({ ...f, [k]: v }))
  const updateF = (k, v) => setFFilters(f => ({ ...f, [k]: v }))

  const openModal = useCallback((title, icon, color, raw) => setModal({ title, icon, color, raw }), [])

  return (
    <div className={styles.root}>
      {/* ── Header ── */}
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Operations Dashboard</h1>
          <p className={styles.subtitle}>Real-time view of your fulfilment status</p>
        </div>
        <button className="btn btn-outline" onClick={handleApply} disabled={loading}>
          <RefreshCw size={14} className={loading ? styles.spin : ''} />
          Refresh
        </button>
      </div>

      {/* ── Global date window filter ── */}
      <DateWindowFilter
        from={winFrom}
        to={winTo}
        onChange={handleWindowChange}
        onApply={handleApply}
        loading={loading}
        isDefault={isDefaultWindow}
      />

      {loading && !stats ? (
        <div className={styles.loader}><Loader2 size={28} className={styles.spin} /></div>
      ) : (
        <>
          {/* ── Stat cards ── */}
          <div className={styles.statsGrid}>
            <StatCard icon={Package}       label="Total Orders"           value={stats?.totalOrders}             color="#2563eb" />
            <StatCard icon={CheckCircle2}  label="Fulfilment Created"  value={stats?.completedManageJobs}     color="#16a34a" />
            <StatCard icon={XCircle}       label="Failed to create Fulfilment"     value={stats?.failedManageJobs}        color="#e01a22" />
            <StatCard icon={TrendingUp}    label="Picked And Delivered Fulfilment"   value={stats?.completedFulfilmentJobs} color="#16a34a" />
            <StatCard icon={XCircle}       label="Failed in Picked or Delivered Fulfilment" value={stats?.failedFulfilmentJobs}    color="#d97706" />
            <StatCard icon={AlertTriangle} label="Priority Issues"        value={stats?.priorityIssues}          color="#e01a22" />

          </div>

          {/* ══════════════════════════════════════════════
               TABLE 1 — Manage Fulfilment Job Queue
          ══════════════════════════════════════════════ */}
          <div className={styles.tableCard}>
            <div className={styles.tableHeader}>
              <div className={styles.tableHeaderLeft}>
                <h2 className={styles.tableTitle}>Manage Fulfilment Job Queue</h2>
                <span className="badge badge-muted">
                  {filteredManage.length}
                  {countActive(mFilters) > 0 && ` of ${manageEvents.length}`} events
                </span>
              </div>
            </div>

            <FilterPanel
              open={mOpen} onToggle={() => setMOpen(v => !v)}
              filters={mFilters} onChange={updateM}
              onReset={() => setMFilters({ ...EMPTY_TABLE_F })}
              statusOpts={mStatusOpts} typeOpts={mTypeOpts}
            />
            <ActivePills filters={mFilters} onChange={updateM} />

            <div className={styles.tableWrap}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Event ID</th>
                    <th>Order ID</th>
                    <th>Event Type</th>
                    <th>Status</th>
                    <th>Fulfilment ID</th>
                    <th>Order Request</th>
                    <th>Retry</th>
                    <th>Exception</th>
                    <th>Date &amp; Time</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredManage.length === 0 ? <EmptyRow cols={9} /> :
                    filteredManage.map(e => (
                      <tr key={e.eventId}>
                        <td><code style={{ fontSize: 11 }}>{e.eventId}</code></td>
                        <td>
                          <button className={styles.orderLink} onClick={() => navigate(`/orders?orderId=${e.orderId}`)}>
                            {e.orderId}
                          </button>
                        </td>
                        <td><span className="badge badge-info">{e.eventType}</span></td>
                        <td><span className={`badge ${statusBadgeClass(e.operationStatus)}`}>{e.operationStatus}</span></td>
                        <td>{e.fulfilmentId || <span className={styles.muted}>—</span>}</td>
                        <td>
                          <PayloadBtn
                            label="Order"
                            icon={ShoppingCart}
                            color="#2563eb"
                            raw={e.orderRequest}
                            onClick={() => openModal(`Order Request — ${e.orderId}`, ShoppingCart, '#2563eb', e.orderRequest)}
                          />
                        </td>
                        <td style={{ textAlign: 'center' }}><RetryBadge n={e.retryAttempt} /></td>
                        <td>
                          {e.exception
                            ? <span className={styles.exception} title={e.exception}>
                                {e.exception.substring(0, 40)}{e.exception.length > 40 ? '…' : ''}
                              </span>
                            : <span className={styles.muted}>—</span>}
                        </td>
                        <td className={styles.dateCell}>{formatDate(e.eventDatetime)}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* ══════════════════════════════════════════════
               TABLE 2 — Fulfilment Job Queue
          ══════════════════════════════════════════════ */}
          <div className={styles.tableCard}>
            <div className={styles.tableHeader}>
              <div className={styles.tableHeaderLeft}>
                <h2 className={styles.tableTitle}>Fulfilment Job Queue</h2>
                <span className="badge badge-muted">
                  {filteredFulfil.length}
                  {countActive(fFilters) > 0 && ` of ${fulfilEvents.length}`} events
                </span>
              </div>
            </div>

            <FilterPanel
              open={fOpen} onToggle={() => setFOpen(v => !v)}
              filters={fFilters} onChange={updateF}
              onReset={() => setFFilters({ ...EMPTY_TABLE_F })}
              statusOpts={fStatusOpts} typeOpts={fTypeOpts}
            />
            <ActivePills filters={fFilters} onChange={updateF} />

            <div className={styles.tableWrap}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Event ID</th>
                    <th>Order ID</th>
                    <th>Fulfilment ID</th>
                    <th>Event Type</th>
                    <th>Status</th>
                    <th>Enrich Request</th>
                    <th>Retry</th>
                    <th>Exception</th>
                    <th>Date &amp; Time</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredFulfil.length === 0 ? <EmptyRow cols={9} /> :
                    filteredFulfil.map(e => {
                      const isPick     = e.eventType === 'pickReport'
                      const isDelivery = e.eventType === 'deliveryReport'
                      return (
                        <tr key={e.eventId}>
                          <td><code style={{ fontSize: 11 }}>{e.eventId}</code></td>
                          <td>
                            <button className={styles.orderLink} onClick={() => navigate(`/orders?orderId=${e.orderId}`)}>
                              {e.orderId}
                            </button>
                          </td>
                          <td>{e.fulfilmentId || <span className={styles.muted}>—</span>}</td>
                          <td>
                            <span className={`badge ${isPick ? 'badge-info' : isDelivery ? 'badge-warning' : 'badge-muted'}`}>
                              {e.eventType}
                            </span>
                          </td>
                          <td><span className={`badge ${statusBadgeClass(e.operationStatus)}`}>{e.operationStatus}</span></td>
                          <td>
                            {isPick && (
                              <PayloadBtn
                                label="View Picked Items"
                                icon={ClipboardList}
                                color="#0891b2"
                                raw={e.enrichRequest}
                                onClick={() => openModal(`Pick Report — ${e.orderId} (${e.fulfilmentId})`, ClipboardList, '#0891b2', e.enrichRequest)}
                              />
                            )}
                            {isDelivery && (
                              <PayloadBtn
                                label="View Delivered Items"
                                icon={Truck}
                                color="#16a34a"
                                raw={e.enrichRequest}
                                onClick={() => openModal(`Delivery Report — ${e.orderId} (${e.fulfilmentId})`, Truck, '#16a34a', e.enrichRequest)}
                              />
                            )}
                            {!isPick && !isDelivery && (
                              <span className={styles.muted} style={{ fontSize: 12 }}>—</span>
                            )}
                          </td>
                          <td style={{ textAlign: 'center' }}><RetryBadge n={e.retryAttempt} /></td>
                          <td>
                            {e.exception
                              ? <span className={styles.exception} title={e.exception}>
                                  {e.exception.substring(0, 40)}{e.exception.length > 40 ? '…' : ''}
                                </span>
                              : <span className={styles.muted}>—</span>}
                          </td>
                          <td className={styles.dateCell}>{formatDate(e.eventDatetime)}</td>
                        </tr>
                      )
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {modal && (
        <PayloadModal
          title={modal.title}
          icon={modal.icon}
          color={modal.color}
          raw={modal.raw}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  )
}
