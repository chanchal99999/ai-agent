import { format } from 'date-fns'

/**
 * Format a date string for display, always in UTC.
 *
 * The backend stores event_datetime as TIMESTAMPTZ (UTC) and Jackson
 * serialises it as an ISO-8601 string with a Z or +00:00 offset.
 * date-fns `format(new Date(str))` converts to the browser's local
 * timezone (e.g. IST = UTC+5:30), causing a display mismatch.
 *
 * Fix: manually extract the UTC year/month/day/hour/minute using
 * Date's UTC getters so the display always matches what is stored.
 */
export function formatDate(dateStr) {
  if (!dateStr) return '—'
  try {
    const d = new Date(dateStr)
    if (isNaN(d.getTime())) return dateStr

    // Build the display string from UTC getters — timezone-safe
    const dd   = String(d.getUTCDate()).padStart(2, '0')
    const mon  = ['Jan','Feb','Mar','Apr','May','Jun',
                  'Jul','Aug','Sep','Oct','Nov','Dec'][d.getUTCMonth()]
    const yyyy = d.getUTCFullYear()
    const hh   = String(d.getUTCHours()).padStart(2, '0')
    const mm   = String(d.getUTCMinutes()).padStart(2, '0')

    return `${dd} ${mon} ${yyyy}, ${hh}:${mm} UTC`
  } catch {
    return dateStr
  }
}

/**
 * Format a datetime-local input value (e.g. "2025-03-24T10:30")
 * treating it as a UTC time for display purposes.
 */
export function formatDateLocal(dateStr) {
  if (!dateStr) return '—'
  try {
    // datetime-local strings have no timezone — treat as UTC
    const d = new Date(dateStr + 'Z')
    if (isNaN(d.getTime())) return dateStr

    const dd   = String(d.getUTCDate()).padStart(2, '0')
    const mon  = ['Jan','Feb','Mar','Apr','May','Jun',
                  'Jul','Aug','Sep','Oct','Nov','Dec'][d.getUTCMonth()]
    const yyyy = d.getUTCFullYear()
    const hh   = String(d.getUTCHours()).padStart(2, '0')
    const mm   = String(d.getUTCMinutes()).padStart(2, '0')

    return `${dd} ${mon} ${yyyy}, ${hh}:${mm} UTC`
  } catch {
    return dateStr
  }
}

export function statusBadgeClass(status) {
  if (!status) return 'badge-muted'
  switch (status.toUpperCase()) {
    case 'COMPLETED':     return 'badge-success'
    case 'API_EXCEPTION': return 'badge-error'
    case 'PENDING':       return 'badge-warning'
    case 'IN_PROGRESS':   return 'badge-info'
    default:              return 'badge-muted'
  }
}

export function priorityBadgeClass(priority) {
  switch ((priority || '').toUpperCase()) {
    case 'CRITICAL': return 'badge-error'
    case 'HIGH':     return 'badge-warning'
    case 'MEDIUM':   return 'badge-info'
    default:         return 'badge-muted'
  }
}

export function truncate(str, n = 50) {
  if (!str) return '—'
  return str.length > n ? str.substring(0, n) + '…' : str
}

export function extractErrorCode(exception) {
  if (!exception) return null
  const match = exception.match(/ErrorCode:([^,]+)/)
  return match ? match[1].trim() : null
}
