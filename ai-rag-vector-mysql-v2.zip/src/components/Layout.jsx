import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import {
  MessageSquare, LayoutDashboard, Package,
  AlertTriangle, FileText, BotMessageSquare,
  ChevronRight, LogOut, User, ShieldCheck, Headset
} from 'lucide-react'
import { useAuth } from '../context/AuthContext.jsx'
import { authApi } from '../services/api.js'
import toast from 'react-hot-toast'
import styles from './Layout.module.css'

// Operations / admin navigation
const OPS_NAV = [
  { to: '/chat',        icon: MessageSquare,   label: 'CFC Agent' },
  { to: '/dashboard',   icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/orders',      icon: Package,         label: 'Orders' },
  { to: '/priority',    icon: AlertTriangle,   label: 'Priority Issues' },
  { to: '/incidents',   icon: ShieldCheck,     label: 'Incidents' },
  { to: '/remediation', icon: FileText,        label: 'Supporting Documents' },
]

// Customer-care navigation (restricted: order status + their incidents)
const CARE_NAV = [
  { to: '/chat',      icon: Headset,       label: 'Care Agent' },
  { to: '/incidents', icon: AlertTriangle, label: 'My Incidents' },
]

export default function Layout() {
  const navigate      = useNavigate()
  const { user, logout, isAdmin } = useAuth()
  const isCare = user?.role === 'CUSTOMER_CARE'
  const NAV = isCare ? CARE_NAV : OPS_NAV

  const handleLogout = async () => {
    try { await authApi.logout() } catch { /* ignore */ }
    logout()
    toast.success('Logged out successfully')
    navigate('/login')
  }

  return (
    <div className={styles.root}>
      {/* Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.brand} onClick={() => navigate('/chat')}>
          <div className={styles.brandIcon}>
            <BotMessageSquare size={18} />
          </div>
          <div>
            <div className={styles.brandName}>CFC Agent</div>
            {/* <div className={styles.brandSub}>Support</div> */}
          </div>
        </div>

        <nav className={styles.nav}>
          {NAV.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `${styles.navItem} ${isActive ? styles.navItemActive : ''}`
              }
            >
              <Icon size={16} />
              <span>{label}</span>
              <ChevronRight size={12} className={styles.navChevron} />
            </NavLink>
          ))}
        </nav>

        {/* User section */}
        <div className={styles.userSection}>
          <div className={styles.userCard}>
            <div className={styles.userAvatar}>
              {isAdmin
                ? <ShieldCheck size={16} />
                : isCare
                ? <Headset size={16} />
                : <User size={16} />
              }
            </div>
            <div className={styles.userInfo}>
              <div className={styles.userName}>
                {user?.fullName || user?.username}
              </div>
              <div className={styles.userMeta}>
                <span className={`${styles.roleBadge} ${isAdmin ? styles.roleBadgeAdmin : styles.roleBadgeUser}`}>
                  {isAdmin ? 'Admin' : isCare ? 'Care' : 'User'}
                </span>
                <span className={styles.userUsername}>@{user?.username}</span>
              </div>
            </div>
          </div>

          <button className={styles.logoutBtn} onClick={handleLogout} title="Sign out">
            <LogOut size={14} />
            <span>Sign out</span>
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className={styles.main}>
        <Outlet />
      </main>
    </div>
  )
}
