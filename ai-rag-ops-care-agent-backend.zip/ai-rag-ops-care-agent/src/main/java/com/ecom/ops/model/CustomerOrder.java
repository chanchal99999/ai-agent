package com.ecom.ops.model;

import java.time.OffsetDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Customer-facing order with its current lifecycle status. This is the live
 * "source of truth" both agents read for order status. Separate from the
 * internal manage/fulfilment job-queue tables (which model ops events).
 */
@Entity
@Table(name = "customer_order", indexes = {
        @Index(name = "idx_customer_order_order_id", columnList = "order_id"),
        @Index(name = "idx_customer_order_status",   columnList = "status")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "order_id", nullable = false, unique = true, length = 64)
    private String orderId;

    @Column(name = "customer_name", length = 150)
    private String customerName;

    @Column(name = "customer_email", length = 200)
    private String customerEmail;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 40)
    private OrderStatus status;

    @Column(name = "item_summary", length = 255)
    private String itemSummary;

    @Column(name = "item_count")
    private Integer itemCount;

    @Column(name = "total_amount")
    private Double totalAmount;

    @Column(name = "currency", length = 8)
    @Builder.Default
    private String currency = "USD";

    @Column(name = "carrier", length = 80)
    private String carrier;

    @Column(name = "tracking_number", length = 100)
    private String trackingNumber;

    @Column(name = "shipping_address", length = 400)
    private String shippingAddress;

    /** Optional human-readable note (e.g. why on hold, delivery failure reason). */
    @Column(name = "status_note", length = 400)
    private String statusNote;

    @Column(name = "order_placed_at")
    private OffsetDateTime orderPlacedAt;

    @Column(name = "estimated_delivery")
    private OffsetDateTime estimatedDelivery;

    // -- Payment & billing ------------------------------------------
    @Column(name = "payment_status", length = 40)
    private String paymentStatus;          // e.g. PAID, PENDING, FAILED, REFUNDED, PARTIALLY_REFUNDED

    @Column(name = "payment_amount")
    private Double paymentAmount;

    @Column(name = "refund_amount")
    private Double refundAmount;

    // -- Age verification (for age-restricted items) ----------------
    @Column(name = "age_verified")
    @Builder.Default
    private Boolean ageVerified = false;

    // -- Delivery slot window (e.g. "Mon 18:00-20:00") --------------
    @Column(name = "slot_window", length = 80)
    private String slotWindow;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private OffsetDateTime updatedAt;
}
