package com.ecom.ops.model;

/**
 * Common order lifecycle statuses, grouped by phase. Each status carries a
 * customer-friendly label and the phase it belongs to.
 */
public enum OrderStatus {

    // ── Pre-Fulfillment ─────────────────────────────────────────
    PENDING            (Phase.PRE_FULFILLMENT, "Pending",            "Order placed but not yet processed."),
    AWAITING_PAYMENT   (Phase.PRE_FULFILLMENT, "Awaiting Payment",   "Payment not yet confirmed."),
    PAYMENT_FAILED     (Phase.PRE_FULFILLMENT, "Payment Failed",     "Transaction declined or unsuccessful."),
    ON_HOLD            (Phase.PRE_FULFILLMENT, "On Hold",            "Order paused (fraud check, manual review, or stock issue)."),

    // ── Fulfillment in Progress ─────────────────────────────────
    PROCESSING         (Phase.FULFILLMENT,     "Processing",         "Order confirmed and being prepared."),
    PACKED             (Phase.FULFILLMENT,     "Packed",             "Items picked and packed for shipment."),
    READY_FOR_SHIPMENT (Phase.FULFILLMENT,     "Ready for Shipment", "Awaiting courier pickup."),

    // ── Shipping & Delivery ─────────────────────────────────────
    SHIPPED            (Phase.SHIPPING,        "Shipped",            "Handed over to the courier."),
    IN_TRANSIT         (Phase.SHIPPING,        "In Transit",         "Courier is moving the package."),
    OUT_FOR_DELIVERY   (Phase.SHIPPING,        "Out for Delivery",   "Courier is delivering today."),
    DELIVERED          (Phase.SHIPPING,        "Delivered",          "Successfully received by the customer."),
    DELIVERY_FAILED    (Phase.SHIPPING,        "Delivery Failed",    "Delivery attempted but unsuccessful (wrong address or customer unavailable)."),
    RETURNED_TO_SENDER (Phase.SHIPPING,        "Returned to Sender", "Courier returned the package to the warehouse."),

    // ── Post-Delivery / Exceptions ──────────────────────────────
    CANCELLED          (Phase.POST_DELIVERY,   "Cancelled",          "Order cancelled by the customer or system."),
    RETURNED           (Phase.POST_DELIVERY,   "Returned",           "Customer returned the item."),
    REFUND_INITIATED   (Phase.POST_DELIVERY,   "Refund Initiated",   "Refund process started."),
    REFUND_COMPLETED   (Phase.POST_DELIVERY,   "Refund Completed",   "Refund successfully processed."),
    REPLACEMENT_SHIPPED(Phase.POST_DELIVERY,   "Replacement Shipped","Replacement item sent.");

    public enum Phase {
        PRE_FULFILLMENT("Pre-Fulfillment"),
        FULFILLMENT("Fulfillment in Progress"),
        SHIPPING("Shipping & Delivery"),
        POST_DELIVERY("Post-Delivery / Exceptions");

        private final String label;
        Phase(String label) { this.label = label; }
        public String getLabel() { return label; }
    }

    private final Phase  phase;
    private final String label;
    private final String description;

    OrderStatus(Phase phase, String label, String description) {
        this.phase = phase;
        this.label = label;
        this.description = description;
    }

    public Phase  getPhase()       { return phase; }
    public String getLabel()       { return label; }
    public String getDescription() { return description; }

    /** True for statuses that represent a failure/exception the customer may need help with. */
    public boolean isExceptional() {
        return this == PAYMENT_FAILED || this == ON_HOLD || this == DELIVERY_FAILED
            || this == RETURNED_TO_SENDER || this == CANCELLED;
    }

    /** True once the order has reached a delivered/closed end-state. */
    public boolean isTerminal() {
        return this == DELIVERED || this == CANCELLED || this == REFUND_COMPLETED
            || this == RETURNED;
    }
}
