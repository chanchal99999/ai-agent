package com.ecom.ops.config;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

import com.ecom.ops.model.CustomerOrder;
import com.ecom.ops.model.OrderStatus;
import com.ecom.ops.repository.CustomerOrderRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Seeds 50 customer orders covering ALL 18 lifecycle statuses (idempotent).
 * Order IDs ORD-70001..ORD-70050. Both agents read live status from this table.
 */
@Configuration
@RequiredArgsConstructor
@Slf4j
public class OrderSeeder {

    private final CustomerOrderRepository orderRepository;

    private static final String[] CARRIERS = {"BlueDart", "FedEx", "DHL", "UPS", "Delhivery"};
    private static final String[] NAMES = {
            "Aarav Sharma","Priya Patel","Liam Smith","Emma Johnson","Noah Williams",
            "Olivia Brown","Ethan Jones","Ava Garcia","Sophia Miller","Mason Davis",
            "Isabella Wilson","Lucas Moore","Mia Taylor","Amelia Anderson","James Thomas"
    };
    private static final String[] ITEMS = {
            "Whole Milk 2L","Free Range Eggs 12 Pack","Sourdough Bread 800g","Basmati Rice 2kg",
            "Chopped Tomatoes 400g","Salmon Fillets 2 Pack 280g","Tenderstem Broccoli 200g","New Potatoes 1kg"
            ,"Beef Mince 5% Fat 500g",
            "Onions Brown 1kg","Cheddar Mature 400g","Semi-Skimmed Milk 6 Pint",
            "Banana x6","Back Bacon Smoked 300g","Mushrooms Closed Cup 400g"
    };

    @Bean
    @Order(2) // run after default users are seeded
    public ApplicationRunner seedCustomerOrders() {
        return args -> {
            if (orderRepository.count() > 0) {
                log.info("customer_order already populated ({} rows) � skipping seed", orderRepository.count());
                return;
            }

            // Distribution across all 18 statuses summing to 50.
            // Common in-flight statuses get a few more; every status >= 1.
            OrderStatus[] s = OrderStatus.values();
            int[] counts = {
                3, // PENDING
                2, // AWAITING_PAYMENT
                2, // PAYMENT_FAILED
                2, // ON_HOLD
                5, // PROCESSING
                3, // PACKED
                2, // READY_FOR_SHIPMENT
                3, // SHIPPED
                5, // IN_TRANSIT
                4, // OUT_FOR_DELIVERY
                6, // DELIVERED
                2, // DELIVERY_FAILED
                1, // RETURNED_TO_SENDER
                2, // CANCELLED
                2, // RETURNED
                2, // REFUND_INITIATED
                1, // REFUND_COMPLETED
                3  // REPLACEMENT_SHIPPED
            }; // total = 50

            List<CustomerOrder> batch = new ArrayList<>();
            int seq = 70001;
            OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);

            for (int i = 0; i < s.length; i++) {
                for (int c = 0; c < counts[i]; c++) {
                    int idx = seq - 70001;
                    String orderId = "ORD-" + (seq++);
                    OrderStatus status = s[i];

                    String name = NAMES[idx % NAMES.length];
                    String email = name.toLowerCase().replace(" ", ".") + "@example.com";
                    String item = ITEMS[idx % ITEMS.length];
                    int itemCount = 1 + (idx % 4);
                    double total = Math.round((15 + (idx * 7.5) % 240) * 100.0) / 100.0;
                    String carrier = CARRIERS[idx % CARRIERS.length];

                    OffsetDateTime placed = now.minusDays((idx % 12) + 1).minusHours(idx % 24);

                    CustomerOrder.CustomerOrderBuilder b = CustomerOrder.builder()
                            .orderId(orderId)
                            .customerName(name)
                            .customerEmail(email)
                            .status(status)
                            .itemSummary(item)
                            .itemCount(itemCount)
                            .totalAmount(total)
                            .currency("USD")
                            .shippingAddress((100 + idx) + " Main St, Springfield")
                            .orderPlacedAt(placed)
                            .statusNote(noteFor(status));

                    // Tracking + carrier only once shipped onward.
                    if (hasTracking(status)) {
                        b.carrier(carrier)
                         .trackingNumber(carrier.substring(0, 2).toUpperCase() + (987654000L + seq));
                    }
                    // Estimated delivery for in-flight orders.
                    if (hasEta(status)) {
                        b.estimatedDelivery(now.plusDays(1 + (idx % 4)));
                    } else if (status == OrderStatus.DELIVERED) {
                        b.estimatedDelivery(placed.plusDays(3));
                    }

                    batch.add(b.build());
                }
            }

            orderRepository.saveAll(batch);
            log.info("Seeded {} customer orders (ORD-70001..ORD-{}) across all {} statuses",
                    batch.size(), seq - 1, s.length);
        };
    }

    private boolean hasTracking(OrderStatus st) {
        return switch (st) {
            case SHIPPED, IN_TRANSIT, OUT_FOR_DELIVERY, DELIVERED,
                 DELIVERY_FAILED, RETURNED_TO_SENDER, REPLACEMENT_SHIPPED -> true;
            default -> false;
        };
    }

    private boolean hasEta(OrderStatus st) {
        return switch (st) {
            case PROCESSING, PACKED, READY_FOR_SHIPMENT, SHIPPED,
                 IN_TRANSIT, OUT_FOR_DELIVERY, REPLACEMENT_SHIPPED -> true;
            default -> false;
        };
    }

    private String noteFor(OrderStatus st) {
        return switch (st) {
            case AWAITING_PAYMENT    -> "Waiting for payment confirmation.";
            case PAYMENT_FAILED      -> "Card declined � please retry payment.";
            case ON_HOLD             -> "Manual review (fraud/stock check) in progress.";
            case DELIVERY_FAILED     -> "Delivery attempted; customer unavailable.";
            case RETURNED_TO_SENDER  -> "Undeliverable � returned to warehouse.";
            case CANCELLED           -> "Cancelled per customer request.";
            case RETURNED            -> "Item returned by customer.";
            case REFUND_INITIATED    -> "Refund started; 5-7 business days to complete.";
            case REFUND_COMPLETED    -> "Refund processed to original payment method.";
            case REPLACEMENT_SHIPPED -> "Replacement dispatched for damaged item.";
            default -> null;
        };
    }
}
