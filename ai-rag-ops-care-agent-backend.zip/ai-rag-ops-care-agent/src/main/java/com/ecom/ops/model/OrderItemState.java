package com.ecom.ops.model;

/**
 * The lifecycle state a line item is currently in, within an order.
 *   ORDERED   - originally ordered by the customer
 *   PICKED    - picked in the warehouse for this order
 *   DELIVERED - delivered to the customer
 *   REJECTED  - rejected/removed (out of stock, failed age check, damaged, etc.)
 */
public enum OrderItemState {
    ORDERED,
    PICKED,
    DELIVERED,
    REJECTED
}
