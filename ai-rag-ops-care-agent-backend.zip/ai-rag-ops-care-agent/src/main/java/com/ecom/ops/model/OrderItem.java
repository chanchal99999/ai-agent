package com.ecom.ops.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * A single line item within an order, in a specific state (ordered / picked /
 * delivered / rejected). Both agents read these for item-level questions.
 *
 * Linked to CustomerOrder by orderId (string business key) to match the existing
 * lookup pattern (no hard FK needed; ddl-auto creates the table).
 */
@Entity
@Table(name = "order_item", indexes = {
        @Index(name = "idx_order_item_order_id", columnList = "order_id"),
        @Index(name = "idx_order_item_state",    columnList = "state")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "order_id", nullable = false, length = 64)
    private String orderId;

    @Enumerated(EnumType.STRING)
    @Column(name = "state", nullable = false, length = 20)
    private OrderItemState state;

    @Column(name = "item_description", length = 255)
    private String itemDescription;

    @Column(name = "item_type", length = 80)
    private String itemType;

    @Column(name = "quantity")
    private Integer quantity;

    /** Whether this item was/can be substituted. */
    @Column(name = "substitute")
    @Builder.Default
    private Boolean substitute = false;

    /** Minimum age required to purchase (0 = none, 18 = age-restricted). */
    @Column(name = "minimum_age_restricted")
    @Builder.Default
    private Integer minimumAgeRestricted = 0;

    public boolean isAgeRestricted() {
        return minimumAgeRestricted != null && minimumAgeRestricted > 0;
    }
}
