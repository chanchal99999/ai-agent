package com.ecom.ops.dto;

import java.time.OffsetDateTime;

import com.ecom.ops.model.Incident;
import com.ecom.ops.model.IncidentSeverity;
import com.ecom.ops.model.IncidentStatus;

import jakarta.validation.constraints.NotBlank;

/** Incident request/response DTOs. */
public class IncidentDtos {

    /** Payload a CUSTOMER_CARE user sends to raise an incident. */
    public record CreateIncidentRequest(
            @NotBlank String orderId,
            String errorCode,
            String description,
            IncidentSeverity severity   // optional; defaults to MEDIUM
    ) {}

    /** Payload the customer-care agent sends to raise a team-routed incident. */
    public record CareIncidentRequest(
            @NotBlank String orderId,
            String errorCode,
            String description,
            IncidentSeverity severity,
            String team,        // OPERATIONS | SUPPORT | BILLING
            String reason
    ) {}

    /** Payload an OPERATIONS/ADMIN user sends to update an incident. */
    public record UpdateIncidentRequest(
            IncidentStatus status,
            String assignedTo,
            String resolutionNotes
    ) {}

    /** Response view of an incident. */
    public record IncidentResponse(
            String incidentId,
            String orderId,
            String errorCode,
            String description,
            IncidentSeverity severity,
            IncidentStatus status,
            String raisedBy,
            String assignedTeam,
            String assignedTo,
            String resolutionNotes,
            OffsetDateTime createdAt,
            OffsetDateTime updatedAt
    ) {
        public static IncidentResponse from(Incident i) {
            return new IncidentResponse(
                    i.getIncidentId() != null ? i.getIncidentId().toString() : null,
                    i.getOrderId(), i.getErrorCode(), i.getDescription(),
                    i.getSeverity(), i.getStatus(), i.getRaisedBy(),
                    i.getAssignedTeam(), i.getAssignedTo(), i.getResolutionNotes(),
                    i.getCreatedAt(), i.getUpdatedAt());
        }
    }
}
