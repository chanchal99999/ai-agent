package com.ecom.ops.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.ops.dto.IncidentDtos.CareIncidentRequest;
import com.ecom.ops.dto.IncidentDtos.CreateIncidentRequest;
import com.ecom.ops.dto.IncidentDtos.IncidentResponse;
import com.ecom.ops.dto.IncidentDtos.UpdateIncidentRequest;
import com.ecom.ops.model.IncidentSeverity;
import com.ecom.ops.service.IncidentService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/incidents")
@RequiredArgsConstructor
public class IncidentController {

	private final IncidentService incidentService;

	/** Raise an incident — CUSTOMER_CARE (and ADMIN as fallback). */
	@PostMapping
	@PreAuthorize("hasAnyRole('CUSTOMER_CARE','ADMIN')")
	public ResponseEntity<IncidentResponse> raise(@Valid @RequestBody CreateIncidentRequest req, Principal principal) {
		return ResponseEntity.ok(incidentService.raise(req, principal.getName()));
	}

	/** Care agent raises a team-routed incident (CUSTOMER_CARE / ADMIN). */
	@PostMapping("/care")
	@PreAuthorize("hasAnyRole('CUSTOMER_CARE','ADMIN')")
	public ResponseEntity<IncidentResponse> raiseFromCare(@Valid @RequestBody CareIncidentRequest req,
			Principal principal) {
		IncidentSeverity sev = req.severity() != null ? req.severity() : IncidentSeverity.HIGH;
		String desc = req.description() != null ? req.description()
				: (req.reason() != null ? req.reason() : "Raised via customer care chat");
		return ResponseEntity.ok(incidentService.raiseForTeam(req.orderId(), emptyToNull(req.errorCode()), desc, sev,
				req.team() != null ? req.team() : "SUPPORT", principal.getName()));
	}

	private static String emptyToNull(String s) {
		return (s == null || s.isBlank()) ? null : s;
	}

	/**
	 * List incidents — visibility depends on role: CUSTOMER_CARE -> only their own
	 * USER / ADMIN -> all (operations view)
	 */
	@GetMapping
	@PreAuthorize("hasAnyRole('CUSTOMER_CARE','USER','ADMIN')")
	public ResponseEntity<List<IncidentResponse>> list(Authentication auth) {
		boolean isOperations = hasAnyRole(auth, "ROLE_USER", "ROLE_ADMIN");
		return ResponseEntity.ok(incidentService.list(auth.getName(), isOperations));
	}

	/** Update an incident — OPERATIONS / ADMIN only. */
	@PutMapping("/{incidentId}")
	@PreAuthorize("hasAnyRole('USER','ADMIN')")
	public ResponseEntity<IncidentResponse> update(@PathVariable String incidentId,
			@RequestBody UpdateIncidentRequest req, Principal principal) {
		return ResponseEntity.ok(incidentService.update(incidentId, req, principal.getName()));
	}

	private boolean hasAnyRole(Authentication auth, String... roles) {
		for (GrantedAuthority ga : auth.getAuthorities()) {
			for (String r : roles) {
				if (r.equals(ga.getAuthority()))
					return true;
			}
		}
		return false;
	}
}
