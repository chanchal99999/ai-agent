package com.ecom.ops.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.stereotype.Service;

import com.ecom.ops.dto.ChatRequestDto;
import com.ecom.ops.dto.ChatRequestDto.MessageInfo;
import com.ecom.ops.repository.ChatMessageRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;

/**
 * Customer-care scoped agent.
 *
 * Handles six intent categories (status/tracking, placement/changes, payment,
 * returns/refunds, delivery issues, account/support). It is RESTRICTED on the
 * backend — it never exposes ops internals (SQL, exceptions, failed-job data,
 * remediation docs). Answers come from three sources:
 *
 * 1. DATA-BACKED -> live order data via OrderService (where it exists) 2.
 * POLICY -> CarePolicyService grounding text, phrased by the LLM 3. HANDOFF ->
 * raise an incident to OPERATIONS / SUPPORT / BILLING and offer a human-agent
 * handoff
 *
 * Intent is detected by the LLM (see classify(...)), with a keyword-based
 * fallback used only if the LLM call fails.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class CustomerCareChatService {

	private final OrderService orderService;
	private final ChatbotService chatbotService;
	private final CarePolicyService carePolicyService;
	private final ChatClient chatClient;
	private final ChatMessageRepository messageRepo;

	private static final Pattern ORDER_ID = Pattern.compile("ORD-\\d+", Pattern.CASE_INSENSITIVE);

	private static final String CARE_SYSTEM = """
			You are a friendly, concise Customer Care assistant talking
			directly to a CUSTOMER (not an internal operator).

			RULES:
			- Be warm, brief, and clear. Use plain language a shopper understands.
			- NEVER mention internal systems, SQL, databases, error codes, stack
			  traces, job queues, or remediation documents.
			- Only answer using the GROUNDING INFORMATION provided to you. If the
			  grounding says to hand off to a human, say so kindly.
			- Never invent policy details (refund windows, fees, dates). If you
			  don't have the information, say you'll connect them to a human agent.
			- Keep responses to a few short sentences unless listing simple steps.
			""";

	// System prompt for the intent classifier. It must return EXACTLY one label.
	private static final String INTENT_SYSTEM = """
			You are an intent classifier for an customer care assistant.
			Read the customer's message and classify it into EXACTLY ONE of the
			labels below. Reply with ONLY the label text — no punctuation, no
			explanation, no quotes.

			LABELS and when to use them:
			- ORDER_WHERE            : where is my order / current location / order status
			- ORDER_WHEN_DELIVERED   : when will it arrive / delivery date / ETA
			- ORDER_TRACK            : how to track / tracking link / tracking number request
			- TRACKING_BROKEN        : tracking number not working / invalid / shows nothing
			- ORDER_ITEMS            : what did I order / show my ordered items / where are my items
			- PICKED_ITEMS           : which items were picked / picked items / packed items
			- DELIVERED_ITEMS        : which items were delivered / what was delivered / rejected/missing items
			- CHANGE_ADDRESS         : change or update the delivery address
			- CANCEL_ORDER           : cancel an order
			- MODIFY_ITEMS           : add or remove items / change quantity of an order
			- WRONG_ORDER            : placed the wrong order / ordered by mistake
			- CHARGED_TWICE          : double charged / duplicate payment / billing error
			- RETURN_ITEM            : how to return an item / start a return
			- REFUND_STATUS          : refund status / when will I get my refund
			- DAMAGED_ITEM           : item arrived damaged / broken / defective
			- ORDER_DELAYED          : order is late / delayed / taking too long
			- NOT_RECEIVED           : marked delivered but not received / missing parcel
			- RESCHEDULE_DELIVERY    : reschedule / change the delivery day or slot
			- EXPRESS_DELIVERY       : same-day / express / faster delivery options
			- SAVE_ADDRESSES         : save / manage multiple addresses / address book
			- HUMAN_AGENT            : wants to talk to a human / real person / agent
			- UNKNOWN                : anything else, unclear, or out of scope

			If the message reasonably fits one label, choose it. Only use UNKNOWN
			when nothing else fits. Reply with the single label and nothing else.
			""";

	public List<ChatRequestDto.MessageInfo> getSessionHistory(UUID sessionId) {
		return messageRepo.findBySessionIdOrderByCreatedAtAsc(sessionId).stream()
				.map(m -> ChatRequestDto.MessageInfo.builder().messageId(m.getMessageId()).role(m.getRole())
						.content(m.getContent()).sqlQuery(m.getSqlQuery())
						.sources(m.getSources() != null ? List.of(m.getSources()) : List.of())
						.createdAt(m.getCreatedAt()).build())
				.collect(Collectors.toList());
	}

	private List<String> getOrderIdFromSession(String userMessage, UUID sessionId) {
		List<String> orderIds = extractOrderIds(userMessage);
		if (orderIds.isEmpty()) {
			List<MessageInfo> messageInfos = getSessionHistory(sessionId);
			for (MessageInfo messageInfo : messageInfos) {
				orderIds = extractOrderIds(messageInfo.getContent());
				if (!orderIds.isEmpty()) {
					break;
				}
			}
		}
		log.info("orderIds:{} userMessage:{}", orderIds, userMessage);
		return orderIds;
	}

	public Flux<String> streamCareChat(String userMessage, UUID sessionId, String username) {
		CareIntent intent = classify(userMessage);
		List<String> orderIds = getOrderIdFromSession(userMessage, sessionId);

		String orderId = orderIds.isEmpty() ? null : orderIds.get(0).toUpperCase();

		log.info("Care chat intent={} order={} user={}", intent, orderId, username);

		String reply;
		String hint = "";

		switch (intent) {
		// ---- DATA-BACKED: order status / tracking / delivery timing ----
		case ORDER_WHERE, ORDER_WHEN_DELIVERED, ORDER_DELAYED, ORDER_TRACK -> {
			if (orderId == null) {
				reply = askForOrderId();
			} else {
				Map<String, Object> o = orderService.getCustomerOrderStatus(orderId);
				if (o == null) {
					reply = orderNotFound(orderId);
				} else {
					boolean exceptional = Boolean.TRUE.equals(o.get("exceptional"));
					String grounding = buildOrderGrounding(o, intent);
					reply = phrase(userMessage, grounding);
					// Offer a human handoff only for genuine exception states.
					if (exceptional) {
						String team = teamForStatus(str(o.get("status")));
						hint = incidentHint(orderId, null, team,
								"Customer asked about order in " + str(o.get("statusLabel")) + " state");
					}
				}
			}
		}

		// ---- DATA-BACKED: order line items by state (ordered/picked/delivered) ----
		case ORDER_ITEMS, PICKED_ITEMS, DELIVERED_ITEMS -> {
			if (orderId == null) {
				reply = askForOrderId();
			} else {
				Map<String, Object> items = orderService.getOrderItemsByState(orderId);
				if (items == null) {
					reply = orderNotFound(orderId);
				} else {
					reply = phrase(userMessage, buildItemsGrounding(orderId, items, intent));
				}
			}
		}

		// ---- TRACKING NUMBER BROKEN: policy + optional handoff ----
		case TRACKING_BROKEN -> {
			reply = phrasePolicy(userMessage, CareIntent.TRACKING_BROKEN);
			if (orderId != null) {
				hint = incidentHint(orderId, null, "SUPPORT", "Tracking number not working");
			}
		}

		// ---- POLICY-ONLY intents ----
		case CHANGE_ADDRESS, CANCEL_ORDER, MODIFY_ITEMS, WRONG_ORDER, RETURN_ITEM, RESCHEDULE_DELIVERY,
				EXPRESS_DELIVERY, SAVE_ADDRESSES -> {
			reply = phrasePolicy(userMessage, intent);
		}

		// ---- NEEDS A HUMAN: raise incident to the right team ----
		case REFUND_STATUS -> {
			String basePolicy = carePolicyService.policyFor(CareIntent.REFUND_STATUS);
			String refund = orderId != null ? refundGrounding(orderId) : "";
			String grounding = (basePolicy == null ? "" : basePolicy)
					+ (refund.isEmpty() ? "" : "\n\nThis order's refund details:\n" + refund);
			if (grounding.isBlank()) {
				reply = "Let me connect you with a support agent who can check your refund.";
			} else {
				reply = phrase(userMessage, grounding);
			}
		}
		case CHARGED_TWICE -> {
			String pay = orderId != null ? paymentGrounding(orderId) : "";
			reply = phrase(userMessage, """
					The customer says they were charged twice. Apologise, reassure
					them our billing team will check and refund any duplicate
					charge, and tell them you're raising it now."""
					+ (pay.isEmpty() ? "" : "\n\nPayment on record:\n" + pay));
			hint = incidentHint(orderId, null, "BILLING", "Customer reports duplicate charge");
		}
		case DAMAGED_ITEM -> {
			reply = phrase(userMessage, """
					The customer received a damaged item. Apologise sincerely, tell
					them we'll arrange a replacement or refund, and that you're
					raising it with our support team now.""");
			hint = incidentHint(orderId, null, "SUPPORT", "Item arrived damaged");
		}
		case NOT_RECEIVED -> {
			reply = phrase(userMessage, """
					The courier marked the order delivered but the customer didn't
					receive it. Apologise, tell them our support team will
					investigate with the courier, and that you're raising it now.""");
			hint = incidentHint(orderId, null, "SUPPORT", "Marked delivered but not received");
		}
		case HUMAN_AGENT -> {
			reply = phrase(userMessage, """
					The customer wants to speak to a human agent. Reassure them
					kindly that you're connecting them and a support agent will
					follow up. Keep it short.""");
			hint = incidentHint(orderId, null, "SUPPORT", "Customer requested a human agent");
		}

		// ---- UNKNOWN / out of scope ----
		default -> reply = """
				I can help with orders, deliveries, returns, refunds, payments,
				and your account. Could you tell me a bit more about what you need
				— and your order number if it's about a specific order?""";
		}

		chatbotService.persistCareTurn(username, sessionId, userMessage, reply);
		return Flux.just(reply + hint);
	}

	// ====================================================================
	// Intent classification — LLM FIRST, keyword fallback on failure
	// ====================================================================

	/**
	 * Detect the customer's intent using the LLM. The model is constrained to
	 * return exactly one CareIntent label; we parse it defensively. If the call
	 * fails or returns something unrecognisable, we fall back to keyword rules so
	 * the agent never breaks.
	 */
	private CareIntent classify(String message) {
		if (message == null || message.isBlank())
			return CareIntent.UNKNOWN;
		try {
			List<Message> messages = new ArrayList<>();
			messages.add(new SystemMessage(INTENT_SYSTEM));
			messages.add(new UserMessage("Customer message:\n\"" + message.trim() + "\"\n\nLabel:"));

			String raw = chatClient.prompt().messages(messages).call().content();
			CareIntent parsed = parseIntent(raw);
			log.info("LLM intent raw='{}' parsed={}", raw == null ? "" : raw.trim(), parsed);

			// If the LLM is unsure, give keywords a chance before settling on UNKNOWN.
			if (parsed == CareIntent.UNKNOWN) {
				CareIntent kw = classifyByKeywords(message);
				return kw != CareIntent.UNKNOWN ? kw : CareIntent.UNKNOWN;
			}
			return parsed;
		} catch (Exception e) {
			log.warn("LLM intent classification failed; using keyword fallback. {}", e.getMessage());
			return classifyByKeywords(message);
		}
	}

	/** Map the model's raw text to a CareIntent, tolerant of extra wording/case. */
	private CareIntent parseIntent(String raw) {
		if (raw == null)
			return CareIntent.UNKNOWN;
		String cleaned = raw.trim().toUpperCase().replaceAll("[^A-Z_]", " ") // strip quotes/punctuation/newlines
				.trim();
		if (cleaned.isEmpty())
			return CareIntent.UNKNOWN;

		// Exact match first.
		for (CareIntent ci : CareIntent.values()) {
			if (cleaned.equals(ci.name()))
				return ci;
		}
		// Otherwise, find a label token contained in the response.
		for (CareIntent ci : CareIntent.values()) {
			if (ci == CareIntent.UNKNOWN)
				continue;
			if (cleaned.contains(ci.name()))
				return ci;
		}
		return CareIntent.UNKNOWN;
	}

	/**
	 * Keyword-based classifier — used ONLY as a fallback when the LLM call fails or
	 * is unsure. Ordered by specificity.
	 */
	private CareIntent classifyByKeywords(String message) {
		String m = message == null ? "" : message.toLowerCase();

		// 3. Payment
		if (contains(m, "charged twice", "double charge", "charged me twice", "duplicate charge", "charged 2"))
			return CareIntent.CHARGED_TWICE;

		// 4. Returns / refunds / damaged
		if (contains(m, "damaged", "broken", "arrived damaged", "defective"))
			return CareIntent.DAMAGED_ITEM;
		if (contains(m, "refund") && contains(m, "when", "status", "how long", "where"))
			return CareIntent.REFUND_STATUS;
		if (contains(m, "return"))
			return CareIntent.RETURN_ITEM;

		// 5. Delivery issues
		if (contains(m, "delivered", "says delivered") && contains(m, "didn't", "did not", "not receive", "haven't"))
			return CareIntent.NOT_RECEIVED;
		if (contains(m, "reschedule", "change delivery date", "different day", "another day"))
			return CareIntent.RESCHEDULE_DELIVERY;
		if (contains(m, "same day", "same-day", "express", "next day", "faster delivery"))
			return CareIntent.EXPRESS_DELIVERY;
		if (contains(m, "delayed", "late", "taking too long", "still not here"))
			return CareIntent.ORDER_DELAYED;

		// 1. Status & tracking
		if (contains(m, "tracking") && contains(m, "not working", "isn't working", "doesn't work", "invalid", "broken"))
			return CareIntent.TRACKING_BROKEN;
		if (contains(m, "track", "tracking number", "tracking link"))
			return CareIntent.ORDER_TRACK;
		if (contains(m, "when will", "delivery date", "arrive", "get my order", "be delivered"))
			return CareIntent.ORDER_WHEN_DELIVERED;
		if (contains(m, "where is", "where's", "location of my order", "status of", "order status"))
			return CareIntent.ORDER_WHERE;

		// 2b. Item details
		if (contains(m, "picked item", "items picked", "what was picked", "picked items"))
			return CareIntent.PICKED_ITEMS;
		if (contains(m, "delivered item", "items delivered", "what was delivered", "rejected item", "missing item"))
			return CareIntent.DELIVERED_ITEMS;
		if (contains(m, "what did i order", "my items", "ordered items", "items in order", "what items"))
			return CareIntent.ORDER_ITEMS;

		// 2. Placement & changes
		if (contains(m, "change") && contains(m, "address"))
			return CareIntent.CHANGE_ADDRESS;
		if (contains(m, "cancel"))
			return CareIntent.CANCEL_ORDER;
		if (contains(m, "add item", "remove item", "add/remove", "add or remove", "change item", "modify"))
			return CareIntent.MODIFY_ITEMS;
		if (contains(m, "wrong order", "placed the wrong", "ordered the wrong", "mistake"))
			return CareIntent.WRONG_ORDER;

		// 6. Account & support
		if (contains(m, "human", "real person", "agent", "representative", "speak to someone", "talk to someone"))
			return CareIntent.HUMAN_AGENT;
		if (contains(m, "save") && contains(m, "address"))
			return CareIntent.SAVE_ADDRESSES;
		if (contains(m, "multiple address", "address book", "saved address"))
			return CareIntent.SAVE_ADDRESSES;

		return CareIntent.UNKNOWN;
	}

	// ====================================================================
	// LLM phrasing helpers
	// ====================================================================

	/** Phrase a reply from arbitrary grounding text. */
	private String phrase(String userMessage, String grounding) {
		try {
			List<Message> messages = new ArrayList<>();
			messages.add(new SystemMessage(CARE_SYSTEM));
			messages.add(new UserMessage("GROUNDING INFORMATION:\n" + grounding + "\n\nCUSTOMER MESSAGE:\n"
					+ userMessage + "\n\nReply to the customer using only the grounding information."));
			return chatClient.prompt().messages(messages).call().content();
		} catch (Exception e) {
			log.error("Care phrasing failed", e);
			return "Sorry, I'm having trouble right now. Please try again in a moment.";
		}
	}

	/** Phrase a reply grounded in a policy; if no policy exists, hand off. */
	private String phrasePolicy(String userMessage, CareIntent intent) {
		String policy = carePolicyService.policyFor(intent);
		if (policy == null || policy.isBlank()) {
			return "I'm not certain of the exact policy here, so let me connect you "
					+ "with a support agent who can help.";
		}
		return phrase(userMessage, policy);
	}

	// ====================================================================
	// Live-order grounding (from customer_order table)
	// ====================================================================
	/**
	 * Build grounding describing the order's line items in the requested state(s).
	 */
	@SuppressWarnings("unchecked")
	private String buildItemsGrounding(String orderId, Map<String, Object> items, CareIntent intent) {
		StringBuilder g = new StringBuilder();
		g.append("LIVE ORDER ITEMS for ").append(orderId).append(" (customer-facing, safe to share):\n");

		// Choose which states to show based on the question.
		List<String> states = switch (intent) {
		case PICKED_ITEMS -> List.of("picked");
		case DELIVERED_ITEMS -> List.of("delivered", "rejected");
		default -> List.of("ordered"); // ORDER_ITEMS
		};

		boolean anyShown = false;
		for (String state : states) {
			List<Map<String, Object>> list = (List<Map<String, Object>>) items.get(state);
			if (list == null || list.isEmpty())
				continue;
			anyShown = true;
			g.append("\n").append(capitalize(state)).append(" items:\n");
			for (Map<String, Object> it : list) {
				g.append("  - ").append(str(it.get("itemDescription"))).append(" (type: ")
						.append(str(it.get("itemType"))).append(", qty: ").append(str(it.get("quantity"))).append(")");
				Object sub = it.get("substitute");
				if (Boolean.TRUE.equals(sub))
					g.append(" [substitute allowed]");
				Object age = it.get("minimumAgeRestricted");
				if (age instanceof Number n && n.intValue() > 0)
					g.append(" [age-restricted ").append(n.intValue()).append("+]");
				g.append("\n");
			}
		}

		// Mention age verification if any shown item is age-restricted.
		if (anyShown) {
			g.append("\nIf any item is age-restricted, mention that age verification ");
			g.append("may be required on delivery. Present the items in a clear, friendly list. ");
			g.append("Do not invent items beyond those listed above.");
		} else {
			g.append("\nThere are no items recorded in that state yet. Tell the customer ");
			g.append("politely (e.g. items haven't been picked/delivered yet) based on the question.");
		}
		g.append("\nNever mention internal systems, SQL, or error codes.");
		return g.toString();
	}

	/** Payment summary grounding for billing questions. */
	private String paymentGrounding(String orderId) {
		Map<String, Object> o = orderService.getCustomerOrderStatus(orderId);
		if (o == null)
			return "";
		StringBuilder g = new StringBuilder();
		if (o.get("paymentStatus") != null)
			g.append("- Payment status: ").append(str(o.get("paymentStatus"))).append("\n");
		if (o.get("paymentAmount") != null)
			g.append("- Amount charged: ").append(str(o.get("paymentAmount"))).append("\n");
		if (o.get("refundAmount") != null)
			g.append("- Refund on record: ").append(str(o.get("refundAmount"))).append("\n");
		return g.toString();
	}

	/** Refund summary grounding for refund-status questions. */
	private String refundGrounding(String orderId) {
		Map<String, Object> o = orderService.getCustomerOrderStatus(orderId);
		if (o == null)
			return "";
		StringBuilder g = new StringBuilder();
		g.append("- Order: ").append(orderId).append("\n");
		if (o.get("paymentStatus") != null)
			g.append("- Payment status: ").append(str(o.get("paymentStatus"))).append("\n");
		if (o.get("refundAmount") != null)
			g.append("- Refund amount: ").append(str(o.get("refundAmount"))).append("\n");
		if (o.get("statusLabel") != null)
			g.append("- Order status: ").append(str(o.get("statusLabel"))).append("\n");
		return g.toString();
	}

	private String capitalize(String s) {
		if (s == null || s.isEmpty())
			return s;
		return Character.toUpperCase(s.charAt(0)) + s.substring(1);
	}

	private String buildOrderGrounding(Map<String, Object> o, CareIntent intent) {
		StringBuilder g = new StringBuilder();
		g.append("LIVE ORDER STATUS (customer-facing, safe to share):\n");
		g.append("- Order: ").append(str(o.get("orderId"))).append("\n");
		g.append("- Status: ").append(str(o.get("statusLabel"))).append(" (").append(str(o.get("statusDescription")))
				.append(")\n");
		g.append("- Phase: ").append(str(o.get("phase"))).append("\n");
		if (o.get("itemSummary") != null)
			g.append("- Items: ").append(str(o.get("itemSummary"))).append("\n");
		if (o.get("carrier") != null)
			g.append("- Carrier: ").append(str(o.get("carrier"))).append("\n");
		if (o.get("trackingNumber") != null)
			g.append("- Tracking number: ").append(str(o.get("trackingNumber"))).append("\n");
		if (o.get("estimatedDelivery") != null)
			g.append("- Estimated delivery: ").append(str(o.get("estimatedDelivery"))).append("\n");
		if (o.get("statusNote") != null)
			g.append("- Note: ").append(str(o.get("statusNote"))).append("\n");

		// Tailor the instruction to the question.
		switch (intent) {
		case ORDER_TRACK -> g.append("\nThe customer wants to track the shipment. ")
				.append("Share the carrier and tracking number if present; otherwise tell them ")
				.append("tracking appears once the order ships, and point them to 'Track Shipment'.");
		case ORDER_WHEN_DELIVERED -> g.append("\nThe customer asks when it will arrive. ")
				.append("Give the estimated delivery if present; do NOT invent a date if it's absent.");
		case ORDER_DELAYED -> g.append("\nThe customer thinks it's delayed. ")
				.append("Explain the current status reassuringly using only the info above.");
		default -> g.append("\nTell the customer where the order is right now, briefly and warmly.");
		}
		g.append("\nNever mention internal systems, SQL, or error codes.");
		return g.toString();
	}

	/** Route exception states to the most relevant team. */
	private String teamForStatus(String status) {
		if (status == null)
			return "SUPPORT";
		return switch (status) {
		case "PAYMENT_FAILED" -> "BILLING";
		case "ON_HOLD" -> "OPERATIONS";
		default -> "SUPPORT"; // DELIVERY_FAILED, RETURNED_TO_SENDER, CANCELLED, etc.
		};
	}

	// ====================================================================
	// Small helpers
	// ====================================================================
	private List<String> extractOrderIds(String text) {
		List<String> ids = new ArrayList<>();
		Matcher m = ORDER_ID.matcher(text == null ? "" : text);
		while (m.find())
			ids.add(m.group());
		return ids;
	}

	private boolean contains(String haystack, String... needles) {
		for (String n : needles)
			if (haystack.contains(n))
				return true;
		return false;
	}

	private String str(Object o) {
		return o == null ? "UNKNOWN" : o.toString();
	}

	private String askForOrderId() {
		return "I'd be happy to help with that. Could you share your order number "
				+ "(it looks like ORD-12345) so I can look it up?";
	}

	private String orderNotFound(String orderId) {
		return "I couldn't find an order with the number " + orderId
				+ ". Could you double-check it? It usually looks like ORD-12345.";
	}

	/** Structured hint -> the UI renders a 'Raise Incident' / handoff button. */
	private String incidentHint(String orderId, String errorCode, String team, String reason) {
		return "\n\n[INCIDENT_AVAILABLE]:{" + "\"orderId\":\"" + (orderId == null ? "" : orderId) + "\","
				+ "\"errorCode\":\"" + (errorCode == null ? "" : errorCode) + "\"," + "\"team\":\"" + team + "\","
				+ "\"reason\":\"" + reason.replace("\"", "'") + "\"}";
	}
}
