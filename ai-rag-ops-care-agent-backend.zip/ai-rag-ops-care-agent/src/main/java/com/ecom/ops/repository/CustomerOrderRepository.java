package com.ecom.ops.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ecom.ops.model.CustomerOrder;
import com.ecom.ops.model.OrderStatus;

@Repository
public interface CustomerOrderRepository extends JpaRepository<CustomerOrder, Long> {

    Optional<CustomerOrder> findByOrderIdIgnoreCase(String orderId);

    List<CustomerOrder> findByStatus(OrderStatus status);

    List<CustomerOrder> findAllByOrderByOrderPlacedAtDesc();

    long countByStatus(OrderStatus status);

    boolean existsByOrderId(String orderId);
}
