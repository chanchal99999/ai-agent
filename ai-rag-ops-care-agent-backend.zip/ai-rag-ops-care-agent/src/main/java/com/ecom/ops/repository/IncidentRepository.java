package com.ecom.ops.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ecom.ops.model.Incident;
import com.ecom.ops.model.IncidentStatus;

@Repository
public interface IncidentRepository extends JpaRepository<Incident, Long> {

    Optional<Incident> findByIncidentId(UUID incidentId);

    /** All incidents, newest first — for OPERATIONS / ADMIN. */
    List<Incident> findAllByOrderByCreatedAtDesc();

    /** Incidents raised by a specific customer-care user — for their own view. */
    List<Incident> findByRaisedByOrderByCreatedAtDesc(String raisedBy);

    /** Filter by status (e.g. OPEN queue for ops). */
    List<Incident> findByStatusOrderByCreatedAtDesc(IncidentStatus status);

    /** Incidents for a given order. */
    List<Incident> findByOrderIdOrderByCreatedAtDesc(String orderId);

    /** Guard against duplicate open incidents for the same order+error. */
    @Query("""
           SELECT COUNT(i) > 0 FROM Incident i
           WHERE i.orderId = :orderId
             AND i.errorCode = :errorCode
             AND i.status IN (com.ecom.ops.model.IncidentStatus.OPEN,
                              com.ecom.ops.model.IncidentStatus.IN_PROGRESS)
           """)
    boolean existsOpenForOrderAndError(@Param("orderId") String orderId,
                                       @Param("errorCode") String errorCode);
}
