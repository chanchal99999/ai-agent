package com.ecom.ops.service;

/**
 * Customer-care intent categories. Each maps to either a data-backed lookup,
 * a policy answer, or a human/incident handoff (or a combination).
 */
public enum CareIntent {

    // 1. Order Status & Tracking
    ORDER_WHERE,            // Where is my order right now?
    ORDER_WHEN_DELIVERED,   // When will my order be delivered?
    ORDER_TRACK,            // How can I track the shipment?
    TRACKING_BROKEN,        // Tracking number isn't working

    // 2b. Order Item Details (ordered / picked / delivered items)
    ORDER_ITEMS,            // What items did I order? where are my ordered items?
    PICKED_ITEMS,           // Which items were picked?
    DELIVERED_ITEMS,        // Which items were delivered?

    // 2. Order Placement & Changes
    CHANGE_ADDRESS,         // Change delivery address after placing the order
    CANCEL_ORDER,           // How do I cancel my order?
    MODIFY_ITEMS,           // Add/remove items from my order
    WRONG_ORDER,            // Placed the wrong order � options?

    // 3. Payment & Billing
    CHARGED_TWICE,          // Why was I charged twice? (-> BILLING incident)

    // 4. Returns, Refunds & Replacements
    RETURN_ITEM,            // How do I return an item?
    REFUND_STATUS,          // When will I get my refund?
    DAMAGED_ITEM,           // Item arrived damaged (-> SUPPORT incident)

    // 5. Delivery Issues
    ORDER_DELAYED,          // My order is delayed � why?
    NOT_RECEIVED,           // Courier says delivered but not received (-> SUPPORT incident)
    RESCHEDULE_DELIVERY,    // Can I reschedule my delivery?
    EXPRESS_DELIVERY,       // Same-day / express delivery?

    // 6. Account & Support
    SAVE_ADDRESSES,         // Save multiple addresses?
    HUMAN_AGENT,            // Speak to a human agent (-> SUPPORT incident)

    // fallback
    UNKNOWN
}
