package com.ecom.ops.service;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

import com.ecom.ops.model.FulfilmentJobQueue;
import com.ecom.ops.model.ManageFulfilmentJobQueue;
import com.ecom.ops.repository.FulfilmentJobQueueRepository;
import com.ecom.ops.repository.ManageFulfilmentJobQueueRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class DataContextService {

	private final ManageFulfilmentJobQueueRepository manageFulfilmentRepo;
	private final FulfilmentJobQueueRepository fulfilmentJobRepo;
	private final com.ecom.ops.repository.CustomerOrderRepository customerOrderRepo;

	private static final Pattern ORDER_ID_PATTERN = Pattern.compile("ORD-\\d+", Pattern.CASE_INSENSITIVE);
	private static final Pattern ERROR_CODE_PATTERN = Pattern.compile("ACC-API-[A-Z-]+ERROR", Pattern.CASE_INSENSITIVE);

	private static final int DEFAULT_WINDOW_HOURS = 1;

	// ── Pattern helpers ────────────────────────────────────────────────

	public boolean isErrorCodeOnlyRequest(String message) {
		boolean hasErrorCode = ERROR_CODE_PATTERN.matcher(message.toUpperCase()).find();
		if (!hasErrorCode)
			return false;
		// If an order ID is also present, the order flow handles it — not this path
		boolean hasOrderId = ORDER_ID_PATTERN.matcher(message.toUpperCase()).find();
		return !hasOrderId;
	}
	
	public List<String> extractOrderIds(String text) {
		List<String> ids = new ArrayList<>();
		Matcher m = ORDER_ID_PATTERN.matcher(text.toUpperCase());
		while (m.find())
			ids.add(m.group());
		return ids;
	}

	public List<String> extractErrorCodes(String text) {
		List<String> codes = new ArrayList<>();
		if (text == null)
			return codes;
		Matcher m = ERROR_CODE_PATTERN.matcher(text.toUpperCase());
		while (m.find())
			codes.add(m.group());
		return codes;
	}

	// ── Intent detection ───────────────────────────────────────────────

	/**
	 * Detects if the user wants the pick report payload for an order. e.g. "show me
	 * the pick report for ORD-10001" "what was picked for ORD-10001" "picked items
	 * for ORD-10001"
	 */
	public boolean isPickReportRequest(String message) {
		String lower = message.toLowerCase();
		return lower.matches(
				".*(pick\\s*report|picked\\s*item|picked\\s*product|pick\\s*payload|what\\s+was\\s+picked|show\\s+pick|get\\s+pick|pick\\s+detail|picking\\s+report).*");
	}

	/**
	 * Detects if the user wants the delivery report payload for an order. e.g.
	 * "show me the delivery report for ORD-10001" "what was delivered for
	 * ORD-10001" "delivery payload ORD-10001"
	 */
	public boolean isDeliveryReportRequest(String message) {
		String lower = message.toLowerCase();
		return lower.matches(
				".*(delivery\\s*report|delivered\\s*item|delivered\\s*product|delivery\\s*payload|what\\s+was\\s+delivered|show\\s+delivery|get\\s+delivery|delivery\\s+detail).*");
	}

	/**
	 * Detects a simple status check — user wants the high-level status of each
	 * stage without full payload detail. e.g. "what is the status of ORD-10001"
	 * "status for ORD-10001" "order status ORD-10001"
	 */
	public boolean isSimpleStatusRequest(String message) {
		String lower = message.toLowerCase();
		// Exclude pick/delivery specific requests — those have richer handlers
		if (isPickReportRequest(message) || isDeliveryReportRequest(message))
			return false;
		return lower.matches(".*(status|progress|state|update|what.*(happen|going on)|how.*order|track).*");
	}

	/**
	 * Detects bulk listing — "show all jobs", "list failed orders", etc. Excludes
	 * specific-order queries.
	 */
	public boolean isBulkListingRequest(String message) {
		String lower = message.toLowerCase();
		boolean hasListVerb = lower.matches(
				".*(show|list|get|display|give me|fetch|find).*(all|every|failed|error|exception|pending|recent|latest|current).*")
				|| lower.matches(
						".*(all|every|failed|error|exception|pending|recent|latest|current).*(job|order|queue|event|issue|problem).*");
		boolean hasSubject = lower.contains("job") || lower.contains("order") || lower.contains("queue")
				|| lower.contains("event") || lower.contains("fulfilment") || lower.contains("fulfillment");
		boolean hasSpecificId = ORDER_ID_PATTERN.matcher(lower.toUpperCase()).find();
		return hasListVerb && hasSubject && !hasSpecificId;
	}

	// ── Full live snapshot ─────────────────────────────────────────────

	public String buildLiveDataContext() {
		StringBuilder ctx = new StringBuilder();

		ctx.append("=== MANAGE FULFILMENT JOB QUEUE ===\n");
		List<ManageFulfilmentJobQueue> allManage = manageFulfilmentRepo.findAll();
		if (allManage.isEmpty()) {
			ctx.append("No records.\n");
		} else {
			for (ManageFulfilmentJobQueue m : allManage) {
				ctx.append(String.format(
						"EventId:%s | OrderId:%s | Status:%s | FulfilmentId:%s | EventType:%s | Retry:%d | Exception:%s\n",
						m.getEventId(), m.getOrderId(), m.getOperationStatus(),
						m.getFulfilmentId() != null ? m.getFulfilmentId() : "N/A", m.getEventType(),
						m.getRetryAttempt() != null ? m.getRetryAttempt() : 0,
						m.getException() != null ? m.getException() : "None"));
			}
		}

		ctx.append("\n=== FULFILMENT JOB QUEUE ===\n");
		List<FulfilmentJobQueue> allFul = fulfilmentJobRepo.findAll();
		if (allFul.isEmpty()) {
			ctx.append("No records.\n");
		} else {
			for (FulfilmentJobQueue f : allFul) {
				ctx.append(String.format(
						"EventId:%s | OrderId:%s | FulfilmentId:%s | EventType:%s | Status:%s | Retry:%d | Exception:%s\n",
						f.getEventId(), f.getOrderId(), f.getFulfilmentId(), f.getEventType(), f.getOperationStatus(),
						f.getRetryAttempt() != null ? f.getRetryAttempt() : 0,
						f.getException() != null ? f.getException() : "None"));
			}
		}

		List<ManageFulfilmentJobQueue> failedM = manageFulfilmentRepo.findFailedJobs();
		List<FulfilmentJobQueue> failedF = fulfilmentJobRepo.findFailedJobs();
		ctx.append("\n=== FAILED / ERROR JOBS ===\n");
		ctx.append("Failed Manage Jobs: ").append(failedM.size()).append("\n");
		failedM.forEach(
				m -> ctx.append(String.format("  OrderId:%s | Exception:%s\n", m.getOrderId(), m.getException())));
		ctx.append("Failed Fulfilment Jobs: ").append(failedF.size()).append("\n");
		failedF.forEach(f -> ctx.append(String.format("  OrderId:%s | EventType:%s | Exception:%s\n", f.getOrderId(),
				f.getEventType(), f.getException())));

		return ctx.toString();
	}

	// ── 1-hour windowed context ────────────────────────────────────────

	public WindowedContext buildWindowedDataContext() {
		OffsetDateTime to = OffsetDateTime.now();
		OffsetDateTime from = to.minusHours(DEFAULT_WINDOW_HOURS);
		String windowLabel = String.format("Last %d Hour%s (since %s)", DEFAULT_WINDOW_HOURS,
				DEFAULT_WINDOW_HOURS == 1 ? "" : "s", from.format(DateTimeFormatter.ofPattern("HH:mm dd-MMM-yyyy")));

		List<ManageFulfilmentJobQueue> manageRows = manageFulfilmentRepo.findByDateRange(from, to);
		List<FulfilmentJobQueue> fulfilRows = fulfilmentJobRepo.findByDateRange(from, to);
		List<ManageFulfilmentJobQueue> failedManage = manageFulfilmentRepo.findFailedJobsByDateRange(from, to);
		List<FulfilmentJobQueue> failedFul = fulfilmentJobRepo.findFailedJobsByDateRange(from, to);

		long totalManage = manageFulfilmentRepo.countByDateRange(from, to);
		long totalFulfilment = fulfilRows.size();

		StringBuilder ctx = new StringBuilder();
		ctx.append("=== DATA WINDOW: ").append(windowLabel).append(" ===\n\n");

		ctx.append("--- MANAGE FULFILMENT JOB QUEUE (").append(windowLabel).append(") ---\n");
		ctx.append("Total events in window: ").append(totalManage).append("\n");
		if (manageRows.isEmpty()) {
			ctx.append("No manage fulfilment events in the last ").append(DEFAULT_WINDOW_HOURS).append(" hour(s).\n");
		} else {
			for (ManageFulfilmentJobQueue m : manageRows) {
				ctx.append(String.format(
						"EventId:%s | OrderId:%s | Status:%s | FulfilmentId:%s | EventType:%s | Retry:%d | Exception:%s\n",
						m.getEventId(), m.getOrderId(), m.getOperationStatus(),
						m.getFulfilmentId() != null ? m.getFulfilmentId() : "N/A", m.getEventType(),
						m.getRetryAttempt() != null ? m.getRetryAttempt() : 0,
						m.getException() != null ? m.getException() : "None"));
			}
		}

		ctx.append("\n--- FULFILMENT JOB QUEUE (").append(windowLabel).append(") ---\n");
		ctx.append("Total events in window: ").append(totalFulfilment).append("\n");
		if (fulfilRows.isEmpty()) {
			ctx.append("No fulfilment job events in the last ").append(DEFAULT_WINDOW_HOURS).append(" hour(s).\n");
		} else {
			for (FulfilmentJobQueue f : fulfilRows) {
				ctx.append(String.format(
						"EventId:%s | OrderId:%s | FulfilmentId:%s | EventType:%s | Status:%s | Retry:%d | Exception:%s\n",
						f.getEventId(), f.getOrderId(), f.getFulfilmentId(), f.getEventType(), f.getOperationStatus(),
						f.getRetryAttempt() != null ? f.getRetryAttempt() : 0,
						f.getException() != null ? f.getException() : "None"));
			}
		}

		ctx.append("\n--- FAILED JOBS IN WINDOW ---\n");
		ctx.append("Failed Manage Jobs: ").append(failedManage.size()).append("\n");
		if (failedManage.isEmpty()) {
			ctx.append("  No failed manage jobs in the last ").append(DEFAULT_WINDOW_HOURS).append(" hour(s).\n");
		} else {
			for (ManageFulfilmentJobQueue m : failedManage) {
				ctx.append(String.format("  OrderId:%s | EventId:%s | Retry:%d | Exception:%s\n", m.getOrderId(),
						m.getEventId(), m.getRetryAttempt() != null ? m.getRetryAttempt() : 0, m.getException()));
			}
		}
		ctx.append("Failed Fulfilment Jobs: ").append(failedFul.size()).append("\n");
		if (failedFul.isEmpty()) {
			ctx.append("  No failed fulfilment jobs in the last ").append(DEFAULT_WINDOW_HOURS).append(" hour(s).\n");
		} else {
			for (FulfilmentJobQueue f : failedFul) {
				ctx.append(String.format("  OrderId:%s | EventId:%s | EventType:%s | Retry:%d | Exception:%s\n",
						f.getOrderId(), f.getEventId(), f.getEventType(),
						f.getRetryAttempt() != null ? f.getRetryAttempt() : 0, f.getException()));
			}
		}

		return new WindowedContext(ctx.toString(), windowLabel, DEFAULT_WINDOW_HOURS, totalManage, totalFulfilment,
				failedManage.size(), failedFul.size());
	}

	// ── Rich order context ─────────────────────────────────────────────
	// intent flags control whether pick/delivery payloads are expanded inline

	public OrderContext buildOrderContext(String orderId, QueryIntent intent) {
		List<ManageFulfilmentJobQueue> mRecords = manageFulfilmentRepo.findByOrderId(orderId);
		List<FulfilmentJobQueue> fRecords = fulfilmentJobRepo.findByOrderId(orderId);

		StringBuilder ctx = new StringBuilder();
		List<String> detectedErrorCodes = new ArrayList<>();
		List<String> detectedExceptions = new ArrayList<>();
		boolean hasErrors = false;
		boolean isCritical = false;

		ctx.append("=== ORDER STATUS REPORT FOR ").append(orderId).append(" ===\n\n");

		// ── Live customer-facing status (customer_order table) ──────────
		customerOrderRepo.findByOrderIdIgnoreCase(orderId).ifPresent(co -> {
			ctx.append("--- LIVE CUSTOMER STATUS ---\n");
			ctx.append("  Status: ").append(co.getStatus().getLabel())
			   .append(" (").append(co.getStatus().getPhase().getLabel()).append(")\n");
			ctx.append("  Description: ").append(co.getStatus().getDescription()).append("\n");
			if (co.getCarrier() != null)
				ctx.append("  Carrier: ").append(co.getCarrier())
				   .append("  Tracking: ").append(co.getTrackingNumber()).append("\n");
			if (co.getEstimatedDelivery() != null)
				ctx.append("  Estimated Delivery: ").append(co.getEstimatedDelivery()).append("\n");
			if (co.getStatusNote() != null)
				ctx.append("  Note: ").append(co.getStatusNote()).append("\n");
			ctx.append("\n");
		});

		// ── Manage fulfilment events ────────────────────────────────────
		ctx.append("--- MANAGE FULFILMENT EVENTS ---\n");
		if (mRecords.isEmpty()) {
			ctx.append("  [NOT FOUND] No records in manage_fulfilment_job_queue for this order.\n");
		} else {
			for (ManageFulfilmentJobQueue m : mRecords) {
				ctx.append(String.format(
						"  EventId: %s\n  EventType: %s\n  Status: %s\n  FulfilmentId: %s\n  RetryAttempt: %d\n",
						m.getEventId(), m.getEventType(), m.getOperationStatus(),
						m.getFulfilmentId() != null ? m.getFulfilmentId() : "NULL — fulfilment not created",
						m.getRetryAttempt() != null ? m.getRetryAttempt() : 0));
				// Always include the order request so the AI can show ordered items
				if (m.getOrderRequest() != null) {
					ctx.append("  ORDER_REQUEST_PAYLOAD: ").append(m.getOrderRequest()).append("\n");
				}
				if (m.getException() != null) {
					hasErrors = true;
					detectedExceptions.add(m.getException());
					extractErrorCodes(m.getException()).stream().filter(ec -> !detectedErrorCodes.contains(ec))
							.forEach(detectedErrorCodes::add);
					ctx.append("  *** ERROR DETECTED ***\n");
					ctx.append("  Exception: ").append(m.getException()).append("\n");
					ctx.append(m.getRetryAttempt() != null && m.getRetryAttempt() >= 3
							? "  SEVERITY: CRITICAL (retry_attempt >= 3)\n"
							: "  SEVERITY: HIGH\n");
					isCritical = isCritical || (m.getRetryAttempt() != null && m.getRetryAttempt() >= 3);
				}
				ctx.append("\n");
			}
		}

		// ── Fulfilment job events ───────────────────────────────────────
		ctx.append("--- FULFILMENT JOB EVENTS (Pick & Delivery) ---\n");
		if (fRecords.isEmpty()) {
			ctx.append("  [NOT STARTED] No pick or delivery events found.\n");
		} else {
			for (FulfilmentJobQueue f : fRecords) {
				boolean isPick = "pickReport".equals(f.getEventType());
				boolean isDelivery = "deliveryReport".equals(f.getEventType());

				ctx.append(String.format(
						"  EventId: %s\n  EventType: %s\n  FulfilmentId: %s\n  Status: %s\n  RetryAttempt: %d\n",
						f.getEventId(), f.getEventType(), f.getFulfilmentId(), f.getOperationStatus(),
						f.getRetryAttempt() != null ? f.getRetryAttempt() : 0));

				// Include enrich_request payload when:
				// - User explicitly asked for pick report AND this is a pickReport event
				// - User explicitly asked for delivery report AND this is a deliveryReport
				// event
				// - User asked for full status (show everything)
				// - Always include when there is an error (for diagnosis)
				boolean includePayload = (intent.wantPickPayload && isPick)
						|| (intent.wantDeliveryPayload && isDelivery) || intent.isFullDetail
						|| f.getException() != null;

				if (includePayload && f.getEnrichRequest() != null) {
					if (isPick) {
						ctx.append("  PICK_REPORT_PAYLOAD (enrichRequest): ").append(f.getEnrichRequest()).append("\n");
						ctx.append(
								"  NOTE: pickedItem array above shows what was physically picked — itemId, description, orderedQty, pickedQty, substituted flag.\n");
					} else if (isDelivery) {
						ctx.append("  DELIVERY_REPORT_PAYLOAD (enrichRequest): ").append(f.getEnrichRequest())
								.append("\n");
						ctx.append(
								"  NOTE: deliveredItem array above shows what was delivered — itemId, description, deliveredQty, driverId, podSigned.\n");
					} else {
						ctx.append("  ENRICH_REQUEST_PAYLOAD: ").append(f.getEnrichRequest()).append("\n");
					}
				}

				if (f.getException() != null) {
					hasErrors = true;
					detectedExceptions.add(f.getException());
					extractErrorCodes(f.getException()).stream().filter(ec -> !detectedErrorCodes.contains(ec))
							.forEach(detectedErrorCodes::add);
					ctx.append("  *** ERROR DETECTED ***\n");
					ctx.append("  Exception: ").append(f.getException()).append("\n");
					ctx.append(f.getRetryAttempt() != null && f.getRetryAttempt() >= 3
							? "  SEVERITY: CRITICAL (retry_attempt >= 3)\n"
							: "  SEVERITY: HIGH\n");
					isCritical = isCritical || (f.getRetryAttempt() != null && f.getRetryAttempt() >= 3);
				}
				ctx.append("\n");
			}
		}

		// ── Lifecycle summary ───────────────────────────────────────────
		ctx.append("--- ORDER LIFECYCLE SUMMARY ---\n");
		String fulfilmentStatus = mRecords.stream().map(ManageFulfilmentJobQueue::getOperationStatus).findFirst()
				.orElse("UNKNOWN");
		boolean fulfilmentCreated = mRecords.stream().anyMatch(m -> m.getFulfilmentId() != null);
		boolean pickCompleted = fRecords.stream()
				.anyMatch(f -> "pickReport".equals(f.getEventType()) && "COMPLETED".equals(f.getOperationStatus()));
		boolean deliveryCompleted = fRecords.stream()
				.anyMatch(f -> "deliveryReport".equals(f.getEventType()) && "COMPLETED".equals(f.getOperationStatus()));
		boolean pickFailed = fRecords.stream()
				.anyMatch(f -> "pickReport".equals(f.getEventType()) && "API_EXCEPTION".equals(f.getOperationStatus()));
		boolean deliveryFailed = fRecords.stream().anyMatch(
				f -> "deliveryReport".equals(f.getEventType()) && "API_EXCEPTION".equals(f.getOperationStatus()));

		ctx.append(String.format("  Stage 1 — Fulfilment Allocated : %s\n", fulfilmentStatus));
		ctx.append(
				String.format("  Stage 2 — Fulfilment Created   : %s\n", fulfilmentCreated ? "YES" : "NO — BLOCKED"));
		ctx.append(String.format("  Stage 3 — Pick Report          : %s\n",
				pickCompleted ? "COMPLETED" : pickFailed ? "FAILED" : "NOT_STARTED"));
		ctx.append(String.format("  Stage 4 — Delivery Report      : %s\n",
				deliveryCompleted ? "COMPLETED" : deliveryFailed ? "FAILED" : "NOT_STARTED"));
		ctx.append(String.format("  Overall Health                 : %s\n", isCritical
				? "CRITICAL — IMMEDIATE ACTION REQUIRED"
				: hasErrors ? "ERROR — ACTION REQUIRED"
						: deliveryCompleted ? "HEALTHY — ORDER FULLY COMPLETED"
								: fulfilmentCreated ? "IN_PROGRESS — NO ERRORS" : "BLOCKED — FULFILMENT NOT CREATED"));

		if (!detectedErrorCodes.isEmpty())
			ctx.append("\n  DETECTED ERROR CODES: ").append(String.join(", ", detectedErrorCodes)).append("\n");
		if (!detectedExceptions.isEmpty()) {
			ctx.append("  FULL EXCEPTION DETAILS:\n");
			detectedExceptions.forEach(ex -> ctx.append("    - ").append(ex).append("\n"));
		}

		return new OrderContext(ctx.toString(), detectedErrorCodes, detectedExceptions, hasErrors, isCritical);
	}

	// Backwards-compatible overload — full detail by default
	public OrderContext buildOrderContext(String orderId) {
		return buildOrderContext(orderId, QueryIntent.fullDetail());
	}

	// ── Value objects ──────────────────────────────────────────────────

	/** Captures what kind of payload the user is asking for */
	public static class QueryIntent {
		public final boolean wantPickPayload;
		public final boolean wantDeliveryPayload;
		public final boolean isFullDetail; // show everything
		public final boolean isSimpleStatus; // just status summary

		public QueryIntent(boolean wantPickPayload, boolean wantDeliveryPayload, boolean isFullDetail,
				boolean isSimpleStatus) {
			this.wantPickPayload = wantPickPayload;
			this.wantDeliveryPayload = wantDeliveryPayload;
			this.isFullDetail = isFullDetail;
			this.isSimpleStatus = isSimpleStatus;
		}

		public static QueryIntent pickOnly() {
			return new QueryIntent(true, false, false, false);
		}

		public static QueryIntent deliveryOnly() {
			return new QueryIntent(false, true, false, false);
		}

		public static QueryIntent fullDetail() {
			return new QueryIntent(true, true, true, false);
		}

		public static QueryIntent statusOnly() {
			return new QueryIntent(false, false, false, true);
		}

		public static QueryIntent both() {
			return new QueryIntent(true, true, false, false);
		}
	}

	public static class OrderContext {
		public final String contextText;
		public final List<String> errorCodes;
		public final List<String> exceptions;
		public final boolean hasErrors;
		public final boolean isCritical;

		public OrderContext(String contextText, List<String> errorCodes, List<String> exceptions, boolean hasErrors,
				boolean isCritical) {
			this.contextText = contextText;
			this.errorCodes = errorCodes;
			this.exceptions = exceptions;
			this.hasErrors = hasErrors;
			this.isCritical = isCritical;
		}
	}

	public static class WindowedContext {
		public final String contextText;
		public final String windowLabel;
		public final int windowHours;
		public final long totalManageEvents;
		public final long totalFulfilmentEvents;
		public final int failedManageCount;
		public final int failedFulfilmentCount;

		public WindowedContext(String contextText, String windowLabel, int windowHours, long totalManageEvents,
				long totalFulfilmentEvents, int failedManageCount, int failedFulfilmentCount) {
			this.contextText = contextText;
			this.windowLabel = windowLabel;
			this.windowHours = windowHours;
			this.totalManageEvents = totalManageEvents;
			this.totalFulfilmentEvents = totalFulfilmentEvents;
			this.failedManageCount = failedManageCount;
			this.failedFulfilmentCount = failedFulfilmentCount;
		}
	}
}
