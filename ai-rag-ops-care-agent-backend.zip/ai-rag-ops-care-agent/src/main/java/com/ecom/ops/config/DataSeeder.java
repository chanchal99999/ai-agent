package com.ecom.ops.config;

import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.ecom.ops.model.User;
import com.ecom.ops.model.UserRole;
import com.ecom.ops.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Seeds default users on startup if they don't already exist (idempotent).
 *   admin / admin123  -> ADMIN
 *   user  / user123   -> USER (operations)
 *   care  / care123   -> CUSTOMER_CARE
 *
 * Passwords are BCrypt-encoded at runtime, so they always match the configured
 * PasswordEncoder. Safe to leave enabled; existing users are never overwritten.
 */
@Configuration
@RequiredArgsConstructor
@Slf4j
public class DataSeeder {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Bean
    public ApplicationRunner seedDefaultUsers() {
        return args -> {
            ensure("admin101", "admin@agent.local", "admin123", "System Admin",     UserRole.ADMIN);
            ensure("user101",  "user@agent.local",  "user123",  "Ops User",          UserRole.USER);
            ensure("care101",  "care@agent.local",  "care123",  "Customer Care Agent", UserRole.CUSTOMER_CARE);
        };
    }

    private void ensure(String username, String email, String rawPassword,
                        String fullName, UserRole role) {
        if (userRepository.existsByUsername(username)) {
            return;
        }
        User u = User.builder()
                .username(username)
                .email(email)
                .passwordHash(passwordEncoder.encode(rawPassword))
                .fullName(fullName)
                .role(role)
                .build();
        userRepository.save(u);
        log.info("Seeded default user: {} ({})", username, role);
    }
}
