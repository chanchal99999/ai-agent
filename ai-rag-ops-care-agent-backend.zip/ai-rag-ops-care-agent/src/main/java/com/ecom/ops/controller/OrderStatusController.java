package com.ecom.ops.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.ops.model.OrderStatus;
import com.ecom.ops.service.OrderService;

import lombok.RequiredArgsConstructor;

/**
 * Exposes the common order-status reference table and a live order-status
 * lookup. Available to all authenticated roles (care, ops, admin).
 */
@RestController
@RequestMapping("/api/order-status")
@RequiredArgsConstructor
public class OrderStatusController {

    private final OrderService orderService;

    /** The 18 common order statuses, grouped by phase (reference table). */
    @GetMapping("/reference")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<Map<String, Object>>> reference() {
        List<Map<String, Object>> rows = java.util.Arrays.stream(OrderStatus.values())
                .map(st -> {
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("status", st.name());
                    m.put("label", st.getLabel());
                    m.put("phase", st.getPhase().getLabel());
                    m.put("description", st.getDescription());
                    m.put("exceptional", st.isExceptional());
                    return m;
                })
                .toList();
        return ResponseEntity.ok(rows);
    }

    /** Live status for a specific order (used by UI; agents read it internally). */
    @GetMapping("/{orderId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Map<String, Object>> liveStatus(@PathVariable String orderId) {
        Map<String, Object> status = orderService.getCustomerOrderStatus(orderId);
        if (status == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(status);
    }

    /** Line items for an order grouped by state (ordered/picked/delivered/rejected). */
    @GetMapping("/{orderId}/items")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Map<String, Object>> orderItems(@PathVariable String orderId) {
        Map<String, Object> items = orderService.getOrderItemsByState(orderId);
        if (items == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(items);
    }
}
