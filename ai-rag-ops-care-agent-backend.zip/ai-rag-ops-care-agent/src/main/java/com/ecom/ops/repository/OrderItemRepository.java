package com.ecom.ops.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ecom.ops.model.OrderItem;
import com.ecom.ops.model.OrderItemState;

@Repository
public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {

    List<OrderItem> findByOrderIdIgnoreCase(String orderId);

    List<OrderItem> findByOrderIdIgnoreCaseAndState(String orderId, OrderItemState state);

    boolean existsByOrderIdIgnoreCase(String orderId);
}
