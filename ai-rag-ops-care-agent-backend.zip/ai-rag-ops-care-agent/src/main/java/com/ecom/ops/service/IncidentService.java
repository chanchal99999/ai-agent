package com.ecom.ops.service;

import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecom.ops.dto.IncidentDtos.CreateIncidentRequest;
import com.ecom.ops.dto.IncidentDtos.IncidentResponse;
import com.ecom.ops.dto.IncidentDtos.UpdateIncidentRequest;
import com.ecom.ops.model.Incident;
import com.ecom.ops.model.IncidentSeverity;
import com.ecom.ops.model.IncidentStatus;
import com.ecom.ops.repository.IncidentRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class IncidentService {

    private final IncidentRepository incidentRepository;

    /** Raise a new incident (CUSTOMER_CARE). Skips duplicates for the same open order+error. */
    @Transactional
    public IncidentResponse raise(CreateIncidentRequest req, String raisedBy) {
        if (req.errorCode() != null
                && incidentRepository.existsOpenForOrderAndError(req.orderId(), req.errorCode())) {
            // Return the existing open incident instead of creating a duplicate.
            return incidentRepository.findByOrderIdOrderByCreatedAtDesc(req.orderId())
                    .stream()
                    .filter(i -> req.errorCode().equals(i.getErrorCode())
                            && (i.getStatus() == IncidentStatus.OPEN
                             || i.getStatus() == IncidentStatus.IN_PROGRESS))
                    .findFirst()
                    .map(IncidentResponse::from)
                    .orElseGet(() -> create(req, raisedBy));
        }
        return create(req, raisedBy);
    }

    /**
     * Raise an incident routed to a specific team (OPERATIONS / SUPPORT / BILLING).
     * Used by the customer-care agent for "needs a human" intents. Idempotent on
     * an open order+error like the standard raise.
     */
    @Transactional
    public IncidentResponse raiseForTeam(String orderId, String errorCode, String description,
                                         IncidentSeverity severity, String team, String raisedBy) {
        if (errorCode != null && incidentRepository.existsOpenForOrderAndError(orderId, errorCode)) {
            return incidentRepository.findByOrderIdOrderByCreatedAtDesc(orderId).stream()
                    .filter(i -> errorCode.equals(i.getErrorCode())
                            && (i.getStatus() == IncidentStatus.OPEN
                             || i.getStatus() == IncidentStatus.IN_PROGRESS))
                    .findFirst()
                    .map(IncidentResponse::from)
                    .orElseGet(() -> doCreate(orderId, errorCode, description, severity, team, raisedBy));
        }
        return doCreate(orderId, errorCode, description, severity, team, raisedBy);
    }

    private IncidentResponse doCreate(String orderId, String errorCode, String description,
                                      IncidentSeverity severity, String team, String raisedBy) {
        Incident incident = Incident.builder()
                .orderId(orderId)
                .errorCode(errorCode)
                .description(description)
                .severity(severity != null ? severity : IncidentSeverity.MEDIUM)
                .status(IncidentStatus.OPEN)
                .raisedBy(raisedBy)
                .assignedTeam(team != null ? team : "OPERATIONS")
                .build();
        Incident saved = incidentRepository.save(incident);
        log.info("Incident {} raised by {} for order {} -> team {}",
                saved.getIncidentId(), raisedBy, orderId, incident.getAssignedTeam());
        return IncidentResponse.from(saved);
    }

    private IncidentResponse create(CreateIncidentRequest req, String raisedBy) {
        Incident incident = Incident.builder()
                .orderId(req.orderId())
                .errorCode(req.errorCode())
                .description(req.description())
                .severity(req.severity() != null ? req.severity() : IncidentSeverity.MEDIUM)
                .status(IncidentStatus.OPEN)
                .raisedBy(raisedBy)
                .assignedTeam("OPERATIONS")
                .build();
        Incident saved = incidentRepository.save(incident);
        log.info("Incident {} raised by {} for order {} ({})",
                saved.getIncidentId(), raisedBy, req.orderId(), req.errorCode());
        return IncidentResponse.from(saved);
    }

    /**
     * Role-aware listing.
     *  - CUSTOMER_CARE: only incidents they raised.
     *  - USER / ADMIN (operations): all incidents.
     */
    @Transactional(readOnly = true)
    public List<IncidentResponse> list(String username, boolean isOperations) {
        List<Incident> incidents = isOperations
                ? incidentRepository.findAllByOrderByCreatedAtDesc()
                : incidentRepository.findByRaisedByOrderByCreatedAtDesc(username);
        return incidents.stream().map(IncidentResponse::from).toList();
    }

    @Transactional(readOnly = true)
    public List<IncidentResponse> byStatus(IncidentStatus status) {
        return incidentRepository.findByStatusOrderByCreatedAtDesc(status)
                .stream().map(IncidentResponse::from).toList();
    }

    /** Update status / assignment / notes (OPERATIONS / ADMIN only — enforced at controller). */
    @Transactional
    public IncidentResponse update(String incidentId, UpdateIncidentRequest req, String actor) {
        Incident incident = incidentRepository.findByIncidentId(UUID.fromString(incidentId))
                .orElseThrow(() -> new IllegalArgumentException("Incident not found: " + incidentId));

        if (req.status() != null)          incident.setStatus(req.status());
        if (req.assignedTo() != null)      incident.setAssignedTo(req.assignedTo());
        if (req.resolutionNotes() != null) incident.setResolutionNotes(req.resolutionNotes());

        // If an ops user starts working and no assignee set, assign to them.
        if (incident.getStatus() == IncidentStatus.IN_PROGRESS && incident.getAssignedTo() == null) {
            incident.setAssignedTo(actor);
        }
        return IncidentResponse.from(incidentRepository.save(incident));
    }
}
