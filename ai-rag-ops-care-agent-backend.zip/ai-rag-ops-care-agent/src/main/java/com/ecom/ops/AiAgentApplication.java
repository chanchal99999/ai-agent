package com.ecom.ops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@EnableAsync
@Slf4j
public class AiAgentApplication {
	public static void main(String[] args) {
		SpringApplication.run(AiAgentApplication.class, args);
		log.info("------In Memory Vector MySql Care Agent--------");
	}
}
