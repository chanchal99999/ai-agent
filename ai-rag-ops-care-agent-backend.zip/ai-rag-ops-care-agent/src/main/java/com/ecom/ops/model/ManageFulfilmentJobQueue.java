package com.ecom.ops.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.time.OffsetDateTime;

@Entity
@Table(name = "manage_fulfilment_job_queue")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ManageFulfilmentJobQueue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "event_id", nullable = false, unique = true)
    private String eventId;

    @Column(name = "event_datetime")
    private OffsetDateTime eventDatetime;

    @Column(name = "event_type")
    private String eventType;

    @Column(name = "order_id")
    private String orderId;

    @Column(name = "operation_status")
    private String operationStatus;

//    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "order_request", columnDefinition = "TEXT")
    private String orderRequest;

    @Column(name = "fulfilment_id")
    private String fulfilmentId;

    @Column(name = "exception", columnDefinition = "TEXT")
    private String exception;

    @Column(name = "retry_attempt")
    private Integer retryAttempt;

    @Column(name = "created_at")
    private OffsetDateTime createdAt;

    @Column(name = "updated_at")
    private OffsetDateTime updatedAt;

    @PrePersist
    public void prePersist() {
        createdAt = OffsetDateTime.now();
        updatedAt = OffsetDateTime.now();
        if (eventDatetime == null) eventDatetime = OffsetDateTime.now();
    }

    @PreUpdate
    public void preUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}
