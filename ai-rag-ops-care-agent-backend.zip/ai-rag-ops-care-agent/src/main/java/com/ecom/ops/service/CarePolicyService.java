package com.ecom.ops.service;

import java.util.EnumMap;
import java.util.Map;

import org.springframework.stereotype.Service;

/**
 * Customer-care policy knowledge base.
 *
 * Holds the procedural / policy answers for the customer-care agent, keyed by
 * intent. These are the "how do I..." answers that are NOT live order data.
 *
 * === EDIT THIS ===
 * Every policy below is a PLACEHOLDER marked with [EDIT THIS]. Replace the text
 * (windows, timelines, links, phone numbers) with your real customer-care
 * policies. The agent phrases its reply from this grounding text, so whatever
 * you put here is what customers will be told.
 *
 * Keeping these in one class makes them easy to find and change without touching
 * the agent logic. If you later prefer a database- or vector-backed KB, swap the
 * implementation of policyFor(...) � the agent only depends on that method.
 */
@Service
public class CarePolicyService {

    private final Map<CareIntent, String> policies = new EnumMap<>(CareIntent.class);

    public CarePolicyService() {
        // 1. Order Status & Tracking
        policies.put(CareIntent.ORDER_TRACK, """
                [EDIT THIS] You can track your shipment from the 'My Orders' page:
                open the order and tap 'Track Shipment' to see live status and the
                courier's tracking link. You'll also receive tracking updates by
                email/SMS once the order is dispatched.""");

        policies.put(CareIntent.TRACKING_BROKEN, """
                [EDIT THIS] If your tracking number isn't working, it can take up to
                24 hours to activate after dispatch. Please wait a few hours and try
                again. If it still doesn't work after 24 hours, we can look into it
                for you � I can raise this with our support team.""");

        // 2. Order Placement & Changes
        policies.put(CareIntent.CHANGE_ADDRESS, """
                [EDIT THIS] You can change the delivery address only while the order
                is still in 'Processing' (before it's dispatched). Go to 'My Orders'
                > select the order > 'Edit delivery address'. Once dispatched, the
                address can no longer be changed.""");

        policies.put(CareIntent.CANCEL_ORDER, """
                [EDIT THIS] You can cancel free of charge while the order is in
                'Processing'. Go to 'My Orders' > select the order > 'Cancel order'.
                Once it's out for delivery it can't be cancelled, but you can refuse
                delivery or return it after it arrives.""");

        policies.put(CareIntent.MODIFY_ITEMS, """
                [EDIT THIS] Items can be added or removed only while the order is in
                'Processing'. After that, the order is locked for fulfilment. If you
                need a change after that point, the simplest option is to cancel (if
                still possible) and reorder, or return unwanted items after delivery.""");

        policies.put(CareIntent.WRONG_ORDER, """
                [EDIT THIS] If you placed the wrong order: if it's still in
                'Processing' you can cancel it and reorder. If it has shipped, you can
                refuse delivery or return it once it arrives for a full refund. I can
                guide you through whichever applies.""");

        // 4. Returns, Refunds & Replacements
        policies.put(CareIntent.RETURN_ITEM, """
                [EDIT THIS] To return an item, go to 'My Orders' > select the order >
                'Return item', choose a reason, and print the prepaid return label.
                Returns are accepted within [EDIT: e.g. 30] days of delivery for
                items in original condition.""");

        policies.put(CareIntent.REFUND_STATUS, """
                [EDIT THIS] Refunds are processed within [EDIT: e.g. 5-7] business
                days after we receive and inspect the returned item. The refund goes
                back to your original payment method. You'll get an email when it's
                issued.""");

        // 5. Delivery Issues
        policies.put(CareIntent.RESCHEDULE_DELIVERY, """
                [EDIT THIS] You can reschedule an upcoming delivery from the tracking
                page: open the order > 'Reschedule delivery' > pick a new slot, as
                long as the order hasn't already been dispatched for that day.""");

        policies.put(CareIntent.EXPRESS_DELIVERY, """
                [EDIT THIS] Yes � same-day and express delivery are available in
                selected areas for orders placed before [EDIT: e.g. 2 PM]. Available
                options and cut-off times are shown at checkout based on your
                delivery postcode.""");

        // 6. Account & Support
        policies.put(CareIntent.SAVE_ADDRESSES, """
                [EDIT THIS] Yes, you can save multiple addresses. Go to 'Account' >
                'Address book' > 'Add address'. You can mark one as default and pick
                any saved address at checkout.""");
    }

    /** Returns the grounding policy text for an intent, or null if none. */
    public String policyFor(CareIntent intent) {
        return policies.get(intent).replaceAll("[EDIT THIS]", "");
    }

    public boolean hasPolicy(CareIntent intent) {
        return policies.containsKey(intent);
    }
}
