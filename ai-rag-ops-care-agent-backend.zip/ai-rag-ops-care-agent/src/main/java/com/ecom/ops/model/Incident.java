package com.ecom.ops.model;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * An incident raised by a CUSTOMER_CARE user for the OPERATIONS team when an
 * order is found in a failure state.
 */
@Entity
@Table(name = "incident")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Incident {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "incident_id", nullable = false, unique = true, updatable = false)
    @Builder.Default
    private UUID incidentId = UUID.randomUUID();

    @Column(name = "order_id", nullable = false, length = 64)
    private String orderId;

    @Column(name = "error_code", length = 100)
    private String errorCode;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "severity", nullable = false, length = 20)
    @Builder.Default
    private IncidentSeverity severity = IncidentSeverity.MEDIUM;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    @Builder.Default
    private IncidentStatus status = IncidentStatus.OPEN;

    /** Username of the customer-care agent who raised it. */
    @Column(name = "raised_by", nullable = false, length = 100)
    private String raisedBy;

    /** Team the incident is routed to (always OPERATIONS for now). */
    @Column(name = "assigned_team", nullable = false, length = 50)
    @Builder.Default
    private String assignedTeam = "OPERATIONS";

    /** Username of the ops user who picked it up (nullable). */
    @Column(name = "assigned_to", length = 100)
    private String assignedTo;

    @Column(name = "resolution_notes", columnDefinition = "TEXT")
    private String resolutionNotes;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private OffsetDateTime updatedAt;

    @PrePersist
    public void prePersist() {
        if (incidentId == null)   incidentId = UUID.randomUUID();
        if (status == null)       status = IncidentStatus.OPEN;
        if (severity == null)     severity = IncidentSeverity.MEDIUM;
        if (assignedTeam == null) assignedTeam = "OPERATIONS";
    }
}
