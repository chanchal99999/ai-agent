package com.ecom.ops.service;

import com.ecom.ops.model.FulfilmentJobQueue;
import com.ecom.ops.model.ManageFulfilmentJobQueue;
import com.ecom.ops.repository.FulfilmentJobQueueRepository;
import com.ecom.ops.repository.ManageFulfilmentJobQueueRepository;
import com.ecom.ops.repository.CustomerOrderRepository;
import com.ecom.ops.model.CustomerOrder;
import com.ecom.ops.model.OrderStatus;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderService {

	private final ManageFulfilmentJobQueueRepository manageFulfilmentRepo;
	private final FulfilmentJobQueueRepository fulfilmentJobRepo;
	private final CustomerOrderRepository customerOrderRepo;
	private final com.ecom.ops.repository.OrderItemRepository orderItemRepo;

	// ── Customer order (live status) lookups ──────────────────────────
	/**
	 * Live customer-facing status for an order from the customer_order table.
	 * Returns null if the order id is unknown. Used by BOTH agents.
	 */
	public Map<String, Object> getCustomerOrderStatus(String orderId) {
		if (orderId == null || orderId.isBlank()) return null;
		return customerOrderRepo.findByOrderIdIgnoreCase(orderId.trim())
				.map(this::toStatusMap)
				.orElse(null);
	}

	/**
	 * Returns the order's line items grouped by state for the care agent:
	 * keys: ordered, picked, delivered, rejected -> each a List of item maps.
	 * Returns null if the order itself does not exist.
	 */
	public Map<String, Object> getOrderItemsByState(String orderId) {
		if (orderId == null || orderId.isBlank()) return null;
		String id = orderId.trim();
		if (customerOrderRepo.findByOrderIdIgnoreCase(id).isEmpty()) return null;

		java.util.List<com.ecom.ops.model.OrderItem> all = orderItemRepo.findByOrderIdIgnoreCase(id);
		Map<String, Object> out = new LinkedHashMap<>();
		out.put("orderId", id);
		out.put("ordered",   itemsForState(all, com.ecom.ops.model.OrderItemState.ORDERED));
		out.put("picked",    itemsForState(all, com.ecom.ops.model.OrderItemState.PICKED));
		out.put("delivered", itemsForState(all, com.ecom.ops.model.OrderItemState.DELIVERED));
		out.put("rejected",  itemsForState(all, com.ecom.ops.model.OrderItemState.REJECTED));
		return out;
	}

	private java.util.List<Map<String, Object>> itemsForState(
			java.util.List<com.ecom.ops.model.OrderItem> all,
			com.ecom.ops.model.OrderItemState state) {
		java.util.List<Map<String, Object>> list = new java.util.ArrayList<>();
		for (com.ecom.ops.model.OrderItem it : all) {
			if (it.getState() != state) continue;
			Map<String, Object> m = new LinkedHashMap<>();
			m.put("itemDescription", it.getItemDescription());
			m.put("itemType", it.getItemType());
			m.put("quantity", it.getQuantity());
			m.put("substitute", it.getSubstitute());
			m.put("minimumAgeRestricted", it.getMinimumAgeRestricted());
			list.add(m);
		}
		return list;
	}

	private Map<String, Object> toStatusMap(CustomerOrder o) {
		OrderStatus st = o.getStatus();
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("orderId", o.getOrderId());
		m.put("status", st.name());
		m.put("statusLabel", st.getLabel());
		m.put("statusDescription", st.getDescription());
		m.put("phase", st.getPhase().getLabel());
		m.put("exceptional", st.isExceptional());
		m.put("terminal", st.isTerminal());
		m.put("customerName", o.getCustomerName());
		m.put("itemSummary", o.getItemSummary());
		m.put("itemCount", o.getItemCount());
		m.put("totalAmount", o.getTotalAmount());
		m.put("currency", o.getCurrency());
		m.put("carrier", o.getCarrier());
		m.put("trackingNumber", o.getTrackingNumber());
		m.put("shippingAddress", o.getShippingAddress());
		m.put("statusNote", o.getStatusNote());
		m.put("orderPlacedAt", o.getOrderPlacedAt());
		m.put("estimatedDelivery", o.getEstimatedDelivery());
		m.put("paymentStatus", o.getPaymentStatus());
		m.put("paymentAmount", o.getPaymentAmount());
		m.put("refundAmount", o.getRefundAmount());
		m.put("ageVerified", o.getAgeVerified());
		m.put("slotWindow", o.getSlotWindow());
		return m;
	}

	// ── Default window: last 1 hour ────────────────────────────────────
	private static final long DEFAULT_WINDOW_HOURS = 1;

	private OffsetDateTime defaultFrom() {
		return OffsetDateTime.now().minusHours(DEFAULT_WINDOW_HOURS);
	}

	private OffsetDateTime defaultTo() {
		return OffsetDateTime.now();
	}

	// ── Parse optional date strings, falling back to 1-hour window ────
	private OffsetDateTime parseFrom(String from) {
		if (from == null || from.isBlank())
			return defaultFrom();
		try {
			return OffsetDateTime.parse(from);
		} catch (Exception e) {
			return defaultFrom();
		}
	}

	private OffsetDateTime parseTo(String to) {
		if (to == null || to.isBlank())
			return defaultTo();
		try {
			return OffsetDateTime.parse(to);
		} catch (Exception e) {
			return defaultTo();
		}
	}

	// ── All events (for table rows) ────────────────────────────────────
	public List<ManageFulfilmentJobQueue> getAllManageEvents(String from, String to) {
		return manageFulfilmentRepo.findByDateRange(parseFrom(from), parseTo(to));
	}

	public List<FulfilmentJobQueue> getAllFulfilmentEvents(String from, String to) {
		return fulfilmentJobRepo.findByDateRange(parseFrom(from), parseTo(to));
	}

	// ── Order summary (no date filter — specific order lookup) ────────
	public Map<String, Object> getOrderSummary(String orderId) {
		Map<String, Object> summary = new LinkedHashMap<>();
		summary.put("orderId", orderId);

		List<ManageFulfilmentJobQueue> mRecords = manageFulfilmentRepo.findByOrderId(orderId);
		List<FulfilmentJobQueue> fRecords = fulfilmentJobRepo.findByOrderId(orderId);

		String fulfilmentStatus = mRecords.stream().map(ManageFulfilmentJobQueue::getOperationStatus).findFirst()
				.orElse("UNKNOWN");
		summary.put("fulfilmentStatus", fulfilmentStatus);

		String fulfilmentId = mRecords.stream().map(ManageFulfilmentJobQueue::getFulfilmentId).filter(Objects::nonNull)
				.findFirst().orElse(null);
		summary.put("fulfilmentId", fulfilmentId);

		String pickStatus = fRecords.stream().filter(f -> "pickReport".equals(f.getEventType()))
				.map(FulfilmentJobQueue::getOperationStatus).findFirst().orElse("NOT_FOUND");
		summary.put("pickStatus", pickStatus);

		String deliveryStatus = fRecords.stream().filter(f -> "deliveryReport".equals(f.getEventType()))
				.map(FulfilmentJobQueue::getOperationStatus).findFirst().orElse("NOT_FOUND");
		summary.put("deliveryStatus", deliveryStatus);

		List<String> errors = new ArrayList<>();
		mRecords.stream().filter(m -> m.getException() != null).forEach(m -> errors.add(m.getException()));
		fRecords.stream().filter(f -> f.getException() != null).forEach(f -> errors.add(f.getException()));
		summary.put("errors", errors);

		boolean hasPriority = mRecords.stream().anyMatch(m -> "API_EXCEPTION".equals(m.getOperationStatus()))
				|| fRecords.stream().anyMatch(f -> "API_EXCEPTION".equals(f.getOperationStatus())
						|| (f.getRetryAttempt() != null && f.getRetryAttempt() >= 3));
		summary.put("hasPriorityIssue", hasPriority);

		summary.put("manageEvents", mRecords);
		summary.put("fulfilmentEvents", fRecords);

		return summary;
	}

	public List<ManageFulfilmentJobQueue> getFailedManageJobs() {
		return manageFulfilmentRepo.findFailedJobs();
	}

	public List<FulfilmentJobQueue> getFailedFulfilmentJobs() {
		return fulfilmentJobRepo.findFailedJobs();
	}

	/**
	 * Returns priority issues (API_EXCEPTION / retry>=3) scoped to a date window.
	 * Defaults to the last 1 hour when no params are supplied — matches dashboard
	 * behaviour.
	 */
	public List<Map<String, Object>> getPriorityIssues(String from, String to) {
		OffsetDateTime fromDt = parseFrom(from);
		OffsetDateTime toDt = parseTo(to);

		List<Map<String, Object>> issues = new ArrayList<>();

		manageFulfilmentRepo.findFailedJobsByDateRange(fromDt, toDt).forEach(m -> {
			Map<String, Object> issue = new LinkedHashMap<>();
			issue.put("source", "ManageFulfilmentJobQueue");
			issue.put("eventId", m.getEventId());
			issue.put("orderId", m.getOrderId());
			issue.put("status", m.getOperationStatus());
			issue.put("exception", m.getException());
			issue.put("retryAttempt", m.getRetryAttempt());
			issue.put("eventDatetime", m.getEventDatetime());
			issue.put("priority", "HIGH");
			issues.add(issue);
		});

		fulfilmentJobRepo.findFailedJobsByDateRange(fromDt, toDt).forEach(f -> {
			Map<String, Object> issue = new LinkedHashMap<>();
			issue.put("source", "FulfilmentJobQueue");
			issue.put("eventId", f.getEventId());
			issue.put("orderId", f.getOrderId());
			issue.put("fulfilmentId", f.getFulfilmentId());
			issue.put("eventType", f.getEventType());
			issue.put("status", f.getOperationStatus());
			issue.put("exception", f.getException());
			issue.put("retryAttempt", f.getRetryAttempt());
			issue.put("eventDatetime", f.getEventDatetime());
			issue.put("priority", f.getRetryAttempt() != null && f.getRetryAttempt() >= 3 ? "CRITICAL" : "HIGH");
			issues.add(issue);
		});

		// Sort: CRITICAL first, then by eventDatetime descending
		issues.sort((a, b) -> {
			int pc = "CRITICAL".equals(b.get("priority")) ? 1 : "CRITICAL".equals(a.get("priority")) ? -1 : 0;
			if (pc != 0)
				return pc;
			OffsetDateTime da = (OffsetDateTime) a.get("eventDatetime");
			OffsetDateTime db = (OffsetDateTime) b.get("eventDatetime");
			if (da == null || db == null)
				return 0;
			return db.compareTo(da);
		});

		return issues;
	}

	// Keep the no-arg overload for any internal callers
	public List<Map<String, Object>> getPriorityIssues() {
		return getPriorityIssues(null, null);
	}

	// ── Dashboard stats — scoped to the requested date window ─────────
	public Map<String, Object> getDashboardStats(String from, String to) {
		OffsetDateTime fromDt = parseFrom(from);
		OffsetDateTime toDt = parseTo(to);

		Map<String, Object> stats = new LinkedHashMap<>();

		long totalOrders = manageFulfilmentRepo.countByDateRange(fromDt, toDt);
		long completedManage = manageFulfilmentRepo.countByStatusAndDateRange("COMPLETED", fromDt, toDt);
		long failedManage = manageFulfilmentRepo.findFailedJobsByDateRange(fromDt, toDt).size();
		long completedFulfilment = fulfilmentJobRepo.countByStatusAndDateRange("COMPLETED","deliveryReport", fromDt, toDt);
		long failedFulfilment = fulfilmentJobRepo.findFailedJobsByDateRange(fromDt, toDt).size();

		// Priority issues within window (cross-repo join in memory)
		List<ManageFulfilmentJobQueue> failedM = manageFulfilmentRepo.findFailedJobsByDateRange(fromDt, toDt);
		List<FulfilmentJobQueue> failedF = fulfilmentJobRepo.findFailedJobsByDateRange(fromDt, toDt);
		long priorityIssues = failedM.size() + failedF.size();

		stats.put("totalOrders", totalOrders);
		stats.put("completedManageJobs", completedManage);
		stats.put("failedManageJobs", failedManage);
		stats.put("completedFulfilmentJobs", completedFulfilment);
		stats.put("failedFulfilmentJobs", failedFulfilment);
		stats.put("priorityIssues", priorityIssues);

		// Echo back the window used so the frontend can display it
		stats.put("windowFrom", fromDt.toString());
		stats.put("windowTo", toDt.toString());
		stats.put("isDefaultWindow", (from == null || from.isBlank()) && (to == null || to.isBlank()));

		return stats;
	}
}
