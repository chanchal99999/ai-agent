package com.ecom.ops.rag;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.ai.document.Document;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Service;

import com.ecom.ops.model.RemediationDocument;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class RagService {

	private final VectorStore vectorStore;
//	private final RemediationDocumentRepository remediationRepo;
	
	@Value("${app.documents-path}")
    private String documentsPath;

	/**
	 * Index a remediation document into the vector store for semantic search.
	 */
//	@Transactional
	public void indexDocument(RemediationDocument doc) {
		try {
			String text = buildDocumentText(doc);
			Map<String, Object> metadata = new HashMap<>();
			metadata.put("documentId", doc.getDocumentId().toString());
			metadata.put("title", doc.getTitle());
			metadata.put("errorCode", doc.getErrorCode() != null ? doc.getErrorCode() : "");
			metadata.put("errorType", doc.getErrorType() != null ? doc.getErrorType() : "");
			metadata.put("source", "remediation_document");

			Document vectorDoc = new Document(text, metadata);
			vectorDoc = new Document(doc.getDocumentId().toString(), text, metadata);
			vectorStore.add(List.of(vectorDoc));
			log.info("Indexed document: {}", doc.getTitle());
		} catch (Exception e) {
			log.error("Failed to index document: {}", doc.getTitle(), e);
		}
	}

	/**
	 * Re-index all active remediation documents.
	 * @throws IOException 
	 */
//	@Transactional
	public void reindexAll() throws IOException {
//		List<RemediationDocument> docs = remediationRepo.findByIsActiveTrue();
//		log.info("Re-indexing {} remediation documents", docs.size());
//		for (RemediationDocument doc : docs) {
//			indexDocument(doc);
//		}
		
		var resolver = new PathMatchingResourcePatternResolver();
        // Supports pdf, docx, txt, html, etc. via Tika
        Resource[] resources = resolver.getResources(documentsPath + "*.*");

//        var splitter = new TokenTextSplitter();

        for (Resource resource : resources) {
            TikaDocumentReader reader = new TikaDocumentReader(resource);
            List<Document> docs = reader.get();
            // attach source filename as metadata
            docs.forEach(d -> d.getMetadata().put("source", resource.getFilename()));
//            List<Document> chunks = splitter.apply(docs);
            vectorStore.add(docs);
        }
	}

	/**
	 * Semantic search for relevant remediation content.
	 */
	public List<Document> search(String query, int topK) {
		try {
			SearchRequest request = SearchRequest.builder().query(query).topK(topK).similarityThreshold(0.5).build();
			return vectorStore.similaritySearch(request);
		} catch (Exception e) {
			log.error("Vector search failed for query: {}", query, e);
			return Collections.emptyList();
		}
	}

	/**
	 * Build a rich text representation of a remediation document for embedding.
	 */
	private String buildDocumentText(RemediationDocument doc) {
		StringBuilder sb = new StringBuilder();
		sb.append("Title: ").append(doc.getTitle()).append("\n");
		if (doc.getErrorCode() != null)
			sb.append("Error Code: ").append(doc.getErrorCode()).append("\n");
		if (doc.getErrorType() != null)
			sb.append("Error Type: ").append(doc.getErrorType()).append("\n");
		if (doc.getTags() != null)
			sb.append("Tags: ").append(String.join(", ", doc.getTags())).append("\n\n");
		sb.append(doc.getContent());
		return sb.toString();
	}
}
