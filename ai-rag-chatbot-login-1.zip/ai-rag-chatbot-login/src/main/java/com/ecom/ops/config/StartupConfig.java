package com.ecom.ops.config;

import com.ecom.ops.rag.RagService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class StartupConfig {

	private final RagService ragService;

	@Bean
	public ApplicationRunner indexRemediationDocs() {
		return args -> {
			log.info("Indexing remediation documents into vector store on startup...");
			try {
				ragService.reindexAll();
				log.info("Remediation document indexing complete.");
			} catch (Exception e) {
				log.warn("Could not index remediation documents on startup (vector store may not be ready): {}",
						e.getMessage());
			}
		};
	}
}
