package com.ecom.ops.service;

import com.ecom.ops.model.FulfilmentJobQueue;
import com.ecom.ops.model.ManageFulfilmentJobQueue;
import com.ecom.ops.repository.FulfilmentJobQueueRepository;
import com.ecom.ops.repository.ManageFulfilmentJobQueueRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderService {

	private final ManageFulfilmentJobQueueRepository manageFulfilmentRepo;
	private final FulfilmentJobQueueRepository fulfilmentJobRepo;

	// ── Default window: last 1 hour ────────────────────────────────────
	private static final long DEFAULT_WINDOW_HOURS = 1;

	private OffsetDateTime defaultFrom() {
		return OffsetDateTime.now().minusHours(DEFAULT_WINDOW_HOURS);
	}

	private OffsetDateTime defaultTo() {
		return OffsetDateTime.now();
	}

	// ── Parse optional date strings, falling back to 1-hour window ────
	private OffsetDateTime parseFrom(String from) {
		if (from == null || from.isBlank())
			return defaultFrom();
		try {
			return OffsetDateTime.parse(from);
		} catch (Exception e) {
			return defaultFrom();
		}
	}

	private OffsetDateTime parseTo(String to) {
		if (to == null || to.isBlank())
			return defaultTo();
		try {
			return OffsetDateTime.parse(to);
		} catch (Exception e) {
			return defaultTo();
		}
	}

	// ── All events (for table rows) ────────────────────────────────────
	public List<ManageFulfilmentJobQueue> getAllManageEvents(String from, String to) {
		return manageFulfilmentRepo.findByDateRange(parseFrom(from), parseTo(to));
	}

	public List<FulfilmentJobQueue> getAllFulfilmentEvents(String from, String to) {
		return fulfilmentJobRepo.findByDateRange(parseFrom(from), parseTo(to));
	}

	// ── Order summary (no date filter — specific order lookup) ────────
	public Map<String, Object> getOrderSummary(String orderId) {
		Map<String, Object> summary = new LinkedHashMap<>();
		summary.put("orderId", orderId);

		List<ManageFulfilmentJobQueue> mRecords = manageFulfilmentRepo.findByOrderId(orderId);
		List<FulfilmentJobQueue> fRecords = fulfilmentJobRepo.findByOrderId(orderId);

		String fulfilmentStatus = mRecords.stream().map(ManageFulfilmentJobQueue::getOperationStatus).findFirst()
				.orElse("UNKNOWN");
		summary.put("fulfilmentStatus", fulfilmentStatus);

		String fulfilmentId = mRecords.stream().map(ManageFulfilmentJobQueue::getFulfilmentId).filter(Objects::nonNull)
				.findFirst().orElse(null);
		summary.put("fulfilmentId", fulfilmentId);

		String pickStatus = fRecords.stream().filter(f -> "pickReport".equals(f.getEventType()))
				.map(FulfilmentJobQueue::getOperationStatus).findFirst().orElse("NOT_FOUND");
		summary.put("pickStatus", pickStatus);

		String deliveryStatus = fRecords.stream().filter(f -> "deliveryReport".equals(f.getEventType()))
				.map(FulfilmentJobQueue::getOperationStatus).findFirst().orElse("NOT_FOUND");
		summary.put("deliveryStatus", deliveryStatus);

		List<String> errors = new ArrayList<>();
		mRecords.stream().filter(m -> m.getException() != null).forEach(m -> errors.add(m.getException()));
		fRecords.stream().filter(f -> f.getException() != null).forEach(f -> errors.add(f.getException()));
		summary.put("errors", errors);

		boolean hasPriority = mRecords.stream().anyMatch(m -> "API_EXCEPTION".equals(m.getOperationStatus()))
				|| fRecords.stream().anyMatch(f -> "API_EXCEPTION".equals(f.getOperationStatus())
						|| (f.getRetryAttempt() != null && f.getRetryAttempt() >= 3));
		summary.put("hasPriorityIssue", hasPriority);

		summary.put("manageEvents", mRecords);
		summary.put("fulfilmentEvents", fRecords);

		return summary;
	}

	public List<ManageFulfilmentJobQueue> getFailedManageJobs() {
		return manageFulfilmentRepo.findFailedJobs();
	}

	public List<FulfilmentJobQueue> getFailedFulfilmentJobs() {
		return fulfilmentJobRepo.findFailedJobs();
	}

	/**
	 * Returns priority issues (API_EXCEPTION / retry>=3) scoped to a date window.
	 * Defaults to the last 1 hour when no params are supplied — matches dashboard
	 * behaviour.
	 */
	public List<Map<String, Object>> getPriorityIssues(String from, String to) {
		OffsetDateTime fromDt = parseFrom(from);
		OffsetDateTime toDt = parseTo(to);

		List<Map<String, Object>> issues = new ArrayList<>();

		manageFulfilmentRepo.findFailedJobsByDateRange(fromDt, toDt).forEach(m -> {
			Map<String, Object> issue = new LinkedHashMap<>();
			issue.put("source", "ManageFulfilmentJobQueue");
			issue.put("eventId", m.getEventId());
			issue.put("orderId", m.getOrderId());
			issue.put("status", m.getOperationStatus());
			issue.put("exception", m.getException());
			issue.put("retryAttempt", m.getRetryAttempt());
			issue.put("eventDatetime", m.getEventDatetime());
			issue.put("priority", "HIGH");
			issues.add(issue);
		});

		fulfilmentJobRepo.findFailedJobsByDateRange(fromDt, toDt).forEach(f -> {
			Map<String, Object> issue = new LinkedHashMap<>();
			issue.put("source", "FulfilmentJobQueue");
			issue.put("eventId", f.getEventId());
			issue.put("orderId", f.getOrderId());
			issue.put("fulfilmentId", f.getFulfilmentId());
			issue.put("eventType", f.getEventType());
			issue.put("status", f.getOperationStatus());
			issue.put("exception", f.getException());
			issue.put("retryAttempt", f.getRetryAttempt());
			issue.put("eventDatetime", f.getEventDatetime());
			issue.put("priority", f.getRetryAttempt() != null && f.getRetryAttempt() >= 3 ? "CRITICAL" : "HIGH");
			issues.add(issue);
		});

		// Sort: CRITICAL first, then by eventDatetime descending
		issues.sort((a, b) -> {
			int pc = "CRITICAL".equals(b.get("priority")) ? 1 : "CRITICAL".equals(a.get("priority")) ? -1 : 0;
			if (pc != 0)
				return pc;
			OffsetDateTime da = (OffsetDateTime) a.get("eventDatetime");
			OffsetDateTime db = (OffsetDateTime) b.get("eventDatetime");
			if (da == null || db == null)
				return 0;
			return db.compareTo(da);
		});

		return issues;
	}

	// Keep the no-arg overload for any internal callers
	public List<Map<String, Object>> getPriorityIssues() {
		return getPriorityIssues(null, null);
	}

	// ── Dashboard stats — scoped to the requested date window ─────────
	public Map<String, Object> getDashboardStats(String from, String to) {
		OffsetDateTime fromDt = parseFrom(from);
		OffsetDateTime toDt = parseTo(to);

		Map<String, Object> stats = new LinkedHashMap<>();

		long totalOrders = manageFulfilmentRepo.countByDateRange(fromDt, toDt);
		long completedManage = manageFulfilmentRepo.countByStatusAndDateRange("COMPLETED", fromDt, toDt);
		long failedManage = manageFulfilmentRepo.findFailedJobsByDateRange(fromDt, toDt).size();
		long completedFulfilment = fulfilmentJobRepo.countByStatusAndDateRange("COMPLETED","deliveryReport", fromDt, toDt);
		long failedFulfilment = fulfilmentJobRepo.findFailedJobsByDateRange(fromDt, toDt).size();

		// Priority issues within window (cross-repo join in memory)
		List<ManageFulfilmentJobQueue> failedM = manageFulfilmentRepo.findFailedJobsByDateRange(fromDt, toDt);
		List<FulfilmentJobQueue> failedF = fulfilmentJobRepo.findFailedJobsByDateRange(fromDt, toDt);
		long priorityIssues = failedM.size() + failedF.size();

		stats.put("totalOrders", totalOrders);
		stats.put("completedManageJobs", completedManage);
		stats.put("failedManageJobs", failedManage);
		stats.put("completedFulfilmentJobs", completedFulfilment);
		stats.put("failedFulfilmentJobs", failedFulfilment);
		stats.put("priorityIssues", priorityIssues);

		// Echo back the window used so the frontend can display it
		stats.put("windowFrom", fromDt.toString());
		stats.put("windowTo", toDt.toString());
		stats.put("isDefaultWindow", (from == null || from.isBlank()) && (to == null || to.isBlank()));

		return stats;
	}
}
