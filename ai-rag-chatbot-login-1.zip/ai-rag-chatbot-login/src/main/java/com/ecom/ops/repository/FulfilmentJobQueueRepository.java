package com.ecom.ops.repository;

import com.ecom.ops.model.FulfilmentJobQueue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface FulfilmentJobQueueRepository extends JpaRepository<FulfilmentJobQueue, Long> {

    List<FulfilmentJobQueue> findByOrderId(String orderId);

    List<FulfilmentJobQueue> findByFulfilmentId(String fulfilmentId);

    List<FulfilmentJobQueue> findByOperationStatus(String status);

    Optional<FulfilmentJobQueue> findByEventId(String eventId);

    @Query("SELECT f FROM FulfilmentJobQueue f WHERE f.exception IS NOT NULL ORDER BY f.eventDatetime DESC")
    List<FulfilmentJobQueue> findAllWithErrors();

    @Query("SELECT f FROM FulfilmentJobQueue f WHERE f.operationStatus = 'API_EXCEPTION' ORDER BY f.retryAttempt DESC, f.eventDatetime DESC")
    List<FulfilmentJobQueue> findFailedJobs();

    @Query("SELECT f FROM FulfilmentJobQueue f WHERE f.orderId = :orderId AND f.eventType = :eventType ORDER BY f.eventDatetime DESC")
    List<FulfilmentJobQueue> findByOrderIdAndEventType(
            @Param("orderId") String orderId,
            @Param("eventType") String eventType);

    @Query("SELECT f FROM FulfilmentJobQueue f WHERE f.exception LIKE %:errorCode% ORDER BY f.eventDatetime DESC")
    List<FulfilmentJobQueue> findByErrorCode(@Param("errorCode") String errorCode);

    // ── Time-windowed queries ──────────────────────────────────────────

    @Query("SELECT f FROM FulfilmentJobQueue f WHERE f.eventDatetime >= :from AND f.eventDatetime <= :to ORDER BY f.eventDatetime DESC")
    List<FulfilmentJobQueue> findByDateRange(
            @Param("from") OffsetDateTime from,
            @Param("to") OffsetDateTime to);

    @Query("SELECT COUNT(f) FROM FulfilmentJobQueue f WHERE f.operationStatus = :status AND f.eventType=:deliveryReport AND f.eventDatetime >= :from AND f.eventDatetime <= :to")
    long countByStatusAndDateRange(
            @Param("status") String status,
            @Param("deliveryReport") String deliveryReport,
            @Param("from") OffsetDateTime from,
            @Param("to") OffsetDateTime to);

    @Query("SELECT f FROM FulfilmentJobQueue f WHERE f.operationStatus = 'API_EXCEPTION' AND f.eventDatetime >= :from AND f.eventDatetime <= :to ORDER BY f.retryAttempt DESC, f.eventDatetime DESC")
    List<FulfilmentJobQueue> findFailedJobsByDateRange(
            @Param("from") OffsetDateTime from,
            @Param("to") OffsetDateTime to);

    @Query("SELECT COUNT(m) FROM FulfilmentJobQueue m WHERE m.eventDatetime >= :from AND m.eventDatetime <= :to")
    long countByDateRange(
            @Param("from") OffsetDateTime from,
            @Param("to") OffsetDateTime to);
//	long countByDateRange(OffsetDateTime from, OffsetDateTime to);
}
