package com.ecom.ops.dto;

import lombok.*;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

public class ChatRequestDto {
    @Getter @Setter
    public static class Request {
        private String message;
        private UUID sessionId;
    }

    @Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
    public static class Response {
        private UUID sessionId;
        private UUID messageId;
        private String content;
        private String sqlQuery;
        private List<String> sources;
        private OffsetDateTime timestamp;
    }

    @Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
    public static class SessionInfo {
        private UUID sessionId;
        private String title;
        private OffsetDateTime createdAt;
        private OffsetDateTime updatedAt;
    }

    @Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
    public static class MessageInfo {
        private UUID messageId;
        private String role;
        private String content;
        private String sqlQuery;
        private List<String> sources;
        private OffsetDateTime createdAt;
    }
}
