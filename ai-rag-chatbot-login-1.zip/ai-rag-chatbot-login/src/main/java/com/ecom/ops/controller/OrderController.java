package com.ecom.ops.controller;

import com.ecom.ops.model.FulfilmentJobQueue;
import com.ecom.ops.model.ManageFulfilmentJobQueue;
import com.ecom.ops.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class OrderController {

	private final OrderService orderService;

	/**
	 * Dashboard stat counts — scoped to a date window. Defaults to the last 1 hour
	 * when no params are supplied.
	 *
	 * GET /api/orders/dashboard?from=2024-01-01T00:00:00Z&to=2024-01-01T01:00:00Z
	 */
	@GetMapping("/dashboard")
	public ResponseEntity<Map<String, Object>> getDashboard(@RequestParam(required = false) String from,
			@RequestParam(required = false) String to) {
		return ResponseEntity.ok(orderService.getDashboardStats(from, to));
	}

	@GetMapping("/{orderId}")
	public ResponseEntity<Map<String, Object>> getOrderSummary(@PathVariable String orderId) {
		return ResponseEntity.ok(orderService.getOrderSummary(orderId));
	}

	/**
	 * Table rows — scoped to the same date window as the dashboard. GET
	 * /api/orders/manage/all?from=...&to=...
	 */
	@GetMapping("/manage/all")
	public ResponseEntity<List<ManageFulfilmentJobQueue>> getAllManageEvents(
			@RequestParam(required = false) String from, @RequestParam(required = false) String to) {
		return ResponseEntity.ok(orderService.getAllManageEvents(from, to));
	}

	@GetMapping("/fulfilment/all")
	public ResponseEntity<List<FulfilmentJobQueue>> getAllFulfilmentEvents(@RequestParam(required = false) String from,
			@RequestParam(required = false) String to) {
		return ResponseEntity.ok(orderService.getAllFulfilmentEvents(from, to));
	}

	@GetMapping("/failed/manage")
	public ResponseEntity<List<ManageFulfilmentJobQueue>> getFailedManageJobs() {
		return ResponseEntity.ok(orderService.getFailedManageJobs());
	}

	@GetMapping("/failed/fulfilment")
	public ResponseEntity<List<FulfilmentJobQueue>> getFailedFulfilmentJobs() {
		return ResponseEntity.ok(orderService.getFailedFulfilmentJobs());
	}

	/**
	 * Priority issues scoped to a date window. Defaults to the last 1 hour when no
	 * params are supplied.
	 *
	 * GET /api/orders/priority?from=2025-03-24T10:00:00Z&to=2025-03-24T11:00:00Z
	 */
	@GetMapping("/priority")
	public ResponseEntity<List<Map<String, Object>>> getPriorityIssues(@RequestParam(required = false) String from,
			@RequestParam(required = false) String to) {
		return ResponseEntity.ok(orderService.getPriorityIssues(from, to));
	}
}
