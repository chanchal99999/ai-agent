package com.ecom.ops.repository;

import com.ecom.ops.model.RemediationDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface RemediationDocumentRepository extends JpaRepository<RemediationDocument, Long> {

//    Optional<RemediationDocument> findByDocumentId(UUID documentId);
//
//    List<RemediationDocument> findByIsActiveTrue();
//
//    List<RemediationDocument> findByErrorCode(String errorCode);
//
//    @Query("SELECT r FROM RemediationDocument r WHERE r.isActive = true AND (r.errorCode LIKE %:keyword% OR r.title LIKE %:keyword% OR r.content LIKE %:keyword%)")
//    List<RemediationDocument> searchByKeyword(@Param("keyword") String keyword);
//
//    @Query("SELECT r FROM RemediationDocument r WHERE :tag = ANY(r.tags) AND r.isActive = true")
//    List<RemediationDocument> findByTag(@Param("tag") String tag);

	Optional<RemediationDocument> findByDocumentId(UUID documentId);

	List<RemediationDocument> findByIsActiveTrue();

	List<RemediationDocument> findByErrorCode(String errorCode);

	@Query("SELECT r FROM RemediationDocument r WHERE r.isActive = true AND (r.errorCode LIKE %:keyword% OR r.title LIKE %:keyword% OR r.content LIKE %:keyword%)")
	List<RemediationDocument> searchByKeyword(@Param("keyword") String keyword);

	@Query(value = "SELECT * FROM remediation_document WHERE :tag = ANY(tags) AND is_active = true", nativeQuery = true)
	List<RemediationDocument> findByTag(@Param("tag") String tag);
}
