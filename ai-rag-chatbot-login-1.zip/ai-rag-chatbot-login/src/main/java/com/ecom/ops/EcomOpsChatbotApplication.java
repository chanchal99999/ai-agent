package com.ecom.ops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class EcomOpsChatbotApplication {
	public static void main(String[] args) {
		SpringApplication.run(EcomOpsChatbotApplication.class, args);
	}
}
