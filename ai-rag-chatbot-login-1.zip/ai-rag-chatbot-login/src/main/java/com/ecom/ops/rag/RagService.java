package com.ecom.ops.rag;

import com.ecom.ops.model.RemediationDocument;
import com.ecom.ops.repository.RemediationDocumentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class RagService {

	private final VectorStore vectorStore;
	private final RemediationDocumentRepository remediationRepo;

	/**
	 * Index a remediation document into the vector store for semantic search.
	 */
	@Transactional
	public void indexDocument(RemediationDocument doc) {
		try {
			String text = buildDocumentText(doc);
			Map<String, Object> metadata = new HashMap<>();
			metadata.put("documentId", doc.getDocumentId().toString());
			metadata.put("title", doc.getTitle());
			metadata.put("errorCode", doc.getErrorCode() != null ? doc.getErrorCode() : "");
			metadata.put("errorType", doc.getErrorType() != null ? doc.getErrorType() : "");
			metadata.put("source", "remediation_document");

			Document vectorDoc = new Document(text, metadata);
			vectorDoc = new Document(doc.getDocumentId().toString(), text, metadata);
			vectorStore.add(List.of(vectorDoc));
			log.info("Indexed document: {}", doc.getTitle());
		} catch (Exception e) {
			log.error("Failed to index document: {}", doc.getTitle(), e);
		}
	}

	/**
	 * Re-index all active remediation documents.
	 */
	@Transactional
	public void reindexAll() {
		List<RemediationDocument> docs = remediationRepo.findByIsActiveTrue();
		log.info("Re-indexing {} remediation documents", docs.size());
		for (RemediationDocument doc : docs) {
			indexDocument(doc);
		}
	}

	/**
	 * Semantic search for relevant remediation content.
	 */
	public List<Document> search(String query, int topK) {
		try {
			SearchRequest request = SearchRequest.builder().query(query).topK(topK).similarityThreshold(0.5).build();
			return vectorStore.similaritySearch(request);
		} catch (Exception e) {
			log.error("Vector search failed for query: {}", query, e);
			return Collections.emptyList();
		}
	}

	/**
	 * Build a rich text representation of a remediation document for embedding.
	 */
	private String buildDocumentText(RemediationDocument doc) {
		StringBuilder sb = new StringBuilder();
		sb.append("Title: ").append(doc.getTitle()).append("\n");
		if (doc.getErrorCode() != null)
			sb.append("Error Code: ").append(doc.getErrorCode()).append("\n");
		if (doc.getErrorType() != null)
			sb.append("Error Type: ").append(doc.getErrorType()).append("\n");
		if (doc.getTags() != null)
			sb.append("Tags: ").append(String.join(", ", doc.getTags())).append("\n\n");
		sb.append(doc.getContent());
		return sb.toString();
	}
}
