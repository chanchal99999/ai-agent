package com.ecom.ops.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ecom.ops.model.ChatMessage;

@Repository
public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
	List<ChatMessage> findBySessionIdOrderByCreatedAtAsc(UUID sessionId);

	@Modifying
	@Query(value = "DELETE FROM chat_message WHERE session_id = ?", nativeQuery = true)
	void deleteBySessionId(UUID sessionId);
}
