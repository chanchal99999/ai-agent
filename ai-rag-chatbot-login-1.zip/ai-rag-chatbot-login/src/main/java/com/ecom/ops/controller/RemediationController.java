package com.ecom.ops.controller;

import com.ecom.ops.model.RemediationDocument;
import com.ecom.ops.rag.RagService;
import com.ecom.ops.service.RemediationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/remediation")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class RemediationController {

    private final RemediationService remediationService;
    private final RagService ragService;

    @GetMapping
    public ResponseEntity<List<RemediationDocument>> getAll() {
        return ResponseEntity.ok(remediationService.getAll());
    }

    @GetMapping("/{documentId}")
    public ResponseEntity<RemediationDocument> getById(@PathVariable UUID documentId) {
        return ResponseEntity.ok(remediationService.getById(documentId));
    }

    @PostMapping
    public ResponseEntity<RemediationDocument> create(@RequestBody Map<String, Object> body) {
        String title = (String) body.get("title");
        String errorCode = (String) body.get("errorCode");
        String errorType = (String) body.get("errorType");
        String content = (String) body.get("content");
        String uploadedBy = (String) body.get("uploadedBy");
        String[] tags = body.get("tags") != null
                ? ((List<String>) body.get("tags")).toArray(new String[0])
                : new String[0];

        RemediationDocument doc = remediationService.create(title, errorCode, errorType, content, uploadedBy, tags);
        return ResponseEntity.ok(doc);
    }

    @PutMapping("/{documentId}")
    public ResponseEntity<RemediationDocument> update(@PathVariable UUID documentId,
                                                       @RequestBody Map<String, Object> body) {
        String title = (String) body.get("title");
        String errorCode = (String) body.get("errorCode");
        String errorType = (String) body.get("errorType");
        String content = (String) body.get("content");
        String[] tags = body.get("tags") != null
                ? ((List<String>) body.get("tags")).toArray(new String[0])
                : null;
        return ResponseEntity.ok(remediationService.update(documentId, title, errorCode, errorType, content, tags));
    }

    @PostMapping("/upload")
    public ResponseEntity<RemediationDocument> uploadFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "title", required = false) String title,
            @RequestParam(value = "errorCode", required = false) String errorCode,
            @RequestParam(value = "errorType", required = false) String errorType,
            @RequestParam(value = "uploadedBy", defaultValue = "support-team") String uploadedBy,
            @RequestParam(value = "tags", required = false) String[] tags) throws IOException {
        return ResponseEntity.ok(
                remediationService.uploadFile(title, errorCode, errorType, uploadedBy, tags, file));
    }

    @GetMapping("/{documentId}/download")
    public ResponseEntity<byte[]> downloadFile(@PathVariable UUID documentId) throws IOException {
        RemediationDocument doc = remediationService.getById(documentId);
        byte[] content = remediationService.downloadFile(documentId);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + doc.getFileName() + "\"")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(content);
    }

    @DeleteMapping("/{documentId}")
    public ResponseEntity<Void> delete(@PathVariable UUID documentId) {
        remediationService.delete(documentId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/reindex")
    public ResponseEntity<Map<String, String>> reindex() {
        ragService.reindexAll();
        return ResponseEntity.ok(Map.of("status", "Reindexing complete"));
    }
}
