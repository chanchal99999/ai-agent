package com.ecom.ops.service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

import org.apache.tika.Tika;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.sax.BodyContentHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.ecom.ops.model.RemediationDocument;
import com.ecom.ops.rag.RagService;
import com.ecom.ops.repository.RemediationDocumentRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Handles all remediation document operations.
 *
 * Text extraction uses Apache Tika's AutoDetectParser which supports
 * 1000+ file types including:
 *   - Plain text  : .txt, .md, .log, .csv, .yaml, .json, .xml, .sql
 *   - PDF         : .pdf  (via PDFBox under the hood)
 *   - Word        : .docx, .doc  (via Apache POI)
 *   - Excel       : .xlsx, .xls  (via Apache POI)
 *   - PowerPoint  : .pptx, .ppt  (via Apache POI)
 *   - HTML/XML    : .html, .htm, .xml
 *   - Email       : .eml, .msg
 *   - Code files  : .java, .py, .js, .ts, .sh, etc.
 *   - Archives    : .zip, .tar, .gz  (metadata only)
 *   - Images      : .png, .jpg, .gif  (EXIF metadata)
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class RemediationService {

    private final RemediationDocumentRepository remediationRepo;
    private final RagService ragService;

    // Single shared Tika instance — thread-safe and lightweight
    private final Tika tika = new Tika();

    @Value("${app.upload.dir:./uploads}")
    private String uploadDir;

    // ── CRUD ───────────────────────────────────────────────────────────

    public List<RemediationDocument> getAll() {
        return remediationRepo.findByIsActiveTrue();
    }

    public RemediationDocument getById(UUID documentId) {
        return remediationRepo.findByDocumentId(documentId)
                .orElseThrow(() -> new RuntimeException("Document not found: " + documentId));
    }

    @Transactional
    public RemediationDocument create(String title, String errorCode, String errorType,
                                       String content, String uploadedBy, String[] tags) {
        RemediationDocument doc = RemediationDocument.builder()
                .title(title)
                .errorCode(errorCode)
                .errorType(errorType)
                .content(content)
                .uploadedBy(uploadedBy != null ? uploadedBy : "support-team")
                .tags(tags)
                .isActive(true)
                .build();
        doc = remediationRepo.save(doc);
        ragService.indexDocument(doc);
        return doc;
    }

    @Transactional
    public RemediationDocument update(UUID documentId, String title, String errorCode,
                                       String errorType, String content, String[] tags) {
        RemediationDocument doc = getById(documentId);
        if (title     != null) doc.setTitle(title);
        if (errorCode != null) doc.setErrorCode(errorCode);
        if (errorType != null) doc.setErrorType(errorType);
        if (content   != null) doc.setContent(content);
        if (tags      != null) doc.setTags(tags);
        doc = remediationRepo.save(doc);
        ragService.indexDocument(doc);
        return doc;
    }

    // ── File upload ────────────────────────────────────────────────────

    @Transactional
    public RemediationDocument uploadFile(String title, String errorCode, String errorType,
                                           String uploadedBy, String[] tags,
                                           MultipartFile file) throws IOException {
        // 1. Save raw bytes to disk — accepts ALL file types
        Path uploadPath = Paths.get(uploadDir);
        Files.createDirectories(uploadPath);
        String storedName = UUID.randomUUID() + "_" + file.getOriginalFilename();
        Path filePath = uploadPath.resolve(storedName);
        Files.copy(file.getInputStream(), filePath);

        // 2. Detect MIME type with Tika (more reliable than browser-reported type)
        String detectedMime;
        try (InputStream is = Files.newInputStream(filePath)) {
            detectedMime = tika.detect(is, file.getOriginalFilename());
        } catch (Exception e) {
            detectedMime = file.getContentType() != null ? file.getContentType() : "application/octet-stream";
        }

        // 3. Extract text content using Tika AutoDetectParser
        String content = extractWithTika(filePath, file.getOriginalFilename());

        // 4. Persist and index for RAG
        RemediationDocument doc = RemediationDocument.builder()
                .title(title != null && !title.isBlank() ? title : stripExtension(file.getOriginalFilename()))
                .errorCode(errorCode)
                .errorType(errorType)
                .content(content)
                .fileName(file.getOriginalFilename())
                .filePath(filePath.toString())
                .mimeType(detectedMime)
                .uploadedBy(uploadedBy != null ? uploadedBy : "support-team")
                .tags(tags)
                .isActive(true)
                .build();
        doc = remediationRepo.save(doc);
        ragService.indexDocument(doc);
        return doc;
    }

    @Transactional
    public void delete(UUID documentId) {
        RemediationDocument doc = getById(documentId);
        doc.setIsActive(false);
        remediationRepo.save(doc);
        ragService.reindexAll();
        
    }

    public byte[] downloadFile(UUID documentId) throws IOException {
        RemediationDocument doc = getById(documentId);
        if (doc.getFilePath() == null)
            throw new RuntimeException("No file attached to this document.");
        return Files.readAllBytes(Paths.get(doc.getFilePath()));
    }

    // ── Text extraction ────────────────────────────────────────────────

    /**
     * Extracts readable text from ANY file type using Apache Tika.
     * For truly binary files (images, executables) it returns a
     * descriptive placeholder so the record is always saved cleanly.
     */
    private String extractWithTika(Path filePath, String originalFileName) {
        try {
            // BodyContentHandler with -1 = no character limit
            BodyContentHandler handler  = new BodyContentHandler(-1);
            Metadata           metadata = new Metadata();
            ParseContext       context  = new ParseContext();
            AutoDetectParser   parser   = new AutoDetectParser();

            metadata.set(TikaCoreProperties.RESOURCE_NAME_KEY, originalFileName);

            try (InputStream stream = Files.newInputStream(filePath)) {
                parser.parse(stream, handler, metadata, context);
            }

            String extracted = handler.toString().trim();
            if (extracted.isEmpty()) {
                // File was parseable but produced no text (e.g. blank doc, pure-image PDF)
                String mime = metadata.get(Metadata.CONTENT_TYPE);
                return String.format("[File: %s (%s) — no extractable text content found]",
                        originalFileName, mime != null ? mime : "unknown type");
            }
            return extracted;

        } catch (Exception e) {
            log.warn("Tika could not extract text from '{}': {}", originalFileName, e.getMessage());
            // Graceful fallback — always store something meaningful
            return String.format("[File uploaded: %s — content stored on disk. Text extraction failed: %s]",
                    originalFileName, e.getMessage());
        }
    }

    private String stripExtension(String fileName) {
        if (fileName == null) return "Untitled";
        int dot = fileName.lastIndexOf('.');
        return dot > 0 ? fileName.substring(0, dot) : fileName;
    }
}
