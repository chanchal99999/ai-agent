package com.ecom.ops.controller;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.ops.dto.ChatRequestDto;
import com.ecom.ops.service.ChatbotService;

import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ChatController {

	private final ChatbotService chatbotService;

	@PostMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<String> streamChat(@RequestBody Map<String, String> body) {
		System.out.println("stream called");
		String message = body.get("message");
		String sessionIdStr = body.get("sessionId");
		UUID sessionId = sessionIdStr != null ? UUID.fromString(sessionIdStr) : null;

		return chatbotService.streamChat(message, sessionId);
	}

	@PostMapping
	public ResponseEntity<ChatRequestDto.Response> chat(@RequestBody Map<String, String> body) {
		String message = body.get("message");
		String sessionIdStr = body.get("sessionId");
		UUID sessionId = sessionIdStr != null ? UUID.fromString(sessionIdStr) : null;

		ChatRequestDto.Response response = chatbotService.chat(message, sessionId);
		return ResponseEntity.ok(response);
	}

	@PostMapping("/sessions")
	public ResponseEntity<ChatRequestDto.SessionInfo> createSession() {
		return ResponseEntity.ok(chatbotService.createSession());
	}

	@GetMapping("/sessions")
	public ResponseEntity<List<ChatRequestDto.SessionInfo>> getSessions() {
		return ResponseEntity.ok(chatbotService.getAllSessions());
	}

	@GetMapping("/sessions/{sessionId}/messages")
	public ResponseEntity<List<ChatRequestDto.MessageInfo>> getMessages(@PathVariable UUID sessionId) {
		return ResponseEntity.ok(chatbotService.getSessionHistory(sessionId));
	}

	@DeleteMapping("/sessions/{sessionId}")
	public ResponseEntity<Void> deleteSession(@PathVariable UUID sessionId) {
		chatbotService.deleteSession(sessionId);
		return ResponseEntity.noContent().build();
	}
}
