package com.ecom.ops.service;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.document.Document;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecom.ops.dto.ChatRequestDto;
import com.ecom.ops.model.ChatMessage;
import com.ecom.ops.model.ChatSession;
import com.ecom.ops.rag.RagService;
import com.ecom.ops.repository.ChatMessageRepository;
import com.ecom.ops.repository.ChatSessionRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;

@Service
@RequiredArgsConstructor
@Slf4j
public class ChatbotService {

	private final ChatClient chatClient;
	private final RagService ragService;
	private final DataContextService dataContextService;
	private final ChatSessionRepository sessionRepo;
	private final ChatMessageRepository messageRepo;

	// ── System prompt ──────────────────────────────────────────────────
	private static final String SYSTEM_PROMPT = """
			You are an E-Commerce Operations Support Assistant. Your ONLY role is to help the
			operations support team manage and troubleshoot e-commerce fulfilment orders.

			STRICT SCOPE: Only answer questions about:
			- Order status (confirmed, picked, delivered)
			- Fulfilment job queue events
			- Errors, API exceptions, failed jobs
			- Pick reports and delivery reports with their item payloads
			- Remediation steps for error codes
			- Priority issues with orders
			- SQL queries for operational data

			If a question is NOT related to e-commerce operations, respond ONLY with:
			"I can only assist with operations support topics."

			─────────────────────────────────────────────────────────────────
			RESPONSE FORMAT A — SIMPLE ORDER STATUS
			─────────────────────────────────────────────────────────────────
			Triggered when: user asks "what is the status of ORD-XXXXX" or
			"order status for ORD-XXXXX" (no pick/delivery payload request).
			Use ONLY data from the LIVE DATABASE CONTEXT — the ORDER STATUS
			REPORT section for this order.

			## Order Status: <ORDER_ID>

			### 📋 Status Summary
			| Stage                      | Status       |
			|----------------------------|--------------|
			| Fulfilment Allocation      | COMPLETED/API_EXCEPTION |
			| Fulfilment Created         | YES / NO     |
			| Pick Report                | COMPLETED / FAILED / NOT_STARTED |
			| Delivery Report            | COMPLETED / FAILED / NOT_STARTED |
			| **Overall Health**         | HEALTHY / ERROR / CRITICAL / IN_PROGRESS |

			### 🛒 Ordered Items
			Extract from ORDER_REQUEST_PAYLOAD in context.
			List as: itemId | description | quantity

			[Only include if errors exist in the context:]
			### ⚠️ Issues Detected
			- Error code, affected stage, severity, retry count

			[Only include if errors exist in the context:]
			### 🔧 Remediation Steps
			Numbered steps using REMEDIATION KNOWLEDGE BASE if available.

			─────────────────────────────────────────────────────────────────
			RESPONSE FORMAT B — PICK REPORT REQUEST
			─────────────────────────────────────────────────────────────────
			Triggered when: user asks for pick report, picked items, or
			what was picked for an order.
			Look for PICK_REPORT_PAYLOAD (enrichRequest) in the context.

			## Pick Report: <ORDER_ID>

			### 📦 Pick Status
			| Field           | Value |
			|-----------------|-------|
			| Fulfilment ID   | ...   |
			| Pick Status     | COMPLETED / API_EXCEPTION |
			| Picker ID       | ...   |
			| Retry Attempts  | ...   |

			### 🧺 Picked Items
			Extract from PICK_REPORT_PAYLOAD → pickedItem array.
			Show as a table:
			| Item ID | Description | Ordered Qty | Picked Qty | Substituted |
			|---------|-------------|-------------|------------|-------------|
			| ...     | ...         | ...         | ...        | Yes/No      |

			If substituted = true, add a note showing substituteItemId and substituteDesc.

			[Only if pick failed:]
			### ⚠️ Pick Error
			- Exception details, error code, severity

			### 🔧 Remediation Steps (if applicable)

			─────────────────────────────────────────────────────────────────
			RESPONSE FORMAT C — DELIVERY REPORT REQUEST
			─────────────────────────────────────────────────────────────────
			Triggered when: user asks for delivery report, delivered items,
			or what was delivered for an order.
			Look for DELIVERY_REPORT_PAYLOAD (enrichRequest) in the context.

			## Delivery Report: <ORDER_ID>

			### 🚚 Delivery Status
			| Field           | Value |
			|-----------------|-------|
			| Fulfilment ID   | ...   |
			| Delivery Status | COMPLETED / API_EXCEPTION |
			| Retry Attempts  | ...   |

			### 📬 Delivered Items
			Extract from DELIVERY_REPORT_PAYLOAD → deliveredItem array.
			Show as a table:
			| Item ID | Description | Delivered Qty |
			|---------|-------------|---------------|
			| ...     | ...         | ...           |

			[Only if delivery failed:]
			### ⚠️ Delivery Error
			- Exception details, error code, severity

			### 🔧 Remediation Steps (if applicable)

			─────────────────────────────────────────────────────────────────
			RESPONSE FORMAT D — BULK JOB/ORDER LISTING (1-hour window)
			─────────────────────────────────────────────────────────────────
			When BULK_LISTING_MODE is active in the context, ALWAYS:

			1. Start with this EXACT notice block:
			> 📌 **Showing data for the last 1 hour only.**
			> For the full history of all jobs and orders, please visit the **Dashboard** page.

			2. Then show the data from the WINDOWED_DATA_CONTEXT.

			3. End with this EXACT footer:
			> 💡 To view all historical data, filter by date, or export — please use the **Dashboard** page.

			─────────────────────────────────────────────────────────────────
			RULES
			─────────────────────────────────────────────────────────────────
			1. Always use LIVE DATABASE CONTEXT — never guess or fabricate data.
			2. The ORDER STATUS REPORT in the context contains labelled sections:
			   - ORDER_REQUEST_PAYLOAD   → ordered items (from manage table)
			   - PICK_REPORT_PAYLOAD     → picked items  (from fulfilment table, pickReport event)
			   - DELIVERY_REPORT_PAYLOAD → delivered items (from fulfilment table, deliveryReport event)
			3. When the user asks for pick report → use PICK_REPORT_PAYLOAD
			   When the user asks for delivery report → use DELIVERY_REPORT_PAYLOAD
			   When the user asks for order status → use both to build the summary table
			4. RetryAttempt >= 3 = CRITICAL. Always highlight.
			5. Use REMEDIATION KNOWLEDGE BASE for step-by-step fixes.
			6. SQL queries go in ```sql blocks.
			7. If a payload is not in the context (no enrichRequest stored), say:
			   "No [pick/delivery] report payload available for this order."

			TABLE SCHEMA:
			- manage_fulfilment_job_queue: event_id, event_datetime, event_type, order_id,
			  operation_status, order_request(jsonb), fulfilment_id, exception, retry_attempt
			- fulfilment_job_queue: event_id, event_datetime, event_type, fulfilment_id,
			  operation_status, order_id, enrich_request(jsonb), exception, retry_attempt

			STATUS VALUES: COMPLETED, API_EXCEPTION, PENDING, IN_PROGRESS
			enrich_request for pickReport    = { "pickReport":    { "pickedItem":    [...] } }
			enrich_request for deliveryReport = { "deliveryReport": { "deliveredItem": [...] } }
			""";

	// ── Main chat entry point ──────────────────────────────────────────

	@Transactional
	public ChatRequestDto.Response chat(String userMessage, UUID sessionId) {

		// 1. Session
		ChatSession session = getOrCreateSession(sessionId, userMessage);

		// 2. Classify intent
		List<String> mentionedOrderIds = dataContextService.extractOrderIds(userMessage);
		boolean isBulkListing = dataContextService.isBulkListingRequest(userMessage);
		boolean wantPickPayload = dataContextService.isPickReportRequest(userMessage);
		boolean wantDeliveryPayload = dataContextService.isDeliveryReportRequest(userMessage);
		boolean isSimpleStatus = dataContextService.isSimpleStatusRequest(userMessage);

		// Build QueryIntent
		DataContextService.QueryIntent intent;
		if (wantPickPayload && wantDeliveryPayload) {
			intent = DataContextService.QueryIntent.both();
		} else if (wantPickPayload) {
			intent = DataContextService.QueryIntent.pickOnly();
		} else if (wantDeliveryPayload) {
			intent = DataContextService.QueryIntent.deliveryOnly();
		} else if (isSimpleStatus) {
			intent = DataContextService.QueryIntent.statusOnly();
		} else {
			intent = DataContextService.QueryIntent.fullDetail();
		}

		// 3. Build DB context ───────────────────────────────────────────
		String dbContext;
		List<String> allErrorCodes = new ArrayList<>();

		if (!mentionedOrderIds.isEmpty()) {
			// Specific order(s) — rich context with payload-aware intent
			StringBuilder combined = new StringBuilder();
			for (String orderId : mentionedOrderIds) {
				DataContextService.OrderContext oc = dataContextService.buildOrderContext(orderId, intent);
				combined.append(oc.contextText).append("\n");
				allErrorCodes.addAll(oc.errorCodes);
			}
			combined.append(dataContextService.buildLiveDataContext());
			dbContext = combined.toString();

		} else if (isBulkListing) {
			// Bulk listing — 1-hour window
			DataContextService.WindowedContext wc = dataContextService.buildWindowedDataContext();
			dbContext = buildBulkListingSystemNote(wc) + wc.contextText;

		} else {
			// General query
			dbContext = dataContextService.buildLiveDataContext();
		}

		// 4. RAG — enriched with detected error codes ───────────────────
		String ragQuery = buildRagQuery(userMessage, allErrorCodes);
		List<Document> ragDocs = new ArrayList<>(ragService.search(ragQuery, 3));

		for (String errorCode : allErrorCodes) {
			ragService.search(errorCode, 2).stream()
					.filter(d -> ragDocs.stream().noneMatch(e -> e.getId().equals(d.getId()))).forEach(ragDocs::add);
		}
		String ragContext = buildRagContext(ragDocs);

		// 5. Conversation history (last 10 turns) ──────────────────────
//		List<ChatMessage> history = messageRepo.findBySessionIdOrderByCreatedAtAsc(session.getSessionId());

		// 6. Assemble system message ────────────────────────────────────
		StringBuilder systemMsg = new StringBuilder(SYSTEM_PROMPT);
		systemMsg.append("\n\n=== LIVE DATABASE CONTEXT ===\n").append(dbContext);
		if (!ragContext.isBlank()) {
			systemMsg.append("\n\n=== REMEDIATION KNOWLEDGE BASE ===\n").append(ragContext);
		}
		if (!allErrorCodes.isEmpty()) {
			systemMsg.append("\n\n=== DETECTED ERROR CODES ===\n");
			allErrorCodes.forEach(ec -> systemMsg.append("  - ").append(ec).append("\n"));
			systemMsg.append("IMPORTANT: Provide step-by-step resolution for each code above.\n");
		}

		// Hint the AI on which response format to use
		if (!mentionedOrderIds.isEmpty()) {
			if (wantPickPayload && !wantDeliveryPayload) {
				systemMsg.append("\n=== QUERY TYPE: PICK REPORT REQUEST ===\n")
						.append("User wants the pick report payload. Use RESPONSE FORMAT B.\n")
						.append("Extract PICK_REPORT_PAYLOAD from the context and render the picked items table.\n");
			} else if (wantDeliveryPayload && !wantPickPayload) {
				systemMsg.append("\n=== QUERY TYPE: DELIVERY REPORT REQUEST ===\n")
						.append("User wants the delivery report payload. Use RESPONSE FORMAT C.\n")
						.append("Extract DELIVERY_REPORT_PAYLOAD from the context and render the delivered items table.\n");
			} else if (wantPickPayload) {
				systemMsg.append("\n=== QUERY TYPE: PICK + DELIVERY REPORT REQUEST ===\n")
						.append("User wants both pick and delivery payloads. Use RESPONSE FORMAT B then C.\n");
			} else if (isSimpleStatus) {
				systemMsg.append("\n=== QUERY TYPE: SIMPLE STATUS REQUEST ===\n")
						.append("User wants a status summary. Use RESPONSE FORMAT A.\n")
						.append("Show the status table and ordered items. Include errors if present.\n");
			} else {
				systemMsg.append("\n=== QUERY TYPE: FULL ORDER DETAIL ===\n").append(
						"Show full order details: status, ordered items, pick report, delivery report, and any errors.\n");
			}
		}

		// 7. Build message list ─────────────────────────────────────────
		List<Message> messages = new ArrayList<>();
		messages.add(new SystemMessage(systemMsg.toString()));

//		int start = Math.max(0, history.size() - 10);
//		for (int i = start; i < history.size(); i++) {
//			ChatMessage m = history.get(i);
//			messages.add("USER".equals(m.getRole()) ? new UserMessage(m.getContent())
//					: new AssistantMessage(m.getContent()));
//		}
		messages.add(new UserMessage(userMessage));

		// 8. AI call ────────────────────────────────────────────────────
		String aiResponse;
		try {
			aiResponse = chatClient.prompt().messages(messages).call().content();
		} catch (Exception e) {
			log.error("AI call failed", e);
			aiResponse = "I'm currently unable to process your request. Please try again shortly.";
		}

		// 9. Extract SQL ────────────────────────────────────────────────
		String sqlQuery = extractSql(aiResponse);

		// 10. Persist ───────────────────────────────────────────────────
		messageRepo.save(
				ChatMessage.builder().sessionId(session.getSessionId()).role("USER").content(userMessage).build());

		List<String> sourceList = ragDocs.stream()
				.map(d -> (String) d.getMetadata().getOrDefault("title", "Remediation Doc")).distinct()
				.collect(Collectors.toList());

		ChatMessage assistantMsg = ChatMessage.builder().sessionId(session.getSessionId()).role("ASSISTANT")
				.content(aiResponse).sqlQuery(sqlQuery).sources(sourceList.isEmpty() ? null : sourceList.toString())
				.build();
		messageRepo.save(assistantMsg);

		// 11. Update session title ──────────────────────────────────────
		if (session.getTitle() == null || session.getTitle().isBlank() || "New Chat".equals(session.getTitle())) {
			session.setTitle(userMessage.length() > 60 ? userMessage.substring(0, 57) + "..." : userMessage);
			sessionRepo.save(session);
		}

		return ChatRequestDto.Response.builder().sessionId(session.getSessionId())
				.messageId(assistantMsg.getMessageId()).content(aiResponse).sqlQuery(sqlQuery).sources(sourceList)
				.timestamp(OffsetDateTime.now()).build();
	}

	// ── Session CRUD ───────────────────────────────────────────────────

	public List<ChatRequestDto.MessageInfo> getSessionHistory(UUID sessionId) {
		return messageRepo.findBySessionIdOrderByCreatedAtAsc(sessionId).stream()
				.map(m -> ChatRequestDto.MessageInfo.builder().messageId(m.getMessageId()).role(m.getRole())
						.content(m.getContent()).sqlQuery(m.getSqlQuery())
						.sources(m.getSources() != null ? List.of(m.getSources()) : List.of())
						.createdAt(m.getCreatedAt()).build())
				.collect(Collectors.toList());
	}

	public List<ChatRequestDto.SessionInfo> getAllSessions() {
		return sessionRepo.findByUserIdOrderByUpdatedAtDesc("support-user").stream()
				.map(s -> ChatRequestDto.SessionInfo.builder().sessionId(s.getSessionId())
						.title(s.getTitle() != null ? s.getTitle() : "New Chat").createdAt(s.getCreatedAt())
						.updatedAt(s.getUpdatedAt()).build())
				.collect(Collectors.toList());
	}

	@Transactional
	public ChatRequestDto.SessionInfo createSession() {
		ChatSession session = sessionRepo.save(ChatSession.builder().userId("support-user").title("New Chat").build());
		return ChatRequestDto.SessionInfo.builder().sessionId(session.getSessionId()).title(session.getTitle())
				.createdAt(session.getCreatedAt()).updatedAt(session.getUpdatedAt()).build();
	}

	@Transactional
	public void deleteSession(UUID sessionId) {
		messageRepo.deleteBySessionId(sessionId);
		sessionRepo.findBySessionId(sessionId).ifPresent(sessionRepo::delete);
	}

	private String buildBulkListingSystemNote(DataContextService.WindowedContext wc) {
		return String.format("""
				=== BULK_LISTING_MODE: ACTIVE ===
				The user has requested a listing of all jobs or orders.
				IMPORTANT INSTRUCTIONS:
				1. You MUST show data for the LAST %d HOUR ONLY (%s).
				2. You MUST start your response with the 1-hour notice block (RESPONSE FORMAT D).
				3. You MUST end your response with the dashboard redirect footer.
				4. DO NOT show data outside this time window.
				5. Total events in window: Manage=%d, Fulfilment=%d
				6. Failed jobs in window: Manage=%d, Fulfilment=%d
				=== END BULK_LISTING_MODE ===

				""", wc.windowHours, wc.windowLabel, wc.totalManageEvents, wc.totalFulfilmentEvents,
				wc.failedManageCount, wc.failedFulfilmentCount);
	}

	private ChatSession getOrCreateSession(UUID sessionId, String firstMessage) {
		if (sessionId != null) {
			return sessionRepo.findBySessionId(sessionId).orElseGet(() -> createNewSession(firstMessage));
		}
		return createNewSession(firstMessage);
	}

	private ChatSession createNewSession(String firstMessage) {
		String title = firstMessage != null && firstMessage.length() > 60 ? firstMessage.substring(0, 57) + "..."
				: firstMessage;
		return sessionRepo.save(ChatSession.builder().userId("support-user").title(title).build());
	}

	private String buildRagQuery(String userMessage, List<String> errorCodes) {
		if (errorCodes.isEmpty())
			return userMessage;
		return userMessage + " " + String.join(" ", errorCodes) + " remediation resolution fix";
	}

	private String buildRagContext(List<Document> docs) {
		if (docs.isEmpty())
			return "";
		StringBuilder sb = new StringBuilder();
		for (Document doc : docs) {
			String title = (String) doc.getMetadata().getOrDefault("title", "Remediation Doc");
			String errorCode = (String) doc.getMetadata().getOrDefault("errorCode", "");
			sb.append("--- ").append(title);
			if (!errorCode.isBlank())
				sb.append(" [").append(errorCode).append("]");
			sb.append(" ---\n").append(doc.getText()).append("\n\n");
		}
		return sb.toString();
	}

	private String extractSql(String response) {
		Pattern p = Pattern.compile("```sql\\s*([\\s\\S]*?)```", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(response);
		return m.find() ? m.group(1).trim() : null;
	}

	public PreparedPrompt preparePrompt(String userMessage, UUID sessionId) {
		ChatSession session = getOrCreateSession(sessionId, userMessage);

		// Intent classification
		boolean isErrorCodeOnly = dataContextService.isErrorCodeOnlyRequest(userMessage);
		List<String> mentionedOrderIds = dataContextService.extractOrderIds(userMessage);
		boolean isBulkListing = dataContextService.isBulkListingRequest(userMessage);
		boolean wantPickPayload = dataContextService.isPickReportRequest(userMessage);
		boolean wantDeliveryPayload = dataContextService.isDeliveryReportRequest(userMessage);
		boolean isSimpleStatus = dataContextService.isSimpleStatusRequest(userMessage);

		// ── ERROR CODE ONLY path ─────────────────────────────────────────
		// User asked about a specific error code with no order ID.
		// Skip all DB context entirely — answer purely from the RAG knowledge base.
		if (isErrorCodeOnly) {
			List<String> errorCodes = dataContextService.extractErrorCodes(userMessage);

			// Search RAG with the error codes directly for maximum precision
			List<Document> ragDocs = new ArrayList<>();
			for (String ec : errorCodes) {
				ragService.search(ec, 3).stream()
						.filter(d -> ragDocs.stream().noneMatch(e -> e.getId().equals(d.getId())))
						.forEach(ragDocs::add);
			}
			// Also search with the full user message in case wording helps retrieval
//            ragService.search(userMessage, 3).stream()
//                    .filter(d -> ragDocs.stream().noneMatch(e -> e.getId().equals(d.getId())))
//                    .forEach(ragDocs::add);

			String ragContext = buildRagContext(ragDocs);

//            List<ChatMessage> history =
//                    messageRepo.findBySessionIdOrderByCreatedAtAsc(session.getSessionId());

			StringBuilder systemMsg = new StringBuilder(SYSTEM_PROMPT);
			systemMsg.append("\n\n=== QUERY TYPE: ERROR CODE DOCUMENTATION REQUEST ===\n");
			systemMsg.append("The user is asking about a specific error code. ");
			systemMsg.append("Answer ONLY using the REMEDIATION KNOWLEDGE BASE below. ");
			systemMsg.append("Do NOT query or reference the live database context — it is not relevant here. ");
			systemMsg.append("Provide: what the error means, its root causes, and numbered resolution steps.\n");
			systemMsg.append("Error codes requested: ").append(String.join(", ", errorCodes)).append("\n");

			if (!ragContext.isBlank()) {
				systemMsg.append("\n=== REMEDIATION KNOWLEDGE BASE ===\n").append(ragContext);
			} else {
				systemMsg.append("\n[No remediation documents found for these error codes. ");
				systemMsg.append("Provide general guidance based on the error code name.]\n");
			}

			List<Message> messages = new ArrayList<>();
			messages.add(new SystemMessage(systemMsg.toString()));
//            int start = Math.max(0, history.size() - 10);
//            for (int i = start; i < history.size(); i++) {
//                ChatMessage m = history.get(i);
//                messages.add("USER".equals(m.getRole())
//                        ? new UserMessage(m.getContent())
//                        : new AssistantMessage(m.getContent()));
//            }
			messages.add(new UserMessage(userMessage));

			List<String> sourceList = ragDocs.stream()
					.map(d -> (String) d.getMetadata().getOrDefault("title", "Remediation Doc")).distinct()
					.collect(Collectors.toList());

			return new PreparedPrompt(session, messages, errorCodes, sourceList);
		}

		DataContextService.QueryIntent intent;
		if (wantPickPayload && wantDeliveryPayload)
			intent = DataContextService.QueryIntent.both();
		else if (wantPickPayload)
			intent = DataContextService.QueryIntent.pickOnly();
		else if (wantDeliveryPayload)
			intent = DataContextService.QueryIntent.deliveryOnly();
		else if (isSimpleStatus)
			intent = DataContextService.QueryIntent.statusOnly();
		else
			intent = DataContextService.QueryIntent.fullDetail();

		// DB context
		String dbContext;
		List<String> allErrorCodes = new ArrayList<>();
		if (!mentionedOrderIds.isEmpty()) {
			StringBuilder combined = new StringBuilder();
			for (String orderId : mentionedOrderIds) {
				DataContextService.OrderContext oc = dataContextService.buildOrderContext(orderId, intent);
				combined.append(oc.contextText).append("\n");
				allErrorCodes.addAll(oc.errorCodes);
			}
			combined.append(dataContextService.buildLiveDataContext());
			dbContext = combined.toString();
		} else if (isBulkListing) {
			DataContextService.WindowedContext wc = dataContextService.buildWindowedDataContext();
			dbContext = buildBulkListingSystemNote(wc) + wc.contextText;
		} else {
			dbContext = dataContextService.buildLiveDataContext();
		}

		// RAG
		String ragQuery = buildRagQuery(userMessage, allErrorCodes);
		List<Document> ragDocs = new ArrayList<>(ragService.search(ragQuery, 5));
		for (String ec : allErrorCodes) {
			ragService.search(ec, 2).stream().filter(d -> ragDocs.stream().noneMatch(e -> e.getId().equals(d.getId())))
					.forEach(ragDocs::add);
		}
		String ragContext = buildRagContext(ragDocs);

		// History (last 10 turns)
//		List<ChatMessage> history = messageRepo.findBySessionIdOrderByCreatedAtAsc(session.getSessionId());

		// System message
		StringBuilder systemMsg = new StringBuilder(SYSTEM_PROMPT);
		systemMsg.append("\n\n=== LIVE DATABASE CONTEXT ===\n").append(dbContext);
		if (!ragContext.isBlank()) {
			systemMsg.append("\n\n=== REMEDIATION KNOWLEDGE BASE ===\n").append(ragContext);
		}
		if (!allErrorCodes.isEmpty()) {
			systemMsg.append("\n\n=== DETECTED ERROR CODES ===\n");
			allErrorCodes.forEach(ec -> systemMsg.append("  - ").append(ec).append("\n"));
			systemMsg.append("IMPORTANT: Provide step-by-step resolution for each code above.\n");
		}
		if (!mentionedOrderIds.isEmpty()) {
			if (wantPickPayload && !wantDeliveryPayload)
				systemMsg.append(
						"\n=== QUERY TYPE: PICK REPORT REQUEST ===\nUse RESPONSE FORMAT B. Extract PICK_REPORT_PAYLOAD.\n");
			else if (wantDeliveryPayload && !wantPickPayload)
				systemMsg.append(
						"\n=== QUERY TYPE: DELIVERY REPORT REQUEST ===\nUse RESPONSE FORMAT C. Extract DELIVERY_REPORT_PAYLOAD.\n");
			else if (wantPickPayload)
				systemMsg.append("\n=== QUERY TYPE: PICK + DELIVERY REQUEST ===\nUse RESPONSE FORMAT B then C.\n");
			else if (isSimpleStatus)
				systemMsg.append("\n=== QUERY TYPE: SIMPLE STATUS REQUEST ===\nUse RESPONSE FORMAT A.\n");
			else
				systemMsg.append(
						"\n=== QUERY TYPE: FULL ORDER DETAIL ===\nShow full order details including pick and delivery.\n");
		}

		// Message list
		List<Message> messages = new ArrayList<>();
		messages.add(new SystemMessage(systemMsg.toString()));
//        int start = Math.max(0, history.size() - 10);
//        for (int i = start; i < history.size(); i++) {
//            ChatMessage m = history.get(i);
//            messages.add("USER".equals(m.getRole())
//                    ? new UserMessage(m.getContent())
//                    : new AssistantMessage(m.getContent()));
//        }
		messages.add(new UserMessage(userMessage));

		List<String> sourceList = ragDocs.stream()
				.map(d -> (String) d.getMetadata().getOrDefault("title", "Remediation Doc")).distinct()
				.collect(Collectors.toList());

		return new PreparedPrompt(session, messages, allErrorCodes, sourceList);
	}

	/** Value object carrying everything preparePrompt() produced. */
	public record PreparedPrompt(ChatSession session, List<Message> messages, List<String> errorCodes,
			List<String> sources) {
	}

	private String sourcesToJson(List<String> sources) {
		if (sources == null || sources.isEmpty())
			return "[]";
		StringBuilder sb = new StringBuilder("[");
		for (int i = 0; i < sources.size(); i++) {
			if (i > 0)
				sb.append(",");
			sb.append("\"").append(sources.get(i).replace("\"", "\\\"")).append("\"");
		}
		sb.append("]");
		return sb.toString();
	}

	public Flux<String> streamChat(String userMessage, UUID sessionId) {
		PreparedPrompt prep;
		try {
			prep = preparePrompt(userMessage, sessionId);
		} catch (Exception e) {
			log.error("Context preparation failed", e);
			return Flux.just("Sorry, I encountered an error preparing your request. Please try again.")
					.concatWith(Flux.just("[DONE]"));
		}

		// Persist the user message immediately so the session title is set
		// and the message appears in history even if the stream is interrupted
		messageRepo.save(ChatMessage.builder().sessionId(prep.session().getSessionId()).role("USER")
				.content(userMessage).build());

		// Update session title from first message
		if (prep.session().getTitle() == null || prep.session().getTitle().isBlank()
				|| "New Chat".equals(prep.session().getTitle())) {
			prep.session().setTitle(userMessage.length() > 60 ? userMessage.substring(0, 57) + "..." : userMessage);
			sessionRepo.save(prep.session());
		}

		// Accumulate the full response as it streams
		StringBuilder fullResponse = new StringBuilder();

		return chatClient.prompt().messages(prep.messages()).stream().content().doOnNext(fullResponse::append)
				.concatWith(
						// After the stream ends: persist, then emit the metadata sentinel
						Flux.defer(() -> {
							String aiResponse = fullResponse.toString();
							String sqlQuery = extractSql(aiResponse);
							String sources = prep.sources().isEmpty() ? null : prep.sources().toString();

							ChatMessage assistantMsg = ChatMessage.builder().sessionId(prep.session().getSessionId())
									.role("ASSISTANT").content(aiResponse).sqlQuery(sqlQuery).sources(sources).build();
							messageRepo.save(assistantMsg);

							// Build the metadata JSON manually (no external dep needed)
							String meta = String.format(
									"{\"sessionId\":\"%s\",\"messageId\":\"%s\",\"sqlQuery\":%s,\"sources\":%s}",
									prep.session().getSessionId(), assistantMsg.getMessageId(),
									sqlQuery != null ? "\"" + sqlQuery.replace("\"", "\\\"").replace("\n", "\\n") + "\""
											: "null",
									sourcesToJson(prep.sources()));
							return Flux.just("[DONE_META]:" + meta, "[DONE]");
						}))
				.onErrorResume(e -> {
					log.error("Streaming error", e);
					return Flux.just("\n\n*An error occurred while generating the response.*", "[DONE]");
				});
	}
}
