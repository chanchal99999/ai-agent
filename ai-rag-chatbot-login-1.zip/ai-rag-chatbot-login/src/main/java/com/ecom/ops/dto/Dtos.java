package com.ecom.ops.dto;

import lombok.*;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

// ---- Chat DTOs ----

@Data @NoArgsConstructor @AllArgsConstructor @Builder
class ChatRequest {
    private String message;
    private UUID sessionId;
}

@Data @NoArgsConstructor @AllArgsConstructor @Builder
class ChatResponse {
    private UUID sessionId;
    private UUID messageId;
    private String content;
    private String sqlQuery;
    private List<String> sources;
    private OffsetDateTime timestamp;
}

@Data @NoArgsConstructor @AllArgsConstructor @Builder
class SessionDto {
    private UUID sessionId;
    private String title;
    private String userId;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;
}

@Data @NoArgsConstructor @AllArgsConstructor @Builder
class MessageDto {
    private UUID messageId;
    private String role;
    private String content;
    private String sqlQuery;
    private List<String> sources;
    private OffsetDateTime createdAt;
}

// ---- Order / Job DTOs ----

@Data @NoArgsConstructor @AllArgsConstructor @Builder
class ManageFulfilmentDto {
    private String eventId;
    private OffsetDateTime eventDatetime;
    private String eventType;
    private String orderId;
    private String operationStatus;
    private String orderRequest;
    private String fulfilmentId;
    private String exception;
    private Integer retryAttempt;
}

@Data @NoArgsConstructor @AllArgsConstructor @Builder
class FulfilmentJobDto {
    private String eventId;
    private OffsetDateTime eventDatetime;
    private String eventType;
    private String fulfilmentId;
    private String operationStatus;
    private String orderId;
    private String enrichRequest;
    private String exception;
    private Integer retryAttempt;
}

@Data @NoArgsConstructor @AllArgsConstructor @Builder
class RemediationDocumentDto {
    private UUID documentId;
    private String title;
    private String errorCode;
    private String errorType;
    private String content;
    private String fileName;
    private String mimeType;
    private String uploadedBy;
    private String[] tags;
    private Boolean isActive;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;
}

@Data @NoArgsConstructor @AllArgsConstructor @Builder
class OrderSummaryDto {
    private String orderId;
    private String fulfilmentStatus;
    private String fulfilmentId;
    private String pickStatus;
    private String deliveryStatus;
    private List<String> errors;
    private Boolean hasPriorityIssue;
}

public class Dtos {
    public static ChatRequest chatRequest() { return new ChatRequest(); }
    public static ChatResponse chatResponse() { return new ChatResponse(); }
    public static SessionDto sessionDto() { return new SessionDto(); }
    public static MessageDto messageDto() { return new MessageDto(); }
    public static ManageFulfilmentDto manageFulfilmentDto() { return new ManageFulfilmentDto(); }
    public static FulfilmentJobDto fulfilmentJobDto() { return new FulfilmentJobDto(); }
    public static RemediationDocumentDto remediationDocumentDto() { return new RemediationDocumentDto(); }
    public static OrderSummaryDto orderSummaryDto() { return new OrderSummaryDto(); }
}
