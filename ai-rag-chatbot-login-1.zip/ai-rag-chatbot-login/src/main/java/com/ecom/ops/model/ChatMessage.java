package com.ecom.ops.model;

import java.time.OffsetDateTime;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "chat_message")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ChatMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "message_id", unique = true)
    private UUID messageId;

    @Column(name = "session_id")
    private UUID sessionId;

    @Column(name = "role", nullable = false)
    private String role; // USER or ASSISTANT

    @Column(name = "content", columnDefinition = "TEXT", nullable = false)
    private String content;

    @Column(name = "sql_query", columnDefinition = "TEXT")
    private String sqlQuery;

//    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "sources", columnDefinition = "TEXT")
    private String sources;

    @Column(name = "created_at")
    private OffsetDateTime createdAt;

    @PrePersist
    public void prePersist() {
        if (messageId == null) messageId = UUID.randomUUID();
        createdAt = OffsetDateTime.now();
    }
}
