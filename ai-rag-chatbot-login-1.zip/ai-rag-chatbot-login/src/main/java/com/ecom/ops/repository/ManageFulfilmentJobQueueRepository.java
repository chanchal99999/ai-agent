package com.ecom.ops.repository;

import com.ecom.ops.model.ManageFulfilmentJobQueue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ManageFulfilmentJobQueueRepository extends JpaRepository<ManageFulfilmentJobQueue, Long> {

    List<ManageFulfilmentJobQueue> findByOrderId(String orderId);

    List<ManageFulfilmentJobQueue> findByOperationStatus(String status);

    Optional<ManageFulfilmentJobQueue> findByEventId(String eventId);

    @Query("SELECT m FROM ManageFulfilmentJobQueue m WHERE m.exception IS NOT NULL ORDER BY m.eventDatetime DESC")
    List<ManageFulfilmentJobQueue> findAllWithErrors();

    @Query("SELECT m FROM ManageFulfilmentJobQueue m WHERE m.operationStatus = 'API_EXCEPTION' ORDER BY m.retryAttempt DESC, m.eventDatetime DESC")
    List<ManageFulfilmentJobQueue> findFailedJobs();

    @Query("SELECT m FROM ManageFulfilmentJobQueue m WHERE m.exception LIKE %:errorCode% ORDER BY m.eventDatetime DESC")
    List<ManageFulfilmentJobQueue> findByErrorCode(@Param("errorCode") String errorCode);

    // ── Time-windowed queries ──────────────────────────────────────────

    @Query("SELECT m FROM ManageFulfilmentJobQueue m WHERE m.eventDatetime >= :from AND m.eventDatetime <= :to ORDER BY m.eventDatetime DESC")
    List<ManageFulfilmentJobQueue> findByDateRange(
            @Param("from") OffsetDateTime from,
            @Param("to") OffsetDateTime to);

    @Query("SELECT COUNT(m) FROM ManageFulfilmentJobQueue m WHERE m.eventDatetime >= :from AND m.eventDatetime <= :to")
    long countByDateRange(
            @Param("from") OffsetDateTime from,
            @Param("to") OffsetDateTime to);

    @Query("SELECT COUNT(m) FROM ManageFulfilmentJobQueue m WHERE m.operationStatus = :status AND m.eventDatetime >= :from AND m.eventDatetime <= :to")
    long countByStatusAndDateRange(
            @Param("status") String status,
            @Param("from") OffsetDateTime from,
            @Param("to") OffsetDateTime to);

    @Query("SELECT m FROM ManageFulfilmentJobQueue m WHERE m.operationStatus = 'API_EXCEPTION' AND m.eventDatetime >= :from AND m.eventDatetime <= :to ORDER BY m.retryAttempt DESC, m.eventDatetime DESC")
    List<ManageFulfilmentJobQueue> findFailedJobsByDateRange(
            @Param("from") OffsetDateTime from,
            @Param("to") OffsetDateTime to);
}
