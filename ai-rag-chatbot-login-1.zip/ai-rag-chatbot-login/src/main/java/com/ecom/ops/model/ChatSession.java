package com.ecom.ops.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "chat_session")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ChatSession {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "session_id", unique = true)
	private UUID sessionId;

	@Column(name = "user_id")
	private String userId;

	@Column(name = "title")
	private String title;

	@Column(name = "created_at")
	private OffsetDateTime createdAt;

	@Column(name = "updated_at")
	private OffsetDateTime updatedAt;

	// Removed @OneToMany(mappedBy = "sessionId") — sessionId in ChatMessage is a
	// raw UUID
	// field, not a @ManyToOne relationship, so the cascade caused:
	// "No operator matches the given name and argument types"
	// Messages are now deleted explicitly in ChatbotService before the session is
	// deleted.

	@PrePersist
	public void prePersist() {
		if (sessionId == null)
			sessionId = UUID.randomUUID();
		createdAt = OffsetDateTime.now();
		updatedAt = OffsetDateTime.now();
	}

	@PreUpdate
	public void preUpdate() {
		updatedAt = OffsetDateTime.now();
	}
}
