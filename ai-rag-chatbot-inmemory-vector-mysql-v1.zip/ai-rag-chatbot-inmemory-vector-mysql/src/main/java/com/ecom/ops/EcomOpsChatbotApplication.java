package com.ecom.ops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@EnableAsync
@Slf4j
public class EcomOpsChatbotApplication {
	public static void main(String[] args) {
		SpringApplication.run(EcomOpsChatbotApplication.class, args);
		log.info("------In Memoery Vector MySql--------");
	}
}
