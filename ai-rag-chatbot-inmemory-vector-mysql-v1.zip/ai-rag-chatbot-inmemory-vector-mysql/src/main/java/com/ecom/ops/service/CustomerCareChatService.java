package com.ecom.ops.service;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

import com.ecom.ops.dto.ChatRequestDto.MessageInfo;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;

/**
 * Customer-care scoped chat. Unlike the full ChatbotService, this agent is
 * RESTRICTED on the backend so a CUSTOMER_CARE user can ONLY retrieve order
 * status / details. It deliberately: - does NOT run RAG / remediation lookups -
 * does NOT expose failed-job internals, SQL, or exception stack traces - only
 * answers order-status questions; anything else is politely refused
 *
 * When an order is found in a failure state, the reply ends with a structured
 * hint [INCIDENT_AVAILABLE]:{"orderId":...,"errorCode":...} that the UI turns
 * into a "Raise Incident" button. The agent never auto-creates incidents.
 *
 * The Flux<String> it returns is streamed by ChatController exactly like the
 * full agent (each emission becomes one SSE `data:` frame), so the existing
 * frontend SSE parser works unchanged.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class CustomerCareChatService {

	private final OrderService orderService;
	private final ChatbotService chatbotService; // reused for per-user persistence

	private static final Pattern ORDER_ID = Pattern.compile("ORD-\\d+", Pattern.CASE_INSENSITIVE);
	private static final Pattern ERROR_CODE = Pattern.compile("ErrorCode:([^,\\s]+)", Pattern.CASE_INSENSITIVE);

	public Flux<String> streamCareChat(String userMessage, UUID sessionId, String username) {

		// 1) Scope: must reference an order id.
		List<String> orderIds = extractOrderIds(userMessage);
		if (orderIds.isEmpty()) {

			List<MessageInfo> messageInfos = chatbotService.getSessionHistory(sessionId);

			for (MessageInfo messageInfo : messageInfos) {
				orderIds = extractOrderIds(messageInfo.getContent());
				if (orderIds.isEmpty()) {
					continue;
				}
			}
			if (orderIds.isEmpty())
				return refuse(username, sessionId, userMessage,
						"I can only help with order status. Please share an order ID, "
								+ "for example: \"What is the status of ORD-12345?\"");
		}

		// 2) Scope: must be a status-type question (block internals).
		if (!isOrderStatusIntent(userMessage)) {
			return refuse(username, sessionId, userMessage,
					"As customer care support, I can only look up order status and details. "
							+ "I'm not able to help with that request.");
		}

		// 3) Read-only lookup via the existing OrderService.
		String orderId = orderIds.get(0).toUpperCase();
		Map<String, Object> summary = orderService.getOrderSummary(orderId);

		boolean exists = summaryHasData(summary);
		if (!exists) {
			return refuse(username, sessionId, userMessage,
					"I couldn't find an order with ID " + orderId + ". Please double-check the order number.");
		}

		boolean failed = isFailed(summary);
		String errorCode = failed ? firstErrorCode(summary) : null;

		// 4) Customer-friendly reply (never leak internal fields).
		String reply = buildReply(orderId, summary, failed, errorCode);
		String hintTail = "";
		if (failed) {
			hintTail = "\n\n[INCIDENT_AVAILABLE]:{\"orderId\":\"" + orderId + "\",\"errorCode\":\""
					+ (errorCode == null ? "" : errorCode) + "\"}";
		}

		// 5) Persist the turn under the real user so it appears in their history.
		chatbotService.persistCareTurn(username, sessionId, userMessage, reply);

		return Flux.just(reply + hintTail);
	}

	// ---------- helpers ----------

	private List<String> extractOrderIds(String text) {
		java.util.ArrayList<String> ids = new java.util.ArrayList<>();
		Matcher m = ORDER_ID.matcher(text == null ? "" : text);
		while (m.find())
			ids.add(m.group());
		return ids;
	}

	private boolean isOrderStatusIntent(String message) {
		if (message == null)
			return false;
		String m = message.toLowerCase();
		boolean statusy = m.contains("status") || m.contains("where") || m.contains("track") || m.contains("detail")
				|| m.contains("eta") || m.contains("delivered") || m.contains("delivery") || m.contains("update on")
				|| m.contains("order");
		boolean restricted = m.contains("fix") || m.contains("remediat") || m.contains("sql") || m.contains("exception")
				|| m.contains("stack") || m.contains("query") || m.contains("failed job") || m.contains("database")
				|| m.contains("payload");
		return statusy && !restricted;
	}

	private boolean summaryHasData(Map<String, Object> summary) {
		Object m = summary.get("manageEvents");
		Object f = summary.get("fulfilmentEvents");
		boolean hasManage = (m instanceof List<?> l) && !l.isEmpty();
		boolean hasFul = (f instanceof List<?> l) && !l.isEmpty();
		return hasManage || hasFul;
	}

	private boolean isFailed(Map<String, Object> summary) {
		Object hp = summary.get("hasPriorityIssue");
		if (hp instanceof Boolean b && b)
			return true;
		Object fs = summary.get("fulfilmentStatus");
		Object ps = summary.get("pickStatus");
		Object ds = summary.get("deliveryStatus");
		return "API_EXCEPTION".equals(fs) || "API_EXCEPTION".equals(ps) || "API_EXCEPTION".equals(ds);
	}

	private String firstErrorCode(Map<String, Object> summary) {
		Object errs = summary.get("errors");
		if (errs instanceof List<?> list) {
			for (Object e : list) {
				if (e == null)
					continue;
				Matcher m = ERROR_CODE.matcher(e.toString());
				if (m.find())
					return m.group(1).trim();
			}
		}
		return null;
	}

	private String buildReply(String orderId, Map<String, Object> summary, boolean failed, String errorCode) {
		if (failed) {
			return "Order **" + orderId + "** is currently delayed due to a processing issue"
					+ (errorCode != null ? " (" + errorCode + ")" : "")
					+ ". Our operations team can investigate this for you — you can raise an "
					+ "incident below and they'll take it forward.";
		}
		Object fs = summary.getOrDefault("fulfilmentStatus", "UNKNOWN");
		Object ps = summary.getOrDefault("pickStatus", "NOT_FOUND");
		Object ds = summary.getOrDefault("deliveryStatus", "NOT_FOUND");
		StringBuilder sb = new StringBuilder();
		sb.append("Here's the latest on order **").append(orderId).append("**:\n\n");
		sb.append("| Stage | Status |\n|---|---|\n");
		sb.append("| Fulfilment | ").append(fs).append(" |\n");
		sb.append("| Pick | ").append(prettyStage(ps)).append(" |\n");
		sb.append("| Delivery | ").append(prettyStage(ds)).append(" |\n\n");
		sb.append("Everything is progressing normally.");
		return sb.toString();
	}

	private String prettyStage(Object status) {
		if (status == null)
			return "Pending";
		String s = status.toString();
		if ("NOT_FOUND".equals(s))
			return "Pending";
		if ("COMPLETED".equals(s))
			return "Completed";
		return s;
	}

	private Flux<String> refuse(String username, UUID sessionId, String userMessage, String message) {
		// Persist the refusal too, so the care user's history is complete.
		try {
			chatbotService.persistCareTurn(username, sessionId, userMessage, message);
		} catch (Exception ignored) {
		}
		return Flux.just(message);
	}
}
