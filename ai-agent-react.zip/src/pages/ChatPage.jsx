import { useState, useEffect, useRef, useCallback } from 'react'
import { useParams, useNavigate, useLocation } from 'react-router-dom'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism'
import {
  Send, Plus, Trash2, MessageSquare, Bot, User,
  Copy, Check, ChevronRight, Loader2, BookOpen, Database,
  Eye, EyeOff
} from 'lucide-react'
import { chatApi } from '../services/api.js'
// import { formatRelative } from '../utils/helpers.js'
import toast from 'react-hot-toast'
import styles from './ChatPage.module.css'

const SUGGESTIONS = [
  'Show me all failed jobs',
  'What errors does order ORD-123457 have?',
  'Show me priority issues',
  'How to resolve ACC-API-FUL-EERROR?',
  'Give me pick report status for ORD-123458',
  'Show orders with API_EXCEPTION status',
  'What is the delivery status of ORD-123456?',
  'Show me SQL to find all failed fulfilment jobs',
]

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false)
  const copy = (e) => {
    e.stopPropagation()
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button onClick={copy} className={styles.copyBtn} title="Copy to clipboard">
      {copied ? <Check size={13} /> : <Copy size={13} />}
    </button>
  )
}

function SqlBlock({ code }) {
  const [open, setOpen] = useState(false)
  return (
    <div className={`${styles.sqlBlock} ${open ? styles.sqlBlockOpen : ''}`}>
      <button className={styles.sqlToggle} onClick={() => setOpen(v => !v)}>
        <span className={styles.sqlToggleLeft}>
          <Database size={13} className={styles.sqlIcon} />
          <span className={styles.sqlLabel}>SQL Query</span>
          <span className={styles.sqlPill}>{open ? 'hide' : 'view'}</span>
        </span>
        <span className={styles.sqlToggleRight}>
          <CopyBtn text={code} />
          {open ? <EyeOff size={14} className={styles.sqlEyeIcon} /> : <Eye size={14} className={styles.sqlEyeIcon} />}
        </span>
      </button>
      {open && (
        <div className={`${styles.sqlBody} fade-in`}>
          <SyntaxHighlighter style={oneDark} language="sql" PreTag="div">
            {code}
          </SyntaxHighlighter>
        </div>
      )}
    </div>
  )
}

function CodeBlock({ lang, code }) {
  return (
    <div className={styles.codeBlock}>
      <div className={styles.codeHeader}>
        <span className={styles.codeLang}>{lang.toUpperCase()}</span>
        <CopyBtn text={code} />
      </div>
      <SyntaxHighlighter style={oneDark} language={lang} PreTag="div">
        {code}
      </SyntaxHighlighter>
    </div>
  )
}

function MessageBubble({ msg }) {
  const isUser = msg.role === 'USER'
  const isStreaming = msg.streaming === true

  return (
    <div className={`${styles.msgRow} ${isUser ? styles.msgRowUser : ''} fade-in`}>
      <div className={`${styles.avatar} ${isUser ? styles.avatarUser : styles.avatarBot}`}>
        {isUser ? <User size={14} /> : <Bot size={14} />}
      </div>
      <div className={`${styles.bubble} ${isUser ? styles.bubbleUser : styles.bubbleBot}`}>
        {isUser ? (
          <p className={styles.userText}>{msg.content}</p>
        ) : (
          <div className={styles.markdown}>
            {/* Show typing dots only when streaming hasn't started yet */}
            {isStreaming && !msg.content ? (
              <div className={styles.streamingDots}>
                <span className={styles.dot} />
                <span className={styles.dot} />
                <span className={styles.dot} />
              </div>
            ) : (
              <>
                <ReactMarkdown
                  remarkPlugins={[remarkGfm]}
                  components={{
                    code({ inline, className, children }) {
                      const match = /language-(\w+)/.exec(className || '')
                      const codeStr = String(children).replace(/\n$/, '')
                      if (!inline && match) {
                        const lang = match[1].toLowerCase()
                        return lang === 'sql'
                          ? <SqlBlock code={codeStr} />
                          : <CodeBlock lang={lang} code={codeStr} />
                      }
                      return <code className={className}>{children}</code>
                    },
                    table({ children }) {
                      return (
                        <div className={styles.tableWrap}>
                          <table className="data-table">{children}</table>
                        </div>
                      )
                    }
                  }}
                >
                  {msg.content}
                </ReactMarkdown>
                {/* Blinking cursor while streaming */}
                {isStreaming && <span className={styles.streamCursor} />}
                {!isStreaming && msg.sources && msg.sources.length > 0 && (
                  <div className={styles.sources}>
                    <BookOpen size={11} />
                    <span>Sources: {Array.isArray(msg.sources) ? msg.sources.join(', ') : msg.sources}</span>
                  </div>
                )}
              </>
            )}
          </div>
        )}
        {!isStreaming && <span className={styles.msgTime}>{msg.createdAt}</span>}
      </div>
    </div>
  )
}

export default function ChatPage() {
  const { sessionId: paramSessionId } = useParams()
  const navigate  = useNavigate()
  const location  = useLocation()
  const [sessions, setSessions] = useState([])
  const [activeSessionId, setActiveSessionId] = useState(null)
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [loadingSessions, setLoadingSessions] = useState(true)
  const bottomRef = useRef(null)
  const textareaRef = useRef(null)
  // Track whether we've processed the prefill so we don't repeat it
  const prefillHandled = useRef(false)
  const [prefillActive, setPrefillActive] = useState(false)

  useEffect(() => {
    chatApi.getSessions()
      .then(setSessions)
      .catch(() => toast.error('Failed to load sessions'))
      .finally(() => setLoadingSessions(false))
  }, [])

  // ── Prefill: create new session + populate input when arriving from
  //    Priority page ("Resolve with AI") or Orders page ("Ask Chatbot")
  useEffect(() => {
    if (prefillHandled.current) return
    const state = location.state

    // Support both location.state.prefill (text) and structured { orderId, exception }
    let prefillText = ''
    if (state?.prefill) {
      prefillText = state.prefill
    } else if (state?.orderId || state?.exception) {
      const parts = []
      if (state.orderId)   parts.push(`What is the status of order ${state.orderId}?`)
      if (state.exception) {
        // Extract error code from exception string e.g. "ErrorCode:ACC-API-FUL-ERROR,..."
        const match = state.exception.match(/ErrorCode:([^,]+)/)
        const code  = match ? match[1].trim() : null
        if (code && !state.orderId) {
          parts[0] = `How do I resolve ${code} for order ${state.orderId}?`
        } else if (code) {
          parts[0] = `What is the status of order ${state.orderId} and how do I fix the ${code} error?`
        }
      }
      prefillText = parts[0] || ''
    }

    if (!prefillText) return
    prefillHandled.current = true

    // Create a fresh session then set the input — do NOT send automatically
    ;(async () => {
      try {
        const session = await chatApi.createSession()
        setSessions(prev => [session, ...prev])
        setActiveSessionId(session.sessionId)
        setMessages([])
        navigate(`/chat/${session.sessionId}`, { replace: true, state: {} })
        setInput(prefillText)
        setPrefillActive(true)
        // Focus the textarea after React re-renders
        setTimeout(() => textareaRef.current?.focus(), 80)
      } catch {
        // Fallback: just set the input without a new session
        setInput(prefillText)
        setPrefillActive(true)
        setTimeout(() => textareaRef.current?.focus(), 80)
      }
    })()
  }, [location.state])

  useEffect(() => {
    if (paramSessionId && paramSessionId !== activeSessionId) {
      setActiveSessionId(paramSessionId)
      chatApi.getMessages(paramSessionId)
        .then(setMessages)
        .catch(() => toast.error('Failed to load messages'))
    }
  }, [paramSessionId])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const newSession = async () => {
    try {
      const session = await chatApi.createSession()
      setSessions(prev => [session, ...prev])
      setActiveSessionId(session.sessionId)
      setMessages([])
      navigate(`/chat/${session.sessionId}`)
    } catch {
      toast.error('Failed to create session')
    }
  }

  const selectSession = async (sessionId) => {
    setActiveSessionId(sessionId)
    navigate(`/chat/${sessionId}`)
    try {
      const msgs = await chatApi.getMessages(sessionId)
      setMessages(msgs)
    } catch {
      toast.error('Failed to load messages')
    }
  }

  const deleteSession = async (e, sessionId) => {
    e.stopPropagation()
    try {
      await chatApi.deleteSession(sessionId)
      setSessions(prev => prev.filter(s => s.sessionId !== sessionId))
      if (activeSessionId === sessionId) {
        setActiveSessionId(null)
        setMessages([])
        navigate('/chat')
      }
      toast.success('Session deleted')
    } catch {
      toast.error('Failed to delete session')
    }
  }

  const send = useCallback(async (text) => {
    const msg = (text || input).trim()
    if (!msg || loading) return
    setInput('')
    setPrefillActive(false)

    // Add user message immediately
    const tempUserId = 'tmp-user-' + Date.now()
    const tempUser = {
      role: 'USER', content: msg,
      createdAt: new Date().toISOString(), messageId: tempUserId
    }
    // Add a streaming placeholder for the assistant response
    const streamingId = 'tmp-stream-' + Date.now()
    setMessages(prev => [...prev, tempUser, {
      role: 'ASSISTANT', content: '', messageId: streamingId,
      createdAt: new Date().toISOString(), streaming: true
    }])
    setLoading(true)

    try {
      const token = localStorage.getItem('ecom_ops_token')
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          message: msg,
          sessionId: activeSessionId || undefined
        })
      })

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`)
      }

      const reader  = response.body.getReader()
      const decoder = new TextDecoder()
      let accumulated = ''
      let meta        = null
      let buffer      = '' // carry-over for partial SSE events across chunk boundaries

      // SSE event loop.
      // Spring frames each Flux<String> emission as:  data: <token>\n\n
      // We split on the SSE event boundary (double newline) so tokens that
      // themselves contain newlines (markdown tables, code blocks) are never lost.
      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })

        // Split completed events on double newline; keep the trailing fragment
        const events = buffer.split('\n\n')
        buffer = events.pop() ?? ''

        for (const event of events) {
          // Collect all "data:" lines within this event and rejoin as one value
          const data = event
            .split('\n')
            .filter(l => l.startsWith('data:'))
            .map(l => l.slice(5)) // strip "data:" prefix, keep the space/content
            .join('\n')

          if (!data) continue

          if (data.trim() === '[DONE]') break

          if (data.trim().startsWith('[DONE_META]:')) {
            try { meta = JSON.parse(data.trim().slice('[DONE_META]:'.length)) }
            catch { /* ignore */ }
            continue
          }

          // Regular token — append and re-render
          accumulated += data
          setMessages(prev => prev.map(m =>
            m.messageId === streamingId
              ? { ...m, content: accumulated }
              : m
          ))
        }
      }

      // Replace streaming placeholder with final persisted message
      if (meta) {
        const finalMsg = {
          role: 'ASSISTANT',
          content: accumulated,
          messageId: meta.messageId || streamingId,
          sqlQuery: meta.sqlQuery,
          sources: meta.sources || [],
          createdAt: new Date().toISOString(),
          streaming: false
        }
        setMessages(prev => prev.map(m =>
          m.messageId === streamingId ? finalMsg : m
        ))

        // Update session in sidebar
        const newSessionId = meta.sessionId
        if (newSessionId) {
          if (!activeSessionId) {
            setActiveSessionId(newSessionId)
            navigate(`/chat/${newSessionId}`, { replace: true, state: {} })
            setSessions(prev => {
              if (prev.find(s => s.sessionId === newSessionId)) {
                return prev.map(s => s.sessionId === newSessionId
                  ? { ...s, title: msg.length > 55 ? msg.substring(0, 52) + '...' : msg }
                  : s)
              }
              return [{ sessionId: newSessionId, title: msg, createdAt: new Date().toISOString() }, ...prev]
            })
          } else {
            setSessions(prev => prev.map(s =>
              s.sessionId === newSessionId
                ? { ...s, title: msg.length > 55 ? msg.substring(0, 52) + '...' : msg }
                : s
            ))
          }
        }
      } else {
        // No metadata — just mark as done
        setMessages(prev => prev.map(m =>
          m.messageId === streamingId ? { ...m, streaming: false } : m
        ))
      }
    } catch (err) {
      console.error('Stream error:', err)
      toast.error('Failed to send message')
      setMessages(prev => prev.filter(m =>
        m.messageId !== tempUserId && m.messageId !== streamingId
      ))
    } finally {
      setLoading(false)
    }
  }, [input, loading, activeSessionId, navigate])

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      send()
    }
  }

  return (
    <div className={styles.root}>
      <div className={styles.sessions}>
        <div className={styles.sessionsHeader}>
          <span className={styles.sessionsTitle}>Conversations</span>
          <button className="btn btn-primary btn-sm btn-icon" onClick={newSession} title="New chat">
            <Plus size={14} />
          </button>
        </div>
        <div className={styles.sessionList}>
          {loadingSessions && <div className={styles.sessionLoading}>Loading…</div>}
          {!loadingSessions && sessions.length === 0 && (
            <div className={styles.sessionEmpty}>
              <MessageSquare size={20} />
              <p>No conversations yet</p>
              <button className="btn btn-primary btn-sm" onClick={newSession}>Start chatting</button>
            </div>
          )}
          {sessions.map(s => (
            <div
              key={s.sessionId}
              className={`${styles.sessionItem} ${s.sessionId === activeSessionId ? styles.sessionItemActive : ''}`}
              onClick={() => selectSession(s.sessionId)}
            >
              <MessageSquare size={13} className={styles.sessionIcon} />
              <div className={styles.sessionMeta}>
                <span className={styles.sessionTitle}>{s.title || 'New Chat'}</span>
                <span className={styles.sessionTime}>{s.updatedAt}</span>
              </div>
              <button className={styles.sessionDelete} onClick={(e) => deleteSession(e, s.sessionId)} title="Delete">
                <Trash2 size={12} />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className={styles.chatArea}>
        {messages.length === 0 ? (
          <div className={styles.emptyState}>
            <div className={styles.emptyIcon}><Bot size={32} /></div>
            { <h2 className={styles.emptyTitle}>CFC Agent</h2> }
            <p className={styles.emptyDesc}>
              Ask me about orders, fulfilment jobs, errors, pick/delivery reports, and remediation steps.
            </p>
            {/* <div className={styles.suggestions}>
              {SUGGESTIONS.map(s => (
                <button key={s} className={styles.suggestion} onClick={() => send(s)}>
                  <ChevronRight size={12} />
                  {s}
                </button>
              ))}
            </div> */}
          </div>
        ) : (
          <div className={styles.messages}>
            {messages.map((msg, i) => (
              <MessageBubble key={msg.messageId || i} msg={msg} />
            ))}

            <div ref={bottomRef} />
          </div>
        )}

        <div className={styles.inputArea}>
          {prefillActive && input && (
            <div className={styles.prefillBanner}>
              <span className={styles.prefillIcon}>✦</span>
              <span>Pre-filled from order context — review and press <strong>Send</strong> to submit</span>
              <button className={styles.prefillDismiss} onClick={() => setPrefillActive(false)}>✕</button>
            </div>
          )}
          <div className={styles.inputWrapper}>
            <textarea
              ref={textareaRef}
              className={styles.textarea}
              placeholder="Ask about orders, jobs, errors, or remediation steps… (Enter to send)"
              value={input}
              onChange={e => { setInput(e.target.value); setPrefillActive(false) }}
              onKeyDown={handleKey}
              rows={1}
              disabled={loading}
            />
            <button className={styles.sendBtn} onClick={() => send()} disabled={!input.trim() || loading}>
              {loading ? <Loader2 size={16} className={styles.spin} /> : <Send size={16} />}
            </button>
          </div>
          <p className={styles.inputHint}>
            Shift+Enter for new line · SQL queries are hidden by default — click "view" to expand
          </p>
        </div>
      </div>
    </div>
  )
}
