import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import {
  MessageSquare, LayoutDashboard, Package,
  AlertTriangle, FileText, BotMessageSquare, ChevronRight
} from 'lucide-react'
import styles from './Layout.module.css'

const NAV = [
  { to: '/chat',        icon: MessageSquare,   label: 'CFC Agent' },
  { to: '/dashboard',   icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/orders',      icon: Package,         label: 'Orders' },
  { to: '/priority',    icon: AlertTriangle,   label: 'Priority Issues' },
  { to: '/remediation', icon: FileText,        label: 'Supporting Documents' },
]

export default function Layout() {
  const navigate = useNavigate()

  return (
    <div className={styles.root}>
      {/* Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.brand} onClick={() => navigate('/chat')}>
          <div className={styles.brandIcon}>
            <BotMessageSquare size={18} />
          </div>
          <div>
            <div className={styles.brandName}>CFC Agent</div>
            {/* <div className={styles.brandSub}>Support</div> */}
          </div>
        </div>

        <nav className={styles.nav}>
          {NAV.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `${styles.navItem} ${isActive ? styles.navItemActive : ''}`
              }
            >
              <Icon size={16} />
              <span>{label}</span>
              <ChevronRight size={12} className={styles.navChevron} />
            </NavLink>
          ))}
        </nav>

        <div className={styles.sidebarFooter}>
          <div className={styles.footerBadge}>
            <span className={styles.footerDot} />
            Operations Support
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className={styles.main}>
        <Outlet />
      </main>
    </div>
  )
}
