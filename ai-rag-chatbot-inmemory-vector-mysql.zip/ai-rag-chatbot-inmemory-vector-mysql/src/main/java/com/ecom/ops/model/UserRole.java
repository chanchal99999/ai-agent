package com.ecom.ops.model;

public enum UserRole {
    ADMIN,
    USER
}
