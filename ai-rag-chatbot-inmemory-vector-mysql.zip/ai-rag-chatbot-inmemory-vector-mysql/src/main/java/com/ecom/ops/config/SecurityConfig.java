package com.ecom.ops.config;

import java.util.List;

import jakarta.servlet.DispatcherType;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.ecom.ops.security.JwtAuthFilter;
import com.ecom.ops.security.UserDetailsServiceImpl;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

	private final JwtAuthFilter jwtAuthFilter;
	private final UserDetailsServiceImpl userDetailsService;

	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider p = new DaoAuthenticationProvider();
		p.setUserDetailsService(userDetailsService);
		p.setPasswordEncoder(passwordEncoder());
		return p;
	}

	@Bean
	AuthenticationManager authenticationManager(AuthenticationConfiguration cfg) throws Exception {
		return cfg.getAuthenticationManager();
	}

	@Bean
	CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration config = new CorsConfiguration();
		config.setAllowedOrigins(List.of("http://localhost:3000", "http://localhost:5173"));
		config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
		config.setAllowedHeaders(List.of("*"));
		config.setAllowCredentials(false);
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", config);
		return source;
	}

	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http.cors(cors -> cors.configurationSource(corsConfigurationSource())).csrf(AbstractHttpConfigurer::disable)
				.sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
				.authorizeHttpRequests(auth -> auth

						// ── Permit async re-dispatch of streaming (Flux) responses ──
						// Streaming endpoints run through the filter chain twice:
						// once on the initial REQUEST (full JWT auth happens here)
						// and again on the ASYNC dispatch when the stream is written
						// back. The SecurityContext is empty on that second pass, so
						// without this line the async dispatch is wrongly denied.
						.dispatcherTypeMatchers(DispatcherType.ASYNC, DispatcherType.FORWARD, DispatcherType.ERROR)
						.permitAll()

						// ── Allow CORS preflight (OPTIONS) for all routes ────
						.requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()

						// ── Public: auth endpoints ──────────────────────────
						.requestMatchers("/api/auth/**").permitAll()

						// ── ADMIN ONLY: remediation write operations ─────────
						.requestMatchers(HttpMethod.POST, "/api/remediation").hasRole("ADMIN")
						.requestMatchers(HttpMethod.POST, "/api/remediation/upload").hasRole("ADMIN")
						.requestMatchers(HttpMethod.POST, "/api/remediation/reindex").hasRole("ADMIN")
						.requestMatchers(HttpMethod.PUT, "/api/remediation/**").hasRole("ADMIN")
						.requestMatchers(HttpMethod.DELETE, "/api/remediation/**").hasRole("ADMIN")

						// ── All other API routes: any authenticated user ─────
						.requestMatchers("/api/**").authenticated()

						// ── Everything else ──────────────────────────────────
						.anyRequest().permitAll())
				.authenticationProvider(authenticationProvider())
				.addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

		return http.build();
	}
}